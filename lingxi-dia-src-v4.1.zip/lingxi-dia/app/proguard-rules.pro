# Add project specific ProGuard rules here.

# 4.0：Vosk 离线语音识别（通过 JNA 调用本机库）
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }
-keep class org.vosk.** { *; }
-dontwarn java.awt.**
