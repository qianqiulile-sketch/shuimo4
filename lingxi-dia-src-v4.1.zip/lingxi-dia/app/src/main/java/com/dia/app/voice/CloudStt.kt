package com.dia.app.voice

import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * 云端语音转文字：OpenAI 兼容的 `/audio/transcriptions` 接口。
 * 适用于 OpenAI Whisper、Groq（whisper-large-v3）、硅基流动（FunAudioLLM/SenseVoiceSmall）、
 * 自建 faster-whisper / whisper.cpp server 等。地址和 Key 留空时沿用「云端模型」的配置。
 */
object CloudStt {

    fun baseUrl(): String = DiaSettings.sttCloudBaseUrl.value.ifBlank { DiaPrefs.cloudBaseUrl.value }.trim()
    fun apiKey(): String = DiaSettings.sttCloudApiKey.value.ifBlank { DiaPrefs.cloudApiKey.value }.trim()
    fun model(): String = DiaSettings.sttCloudModel.value.ifBlank { "whisper-1" }

    fun isConfigured(): Boolean = baseUrl().startsWith("http")

    /** 云端一次能收的大小（大多数服务上限 25MB）。 */
    const val MAX_UPLOAD = 24 * 1024 * 1024

    val DIRECT_EXTS = setOf("mp3", "mp4", "mpeg", "mpga", "m4a", "wav", "webm", "ogg", "flac", "opus")

    fun endpoint(): String {
        val b = baseUrl().trimEnd('/')
        return when {
            b.endsWith("/audio/transcriptions") -> b
            Regex("/v\\d").containsMatchIn(b) || b.count { it == '/' } > 2 -> "$b/audio/transcriptions"
            else -> "$b/v1/audio/transcriptions"
        }
    }

    /**
     * 上传一段音频，返回文字。同步执行（请在 IO 线程调用）。
     * @param ext 文件扩展名（决定上传时的文件名 / 类型）
     */
    fun transcribe(bytes: ByteArray, ext: String, language: String? = null): String {
        if (!isConfigured()) throw IllegalStateException("没有配置云端转写接口：设置 → 语音转文字 → 云端转写")
        val boundary = "----LingXi${System.currentTimeMillis()}"
        val body = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            body.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(Charsets.UTF_8))
        }
        field("model", model())
        field("response_format", "json")
        if (!language.isNullOrBlank()) field("language", language)
        val e = ext.lowercase().ifBlank { "wav" }
        val mime = when (e) {
            "mp3", "mpga", "mpeg" -> "audio/mpeg"
            "m4a", "mp4" -> "audio/mp4"
            "ogg", "opus" -> "audio/ogg"
            "webm" -> "audio/webm"
            "flac" -> "audio/flac"
            else -> "audio/wav"
        }
        body.write(
            "--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.$e\"\r\nContent-Type: $mime\r\n\r\n".toByteArray(Charsets.UTF_8),
        )
        body.write(bytes)
        body.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
        val payload = body.toByteArray()

        val conn = (URL(endpoint()).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 300_000
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val key = apiKey()
            if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
            setFixedLengthStreamingMode(payload.size)
        }
        try {
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("云端转写失败（HTTP $code）：${text.take(300)}")
            return try {
                JSONObject(text).optString("text").trim()
            } catch (_: Exception) {
                text.trim()
            }
        } finally {
            conn.disconnect()
        }
    }
}
