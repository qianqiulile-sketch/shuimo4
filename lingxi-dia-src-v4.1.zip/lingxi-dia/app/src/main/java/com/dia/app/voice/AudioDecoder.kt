package com.dia.app.voice

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.floor

/**
 * 把任意音频 / 视频文件（mp3、m4a、aac、wav、ogg、amr、flac、mp4…）解码成
 * 16kHz、单声道、16 位 PCM，**边解码边交给下游**（几个小时的录音也不会占满内存）。
 *
 * 只用系统自带的 MediaExtractor + MediaCodec，不加第三方库。
 */
object AudioDecoder {

    const val RATE = 16_000

    class Info(val durationUs: Long, val mime: String, val sourceRate: Int, val channels: Int)

    /**
     * @param sink 收到一段 16k 单声道 PCM（前 n 个有效）；返回 false 提前结束
     * @param onProgress 0..1 的进度（拿不到时长时不回调）
     * @return 文件信息
     */
    fun decode(
        context: Context,
        uri: Uri,
        sink: (ShortArray, Int) -> Boolean,
        onProgress: (Float) -> Unit = {},
    ): Info {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
                if (m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) throw IllegalArgumentException("文件里没有音轨")
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else -1L
            val info = Info(durationUs, mime, rate, channels)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            var floatPcm = false
            var resampler = Resampler(rate, RATE)
            val bufInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var stopped = false
            var mono = FloatArray(8192)
            var lastPct = -1
            try {
                while (!outputDone && !stopped) {
                    if (!inputDone) {
                        val inIdx = codec.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val inBuf = codec.getInputBuffer(inIdx)
                            val n = if (inBuf != null) ex.readSampleData(inBuf, 0) else -1
                            if (n < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, n, ex.sampleTime.coerceAtLeast(0), 0)
                                ex.advance()
                            }
                        }
                    }
                    val outIdx = codec.dequeueOutputBuffer(bufInfo, 10_000)
                    when {
                        outIdx >= 0 -> {
                            val out = codec.getOutputBuffer(outIdx)
                            if (out != null && bufInfo.size > 0) {
                                out.position(bufInfo.offset)
                                out.limit(bufInfo.offset + bufInfo.size)
                                val ch = channels.coerceAtLeast(1)
                                val frames: Int
                                if (floatPcm) {
                                    val fb = out.order(ByteOrder.nativeOrder()).asFloatBuffer()
                                    frames = fb.remaining() / ch
                                    if (mono.size < frames) mono = FloatArray(frames)
                                    for (f in 0 until frames) {
                                        var sum = 0f
                                        for (c in 0 until ch) sum += fb.get()
                                        mono[f] = (sum / ch) * 32767f
                                    }
                                } else {
                                    val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                                    frames = sb.remaining() / ch
                                    if (mono.size < frames) mono = FloatArray(frames)
                                    for (f in 0 until frames) {
                                        var sum = 0f
                                        for (c in 0 until ch) sum += sb.get().toFloat()
                                        mono[f] = sum / ch
                                    }
                                }
                                if (frames > 0) {
                                    val produced = resampler.process(mono, frames)
                                    if (produced > 0 && !sink(resampler.out, produced)) stopped = true
                                }
                                if (durationUs > 0) {
                                    val pct = ((bufInfo.presentationTimeUs * 100) / durationUs).toInt().coerceIn(0, 100)
                                    if (pct != lastPct) { lastPct = pct; onProgress(pct / 100f) }
                                }
                            }
                            codec.releaseOutputBuffer(outIdx, false)
                            if ((bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        }
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val of = codec.outputFormat
                            if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            floatPcm = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                            resampler = Resampler(rate, RATE)
                        }
                    }
                }
            } finally {
                try { codec.stop() } catch (_: Exception) { }
                try { codec.release() } catch (_: Exception) { }
            }
            return info
        } finally {
            try { ex.release() } catch (_: Exception) { }
        }
    }

    /** 解码整段（有上限，默认 10 分钟），返回 16k 单声道 PCM 字节（小端）。 */
    fun decodeAll(context: Context, uri: Uri, maxSeconds: Int = 600, onProgress: (Float) -> Unit = {}): ByteArray {
        val limit = maxSeconds.toLong() * RATE
        val out = java.io.ByteArrayOutputStream()
        var total = 0L
        decode(context, uri, { buf, n ->
            val take = minOf(n.toLong(), limit - total).toInt()
            for (i in 0 until take) {
                val v = buf[i].toInt()
                out.write(v and 0xff)
                out.write((v shr 8) and 0xff)
            }
            total += take
            total < limit
        }, onProgress)
        return out.toByteArray()
    }

    /** 16 位 PCM 字节 → ShortArray。 */
    fun bytesToShorts(pcm: ByteArray): ShortArray {
        val n = pcm.size / 2
        val s = ShortArray(n)
        for (i in 0 until n) s[i] = ((pcm[2 * i].toInt() and 0xff) or (pcm[2 * i + 1].toInt() shl 8)).toShort()
        return s
    }

    /** ShortArray → 16 位小端 PCM 字节。 */
    fun shortsToBytes(s: ShortArray, n: Int = s.size): ByteArray {
        val b = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = s[i].toInt()
            b[2 * i] = (v and 0xff).toByte()
            b[2 * i + 1] = ((v shr 8) and 0xff).toByte()
        }
        return b
    }

    /** 线性插值重采样（流式，跨块连续）。 */
    class Resampler(src: Int, private val dst: Int) {
        private val step = src.toDouble() / dst
        private var pos = 0.0
        private var prev = 0f
        var out = ShortArray(4096)
            private set

        /** 处理 input 的前 n 个样本，结果写进 [out]，返回写了多少个。 */
        fun process(input: FloatArray, n: Int): Int {
            if (n <= 0) return 0
            val need = (n / step).toInt() + 4
            if (out.size < need) out = ShortArray(need)
            var w = 0
            if (step == 1.0) {
                for (i in 0 until n) out[w++] = clamp(input[i])
                prev = input[n - 1]
                return w
            }
            while (true) {
                val i = floor(pos).toInt()
                if (i + 1 >= n) break
                val a = if (i < 0) prev else input[i]
                val b = input[i + 1]
                val t = (pos - i).toFloat()
                if (w >= out.size) out = out.copyOf(out.size * 2)
                out[w++] = clamp(a + (b - a) * t)
                pos += step
            }
            prev = input[n - 1]
            pos -= n
            return w
        }

        private fun clamp(v: Float): Short = v.coerceIn(-32768f, 32767f).toInt().toShort()
    }
}
