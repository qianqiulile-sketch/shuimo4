package com.dia.app.deep

import org.json.JSONArray
import org.json.JSONObject

/** 用户在长思进行中随时发来的消息（补充信息、改方向、回答 AI 的提问）。 */
data class DeepNote(
    val id: String,
    val text: String,
    val time: Long,
    val handled: Boolean = false,
    /** 立即处理：打断当前步骤，下一轮优先落实 */
    val urgent: Boolean = false,
)

/**
 * 长思过程中的一条记录（界面「进程」页显示）。
 * kind：cycle 一轮开始 / tool 工具调用 / result 本步结论 / user 用户消息 / question AI 请示 /
 *       plan 计划变化 / error 出错 / system 系统提示 / confirm 待批准
 */
data class DeepEvent(
    val id: String,
    val time: Long,
    val kind: String,
    val title: String,
    val detail: String = "",
    /** running / done / error（工具）；pending / approved / rejected（确认） */
    val status: String = "",
    /** 工具进度 / 意图等补充说明 */
    val note: String = "",
    val toolName: String? = null,
    val durationMs: Long = 0,
)

/** 一个「自主长思」。不可变，修改用 copy。 */
data class DeepSession(
    val id: String,
    val topic: String,
    val createdAt: Long,
    val updatedAt: Long = createdAt,
    /** idle / planning / review 待确认计划 / running / paused / done / error */
    val status: String = "idle",
    /** auto 自行决定 / on 允许联网 / off 不联网 */
    val web: String = "auto",
    val autoApprove: Boolean = true,
    /** 最多多少轮（0 = 不限，直到用户暂停） */
    val maxCycles: Int = 0,
    /** 生成计划后先等用户确认 */
    val reviewFirst: Boolean = false,
    val cycles: Int = 0,
    val plan: List<DeepStep> = emptyList(),
    val nextId: Int = 1,
    val currentStepId: String? = null,
    /** 正在做什么（一句话） */
    val activity: String = "",
    /** 阶段总结 */
    val summary: String = "",
    val notes: List<DeepNote> = emptyList(),
    /** 本长思的目录（绝对路径） */
    val folder: String = "",
    /** 连续几次复盘都没想出新步骤 */
    val emptyReflections: Int = 0,
    /** 每个步骤「未完成」的次数，超过 2 次标为失败 */
    val attempts: Map<String, Int> = emptyMap(),
    /** 最终要交付的格式：docx / pptx / pdf / xlsx / md */
    val deliverables: List<String> = listOf("docx"),
    /** 上次导出 Word 全记录时是第几轮 */
    val backupCycle: Int = 0,
    /** 上次生成成果（报告 / PPT / PDF）时是第几轮 */
    val reportCycle: Int = 0,
) {
    val isActive: Boolean get() = status == "running" || status == "planning"

    val statusLabel: String
        get() = when (status) {
            "planning" -> "规划中"
            "review" -> "待你确认计划"
            "running" -> "思考中"
            "paused" -> "已暂停"
            "done" -> "已完成"
            "error" -> "出错"
            else -> "未开始"
        }
}

/** JSON 读写（state.json / events.json）。 */
object DeepJson {

    fun step(s: DeepStep): JSONObject = JSONObject()
        .put("id", s.id).put("title", s.title).put("detail", s.detail).put("status", s.status)
        .put("result", s.result).put("by", s.by)
        .put("children", JSONArray().also { a -> s.children.forEach { a.put(step(it)) } })

    fun step(o: JSONObject): DeepStep = DeepStep(
        id = o.optString("id"),
        title = o.optString("title"),
        detail = o.optString("detail"),
        status = o.optString("status", DeepStep.TODO).ifBlank { DeepStep.TODO },
        result = o.optString("result"),
        by = o.optString("by", "ai"),
        children = o.optJSONArray("children")?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let { c -> step(c) } } }.orEmpty(),
    )

    fun session(s: DeepSession): JSONObject = JSONObject()
        .put("id", s.id).put("topic", s.topic).put("createdAt", s.createdAt).put("updatedAt", s.updatedAt)
        .put("status", s.status).put("web", s.web).put("autoApprove", s.autoApprove).put("maxCycles", s.maxCycles)
        .put("reviewFirst", s.reviewFirst).put("cycles", s.cycles).put("nextId", s.nextId)
        .put("currentStepId", s.currentStepId ?: "").put("activity", s.activity).put("summary", s.summary)
        .put("folder", s.folder).put("emptyReflections", s.emptyReflections)
        .put("plan", JSONArray().also { a -> s.plan.forEach { a.put(step(it)) } })
        .put("notes", JSONArray().also { a ->
            s.notes.forEach { n ->
                a.put(JSONObject().put("id", n.id).put("text", n.text).put("time", n.time).put("handled", n.handled).put("urgent", n.urgent))
            }
        })
        .put("attempts", JSONObject().also { o -> s.attempts.forEach { (k, v) -> o.put(k, v) } })
        .put("deliverables", JSONArray().also { a -> s.deliverables.forEach { a.put(it) } })
        .put("backupCycle", s.backupCycle).put("reportCycle", s.reportCycle)

    fun session(o: JSONObject): DeepSession {
        val notes = o.optJSONArray("notes")?.let { a ->
            (0 until a.length()).mapNotNull { i ->
                a.optJSONObject(i)?.let { n ->
                    DeepNote(n.optString("id"), n.optString("text"), n.optLong("time"), n.optBoolean("handled"), n.optBoolean("urgent"))
                }
            }
        }.orEmpty()
        val attempts = HashMap<String, Int>()
        o.optJSONObject("attempts")?.let { a -> a.keys().forEach { k -> attempts[k] = a.optInt(k) } }
        return DeepSession(
            id = o.optString("id"),
            topic = o.optString("topic"),
            createdAt = o.optLong("createdAt"),
            updatedAt = o.optLong("updatedAt"),
            status = o.optString("status", "idle"),
            web = o.optString("web", "auto"),
            autoApprove = o.optBoolean("autoApprove", true),
            maxCycles = o.optInt("maxCycles", 0),
            reviewFirst = o.optBoolean("reviewFirst", false),
            cycles = o.optInt("cycles", 0),
            plan = o.optJSONArray("plan")?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let { s -> step(s) } } }.orEmpty(),
            nextId = o.optInt("nextId", 1),
            currentStepId = o.optString("currentStepId").ifBlank { null },
            activity = o.optString("activity"),
            summary = o.optString("summary"),
            notes = notes,
            folder = o.optString("folder"),
            emptyReflections = o.optInt("emptyReflections", 0),
            attempts = attempts,
            deliverables = o.optJSONArray("deliverables")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } } ?: listOf("docx"),
            backupCycle = o.optInt("backupCycle", 0),
            reportCycle = o.optInt("reportCycle", 0),
        )
    }

    fun events(list: List<DeepEvent>): JSONArray = JSONArray().also { a ->
        list.forEach { e ->
            a.put(
                JSONObject().put("id", e.id).put("time", e.time).put("kind", e.kind).put("title", e.title)
                    .put("detail", e.detail.take(6000)).put("status", e.status).put("note", e.note)
                    .put("toolName", e.toolName ?: "").put("durationMs", e.durationMs),
            )
        }
    }

    fun events(a: JSONArray): List<DeepEvent> = (0 until a.length()).mapNotNull { i ->
        a.optJSONObject(i)?.let { o ->
            DeepEvent(
                id = o.optString("id"), time = o.optLong("time"), kind = o.optString("kind"), title = o.optString("title"),
                detail = o.optString("detail"), status = o.optString("status").let { if (it == "running" || it == "pending") "error" else it },
                note = o.optString("note"), toolName = o.optString("toolName").ifBlank { null }, durationMs = o.optLong("durationMs"),
            )
        }
    }
}
