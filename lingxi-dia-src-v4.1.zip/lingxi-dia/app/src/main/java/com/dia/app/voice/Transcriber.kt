package com.dia.app.voice

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.dia.app.files.FileManager
import com.dia.app.files.FileRef
import com.dia.app.llm.AudioClip
import com.dia.app.llm.DiaEngine
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.coroutineContext

/**
 * 语音转文字的统一入口（对话里说的话、录音、音频 / 视频文件）。
 *
 * 引擎：
 *  - vosk  ：嵌入式离线模型（默认，下载一次后完全离线）
 *  - cloud ：云端 Whisper / SenseVoice（OpenAI 兼容接口）
 *  - gemma ：本机多模态大模型直接听写（Gemma 3n / 4）
 *  - system：系统语音识别（只用于对话里实时说话）
 *
 * auto 会按「离线模型 → 云端 → 本机大模型」依次挑第一个可用的。
 */
object Transcriber {

    data class Result(
        val text: String,
        val engine: String,
        val seconds: Double,
        /** 带时间戳的分段（每行一句） */
        val segments: String? = null,
        val note: String = "",
    )

    fun engineLabel(e: String): String = when (e) {
        "vosk" -> "离线语音模型"
        "cloud" -> "云端转写"
        "gemma" -> "本机大模型听写"
        "system" -> "系统语音识别"
        else -> "自动"
    }

    private fun language(): String = DiaSettings.voiceLanguage.value.substringBefore('-').lowercase(Locale.ROOT)

    /** 文件转写可用的引擎。 */
    fun availableFileEngines(ctx: Context): List<String> = buildList {
        if (VoskModels.isReady(ctx)) add("vosk")
        if (CloudStt.isConfigured()) add("cloud")
        if (DiaEngine.isReady) add("gemma")
    }

    fun resolveFileEngine(ctx: Context, pref: String): String? {
        val avail = availableFileEngines(ctx)
        return if (pref in avail) pref else avail.firstOrNull()
    }

    private fun noEngineMessage(): String =
        "没有可用的语音转文字引擎。请在 设置 → 语音转文字 里下载离线中文模型（约 42MB，一次下载永久离线），" +
            "或配置云端转写接口，或加载本机 Gemma 模型。"

    fun formatDuration(sec: Double): String {
        if (sec <= 0) return "未知时长"
        val s = sec.toLong()
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun stamp(sec: Double): String {
        val s = sec.coerceAtLeast(0.0).toLong()
        return if (s >= 3600) String.format(Locale.US, "[%d:%02d:%02d]", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.US, "[%02d:%02d]", s / 60, s % 60)
    }

    private fun joinPieces(pieces: List<String>): String {
        val sb = StringBuilder()
        for (p in pieces) {
            if (p.isBlank()) continue
            if (sb.isNotEmpty()) {
                val last = sb.last()
                sb.append(if (last.code in 0x3400..0x9fff) "。" else ". ")
            }
            sb.append(p.trim())
        }
        if (sb.isNotEmpty() && sb.last().code in 0x3400..0x9fff) sb.append('。')
        return sb.toString()
    }

    fun probeSeconds(ctx: Context, uri: Uri): Double = try {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var d = -1L
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/") && f.containsKey(MediaFormat.KEY_DURATION)) {
                    d = f.getLong(MediaFormat.KEY_DURATION); break
                }
            }
            if (d > 0) d / 1_000_000.0 else -1.0
        } finally {
            ex.release()
        }
    } catch (_: Exception) {
        -1.0
    }

    // ───────── 文件 ─────────

    suspend fun transcribeRef(ctx: Context, ref: FileRef, engine: String, progress: (String) -> Unit): Result {
        val e = resolveFileEngine(ctx, engine) ?: return Result("", "无", 0.0, note = noEngineMessage())
        val uri = Uri.parse(ref.uri)
        progress("${engineLabel(e)} · 正在转写 ${ref.name}…")
        val raw = when (e) {
            "vosk" -> withContext(Dispatchers.IO) { voskFile(ctx, uri, progress) }
            "cloud" -> withContext(Dispatchers.IO) { cloudFile(ctx, ref, uri, progress) }
            else -> gemmaFile(ctx, uri, progress)
        }
        if (e == "vosk" && DiaSettings.sttPolish.value && raw.text.isNotBlank() && LlmGateway.isAvailable()) {
            progress("AI 正在加标点、分段…")
            val polished = polish(raw.text)
            if (polished.isNotBlank()) return raw.copy(text = polished)
        }
        return raw
    }

    private suspend fun voskFile(ctx: Context, uri: Uri, progress: (String) -> Unit): Result {
        val job = coroutineContext[Job]
        progress("正在加载离线语音模型…")
        val rec = VoskModels.recognizer(ctx)
        val pieces = ArrayList<String>()
        val segs = StringBuilder()
        var samples = 0L
        fun add(json: String?) {
            val p = VoskModels.parse(json)
            if (p.text.isBlank()) return
            pieces.add(p.text)
            val start = if (p.start >= 0) p.start else samples / AudioDecoder.RATE.toDouble()
            segs.append(stamp(start)).append(' ').append(p.text).append('\n')
        }
        val info = try {
            AudioDecoder.decode(ctx, uri, { buf, n ->
                if (rec.acceptWaveForm(buf, n)) add(rec.result)
                samples += n
                job?.isActive != false
            }, { pct -> progress("离线识别中 ${(pct * 100).toInt()}%") })
        } finally {
            try { add(rec.finalResult) } catch (_: Throwable) { }
            try { rec.close() } catch (_: Throwable) { }
        }
        val secs = if (info.durationUs > 0) info.durationUs / 1_000_000.0 else samples / AudioDecoder.RATE.toDouble()
        return Result(joinPieces(pieces), engineLabel("vosk"), secs, segs.toString().trim())
    }

    private fun cloudFile(ctx: Context, ref: FileRef, uri: Uri, progress: (String) -> Unit): Result {
        val secs = probeSeconds(ctx, uri)
        if (ref.ext in CloudStt.DIRECT_EXTS && ref.size in 1..CloudStt.MAX_UPLOAD.toLong()) {
            progress("正在上传到云端转写…")
            val text = CloudStt.transcribe(FileManager.readBytes(ref), ref.ext, language())
            return Result(text, engineLabel("cloud") + " · " + CloudStt.model(), secs)
        }
        // 太大或格式不支持：解码成 16k WAV，按 10 分钟一段上传
        val chunkSamples = AudioDecoder.RATE * 600
        val buf = ShortArray(chunkSamples)
        var fill = 0
        var index = 0
        val texts = ArrayList<String>()
        val segs = StringBuilder()
        fun flush() {
            if (fill == 0) return
            index++
            progress("云端转写第 $index 段…")
            val wav = AudioClip(AudioDecoder.shortsToBytes(buf, fill), AudioDecoder.RATE).toWavBytes()
            val t = CloudStt.transcribe(wav, "wav", language())
            if (t.isNotBlank()) {
                texts.add(t)
                segs.append(stamp((index - 1) * 600.0)).append(' ').append(t).append('\n')
            }
            fill = 0
        }
        AudioDecoder.decode(ctx, uri, { b, n ->
            var i = 0
            while (i < n) {
                val take = minOf(n - i, chunkSamples - fill)
                System.arraycopy(b, i, buf, fill, take)
                fill += take; i += take
                if (fill == chunkSamples) flush()
            }
            true
        })
        flush()
        return Result(texts.joinToString("\n"), engineLabel("cloud") + " · " + CloudStt.model(), secs, segs.toString().trim())
    }

    private suspend fun gemmaFile(ctx: Context, uri: Uri, progress: (String) -> Unit): Result {
        progress("正在解码音频…")
        val pcm = withContext(Dispatchers.IO) { AudioDecoder.decodeAll(ctx, uri, maxSeconds = 20 * 60) }
        val per = AudioDecoder.RATE * 2 * 30
        val chunks = (pcm.size + per - 1) / per
        val texts = ArrayList<String>()
        val segs = StringBuilder()
        for (i in 0 until chunks) {
            if (coroutineContext[Job]?.isActive == false) break
            progress("本机大模型听写第 ${i + 1}/$chunks 段…")
            val part = pcm.copyOfRange(i * per, minOf(pcm.size, (i + 1) * per))
            val t = try {
                LlmGateway.completeLocal(
                    system = "你是语音转写引擎。把音频里的话逐字转写成文字（中文用简体，带标点），只输出转写结果；没有人说话就输出空。",
                    prompt = "",
                    audio = listOf(AudioClip(part, AudioDecoder.RATE)),
                    temperature = 0.1,
                ).trim()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                ""
            }
            if (t.isNotBlank()) {
                texts.add(t)
                segs.append(stamp(i * 30.0)).append(' ').append(t).append('\n')
            }
        }
        val note = if (pcm.size >= AudioDecoder.RATE * 2 * 20 * 60) "（本机大模型只转写前 20 分钟）" else ""
        return Result(texts.joinToString(""), engineLabel("gemma"), pcm.size / 2.0 / AudioDecoder.RATE, segs.toString().trim(), note)
    }

    /** 给没有标点的转写加标点、分段（不改用词）。太长时只处理前 12000 字。 */
    private suspend fun polish(text: String): String {
        val limit = 12_000
        val head = text.take(limit)
        val chunks = com.dia.app.agent.AgentTools.chunk(head.replace("。", "。\n"), 1500)
        val out = StringBuilder()
        for (c in chunks) {
            val r = try {
                LlmGateway.complete(
                    system = "你是语音转写的校对员：给文字加上正确的标点，按意思分段，修正明显的同音错别字；不要增删内容、不要总结、不要解释。只输出校对后的文字。",
                    prompt = c,
                    temperature = 0.1,
                    timeoutMs = 120_000,
                ).trim()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                c
            }
            out.append(r).append('\n')
        }
        if (text.length > limit) out.append(text.substring(limit))
        return out.toString().trim()
    }

    // ───────── 一段录音（对话里说的话） ─────────

    /** 对话里的语音输入用哪个引擎（vosk / system / cloud / gemma / none）。 */
    fun micEngine(ctx: Context, systemAvailable: Boolean): String {
        val pref = DiaSettings.sttEngine.value
        val vosk = VoskModels.isReady(ctx)
        return when {
            pref == "vosk" && vosk -> "vosk"
            pref == "system" && systemAvailable -> "system"
            pref == "cloud" && CloudStt.isConfigured() -> "cloud"
            pref == "gemma" && DiaEngine.isReady -> "gemma"
            vosk -> "vosk"
            systemAvailable -> "system"
            CloudStt.isConfigured() && LlmGateway.usingCloud() -> "cloud"
            DiaEngine.isReady -> "gemma"
            else -> "none"
        }
    }

    /** 把一段 PCM（16 位单声道）转成文字。engine = auto 时按 离线 → 云端 → 本机大模型 挑选。 */
    suspend fun transcribePcm(ctx: Context, pcm: ByteArray, sampleRate: Int, engine: String = "auto"): String {
        if (pcm.isEmpty()) return ""
        val e = when {
            engine != "auto" -> engine
            VoskModels.isReady(ctx) -> "vosk"
            CloudStt.isConfigured() && LlmGateway.usingCloud() -> "cloud"
            DiaEngine.isReady -> "gemma"
            else -> return ""
        }
        return when (e) {
            "vosk" -> withContext(Dispatchers.IO) {
                val rec = VoskModels.recognizer(ctx, sampleRate.toFloat())
                try {
                    val pieces = ArrayList<String>()
                    val shorts = AudioDecoder.bytesToShorts(pcm)
                    var i = 0
                    while (i < shorts.size) {
                        val n = minOf(4000, shorts.size - i)
                        val chunk = shorts.copyOfRange(i, i + n)
                        if (rec.acceptWaveForm(chunk, n)) VoskModels.parse(rec.result).text.takeIf { it.isNotBlank() }?.let { pieces.add(it) }
                        i += n
                    }
                    VoskModels.parse(rec.finalResult).text.takeIf { it.isNotBlank() }?.let { pieces.add(it) }
                    pieces.joinToString("，")
                } finally {
                    try { rec.close() } catch (_: Throwable) { }
                }
            }
            "cloud" -> withContext(Dispatchers.IO) { CloudStt.transcribe(AudioClip(pcm, sampleRate).toWavBytes(), "wav", language()) }
            "gemma" -> LlmGateway.completeLocal(
                system = "你是语音转写引擎。把音频里的话逐字转写成简体中文文字（带标点），只输出转写结果。",
                prompt = "",
                audio = listOf(AudioClip(pcm, sampleRate)),
                temperature = 0.1,
            ).trim()
            else -> ""
        }
    }

    // ───────── 让 AI 直接「听」 ─────────

    suspend fun listen(ctx: Context, ref: FileRef, question: String, progress: (String) -> Unit): String {
        val uri = Uri.parse(ref.uri)
        if (DiaEngine.isReady) {
            progress("正在解码音频…")
            val pcm = withContext(Dispatchers.IO) { AudioDecoder.decodeAll(ctx, uri, maxSeconds = 120) }
            val per = AudioDecoder.RATE * 2 * 30
            val n = ((pcm.size + per - 1) / per).coerceAtLeast(1)
            val answers = ArrayList<String>()
            for (i in 0 until n) {
                progress("本机模型正在听第 ${i + 1}/$n 段…")
                val part = pcm.copyOfRange(i * per, minOf(pcm.size, (i + 1) * per))
                val a = LlmGateway.completeLocal(
                    system = "你在仔细听一段音频。根据听到的内容（说话内容、语气情绪、音乐、环境声）回答问题，听不清的地方如实说明。",
                    prompt = if (n > 1) "（这是第 ${i + 1}/$n 段，约第 ${i * 30}–${(i + 1) * 30} 秒）$question" else question,
                    audio = listOf(AudioClip(part, AudioDecoder.RATE)),
                    temperature = 0.3,
                ).trim()
                answers.add(if (n > 1) "【第 ${i + 1} 段】$a" else a)
            }
            val joined = answers.joinToString("\n\n")
            val tail = if (pcm.size >= AudioDecoder.RATE * 2 * 120) "\n\n（只听了前 2 分钟；完整内容可以用 transcribe_audio 转写全文）" else ""
            return "《${ref.name}》（本机模型直接听）\n$joined$tail"
        }
        // 没有本机模型：先转文字，再让对话模型回答
        val t = transcribeRef(ctx, ref, DiaSettings.sttFileEngine.value, progress)
        if (t.text.isBlank()) return "没法听这段音频：${t.note.ifBlank { noEngineMessage() }}"
        progress("正在根据转写内容回答…")
        val answer = LlmGateway.complete(
            system = "你根据一段音频的转写文字回答问题。注意：转写看不出语气和背景声音，必要时说明。",
            prompt = "【音频转写】\n${t.text.take(12000)}\n\n【问题】$question",
            temperature = 0.3,
        ).trim()
        return "《${ref.name}》（已先用${t.engine}转写，${formatDuration(t.seconds)}）\n$answer"
    }
}
