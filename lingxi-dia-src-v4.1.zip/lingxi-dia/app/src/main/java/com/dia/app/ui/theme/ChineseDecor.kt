package com.dia.app.ui.theme

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.R
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ═════════════════════ 整页背景 ═════════════════════

/** 读取用户自定义背景（缩到合适大小，避免占用太多内存）。 */
@Composable
private fun customBackground(): ImageBitmap? {
    val path by DiaSettings.customBgPath.flow.collectAsState()
    val bmp by produceState<ImageBitmap?>(initialValue = null, path) {
        value = if (path.isBlank()) null else withContext(Dispatchers.IO) {
            try {
                val f = File(path)
                if (!f.exists()) return@withContext null
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var sample = 1
                while (o.outHeight / sample > 2400 || o.outWidth / sample > 1400) sample *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
            } catch (_: Throwable) {
                null
            }
        }
    }
    return bmp
}

/** 等比铺满（居中裁切）画一张图。 */
private fun DrawScope.drawCover(img: ImageBitmap, alpha: Float, alignTop: Boolean = false) {
    val scale = max(size.width / img.width, size.height / img.height)
    val dw = img.width * scale
    val dh = img.height * scale
    val dx = (size.width - dw) / 2f
    val dy = if (alignTop) 0f else (size.height - dh) / 2f
    drawImage(
        image = img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(dx.toInt(), dy.toInt()),
        dstSize = IntSize(dw.toInt() + 1, dh.toInt() + 1),
        alpha = alpha.coerceIn(0f, 1f),
    )
}

/**
 * 水墨背景：宣纸山水 / 江湖夜色 / 无极墨金 三幅画（或用户自定义 / AI 生成的背景），
 * 上面盖一层与底色相同的薄纱，保证文字清楚。浓淡可在设置里调。
 */
@Composable
fun Modifier.inkWashBackground(p: DiaPalette): Modifier {
    val strength by DiaSettings.bgStrength.flow.collectAsState()
    val builtIn = ImageBitmap.imageResource(p.bgRes)
    val custom = customBackground()
    // 主题包的背景画（水墨太极等）
    val themed = rememberThemeBitmap(LocalThemePack.current.images["background"], 1400)
    val img = custom ?: themed ?: builtIn
    val veil = p.background
    return this.drawBehind {
        drawRect(p.background)
        drawCover(img, (strength.coerceIn(10, 100) / 100f), alignTop = true)
        // 顶部和底部各加一道薄纱，标题栏 / 输入栏更清楚
        drawRect(
            brush = Brush.verticalGradient(
                0f to veil.copy(alpha = 0.55f),
                0.12f to veil.copy(alpha = 0.10f),
                0.80f to veil.copy(alpha = 0.05f),
                1f to veil.copy(alpha = 0.50f),
            ),
        )
    }
}

/** 老功能页（实时镜头、手写板…）的背景：江湖夜色，再压暗一些。 */
@Composable
fun Modifier.inkPageBackground(): Modifier {
    val builtIn = ImageBitmap.imageResource(R.drawable.bg_night)
    val img = rememberThemeBitmap(LocalThemePack.current.images["page"], 1400) ?: builtIn
    return this.drawBehind {
        drawRect(InkPalette.background)
        drawCover(img, 0.75f, alignTop = true)
        drawRect(Color.Black.copy(alpha = 0.35f))
    }
}

// ═════════════════════ 宣纸纹理 / 墨笔描边 ═════════════════════

/** 平铺宣纸纤维纹理（放在 clip 之后使用，纹理只出现在形状里）。 */
@Composable
fun Modifier.paperGrain(alpha: Float = 0.10f): Modifier {
    val builtIn = ImageBitmap.imageResource(R.drawable.paper_grain)
    val img = rememberThemeBitmap(LocalThemePack.current.images["grain"], 512) ?: builtIn
    val brush = remember(img) { ShaderBrush(ImageShader(img, TileMode.Repeated, TileMode.Repeated)) }
    return this.drawBehind { drawRect(brush = brush, alpha = alpha) }
}

/**
 * 毛笔勾边的气泡形状：圆角矩形的边缘带一点不规则的抖动（每条消息的抖动不同），
 * 像用笔在宣纸上勾出来的。[radii] 依次为 左上 / 右上 / 右下 / 左下 的圆角（dp）。
 */
class InkBubbleShape(
    private val seed: Int,
    private val radii: FloatArray = floatArrayOf(16f, 16f, 16f, 16f),
    private val wobbleDp: Float = 1.3f,
) : Shape {

    private fun noise(i: Int): Float {
        val s = seed * 0.37f
        return (sin(i * 0.83f + s) * 0.55f + sin(i * 2.17f + s * 1.9f) * 0.3f + sin(i * 0.31f + s * 0.7f) * 0.15f)
    }

    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val px = density.density
        val w = size.width
        val h = size.height
        val maxR = min(w, h) / 2f
        val r = FloatArray(4) { (radii[it] * px).coerceAtMost(maxR) }
        val wob = wobbleDp * px
        val step = 10f * px
        val pts = ArrayList<Offset>()
        val nrm = ArrayList<Offset>()

        fun line(x0: Float, y0: Float, x1: Float, y1: Float, n: Offset) {
            val len = kotlin.math.hypot(x1 - x0, y1 - y0)
            val k = max(1, (len / step).toInt())
            for (i in 0 until k) {
                val t = i / k.toFloat()
                pts.add(Offset(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)); nrm.add(n)
            }
        }

        fun arc(cx: Float, cy: Float, rad: Float, startDeg: Float) {
            if (rad < 1f) return
            val k = max(2, ((rad * PI / 2) / step).toInt())
            for (i in 0 until k) {
                val a = Math.toRadians((startDeg + 90f * i / k).toDouble())
                val c = cos(a).toFloat()
                val s = sin(a).toFloat()
                pts.add(Offset(cx + c * rad, cy + s * rad)); nrm.add(Offset(c, s))
            }
        }

        line(r[0], 0f, w - r[1], 0f, Offset(0f, -1f))
        arc(w - r[1], r[1], r[1], -90f)
        line(w, r[1], w, h - r[2], Offset(1f, 0f))
        arc(w - r[2], h - r[2], r[2], 0f)
        line(w - r[2], h, r[3], h, Offset(0f, 1f))
        arc(r[3], h - r[3], r[3], 90f)
        line(0f, h - r[3], 0f, r[0], Offset(-1f, 0f))
        arc(r[0], r[0], r[0], 180f)

        val n = pts.size
        val q = ArrayList<Offset>(n)
        for (i in 0 until n) {
            val d = noise(i) * wob
            // 收进来一点，保证抖动不超出布局边界
            q.add(Offset(pts[i].x + nrm[i].x * (d - wob), pts[i].y + nrm[i].y * (d - wob)))
        }
        val path = Path()
        fun mid(a: Offset, b: Offset) = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
        val start = mid(q[n - 1], q[0])
        path.moveTo(start.x, start.y)
        var prev = start
        for (i in 0 until n) {
            val ctrl = q[i]
            val end = mid(q[i], q[(i + 1) % n])
            // 二次贝塞尔转三次
            val c1 = Offset(prev.x + 2f / 3f * (ctrl.x - prev.x), prev.y + 2f / 3f * (ctrl.y - prev.y))
            val c2 = Offset(end.x + 2f / 3f * (ctrl.x - end.x), end.y + 2f / 3f * (ctrl.y - end.y))
            path.cubicTo(c1.x, c1.y, c2.x, c2.y, end.x, end.y)
            prev = end
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** 沿形状勾一道墨线：主笔 + 错开一点的淡笔，像毛笔的干湿变化。 */
fun Modifier.inkStroke(color: Color, shape: Shape, width: Dp = 1.1.dp): Modifier = this.drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    val sw = width.toPx()
    drawOutline(outline, color = color.copy(alpha = color.alpha * 0.85f), style = Stroke(width = sw))
    translate(left = sw * 0.6f, top = sw * 0.45f) {
        drawOutline(outline, color = color.copy(alpha = color.alpha * 0.30f), style = Stroke(width = sw * 0.7f))
    }
}

// ═════════════════════ 卷轴边框（设置页卡片等） ═════════════════════

/** 卷轴卡片：淡墨细边 + 四角朱砂小点。 */
fun Modifier.scrollFrame(p: DiaPalette, corner: Dp = 14.dp): Modifier = this
    .border(0.8.dp, p.border, RoundedCornerShape(corner))
    .drawBehind {
        val inset = 5.dp.toPx()
        val len = 9.dp.toPx()
        val sw = 1.4.dp.toPx()
        val c = p.ink.copy(alpha = 0.45f)
        drawLine(c, Offset(inset, inset), Offset(inset + len, inset), sw)
        drawLine(c, Offset(inset, inset), Offset(inset, inset + len), sw)
        drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset - len, size.height - inset), sw)
        drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset, size.height - inset - len), sw)
        drawCircle(p.cinnabar.copy(alpha = 0.65f), radius = 2.dp.toPx(), center = Offset(size.width - inset - 1.dp.toPx(), inset + 1.dp.toPx()))
    }

// ═════════════════════ 印章 / 头像 / 插画 / 分隔笔触 ═════════════════════

/** 朱砂印章（方形红底、书法字），用作标志。 */
@Composable
fun SealMark(
    text: String,
    size: Dp = 36.dp,
    color: Color = DiaPal.current.cinnabar,
    textColor: Color = DiaPal.current.onCinnabar,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.16f))
            .background(color)
            .border(1.dp, textColor.copy(alpha = 0.35f), RoundedCornerShape(size * 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(size * 0.84f)
                .border(0.8.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(size * 0.1f)),
            contentAlignment = Alignment.Center,
        ) {
            val chars = text.length
            Text(
                text = if (chars == 4) text.substring(0, 2) + "\n" + text.substring(2) else text,
                color = textColor,
                fontFamily = DiaBrush,
                fontWeight = FontWeight.Normal,
                fontSize = (size.value * when (chars) { 1 -> 0.58f; 2 -> 0.40f; else -> 0.30f }).sp,
                lineHeight = (size.value * 0.34f).sp,
            )
        }
    }
}

/** 侠客头像（灵犀的头像）。主题可以换（图标位 avatar.ai 或主题图片 avatar）。 */
@Composable
fun InkAvatar(size: Dp = 32.dp, modifier: Modifier = Modifier) {
    val pack = LocalThemePack.current
    when (val spec = pack.icons["avatar.ai"]) {
        is IconSpec.Txt -> {
            SealMark(spec.text.take(2), size = size, modifier = modifier)
            return
        }
        else -> Unit
    }
    val path = (pack.icons["avatar.ai"] as? IconSpec.Img)?.path ?: pack.images["avatar"]
    val themed = rememberThemeBitmap(path, 256)
    if (themed != null) {
        Image(bitmap = themed, contentDescription = "灵犀", modifier = modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
        return
    }
    Image(
        painter = painterResource(R.drawable.xia_avatar),
        contentDescription = "灵犀",
        modifier = modifier.size(size).clip(CircleShape),
        contentScale = ContentScale.Crop,
    )
}

/** 月下松间侠客插画（单色墨稿，按主题着色）。 */
@Composable
fun InkHero(p: DiaPalette, modifier: Modifier = Modifier) {
    val pack = LocalThemePack.current
    val themed = rememberThemeBitmap(pack.images["hero"], 900)
    if (themed != null) {
        Image(
            bitmap = themed, contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit,
            colorFilter = if (pack.heroTint) ColorFilter.tint(p.ink.copy(alpha = if (p.isDark) 0.75f else 0.88f)) else null,
        )
        return
    }
    Image(
        painter = painterResource(R.drawable.ink_hero),
        contentDescription = null,
        modifier = modifier,
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(p.ink.copy(alpha = if (p.isDark) 0.75f else 0.88f)),
    )
}

/** 一笔横向墨痕（替代原来的祥云分隔线）。 */
@Composable
fun CloudDivider(p: DiaPalette, modifier: Modifier = Modifier) {
    val pack = LocalThemePack.current
    val themed = rememberThemeBitmap(pack.images["divider"], 1200)
    if (themed != null) {
        Image(
            bitmap = themed, contentDescription = null, modifier = modifier.fillMaxWidth().height(9.dp), contentScale = ContentScale.FillBounds,
            colorFilter = if (pack.dividerTint) ColorFilter.tint(p.ink.copy(alpha = if (p.isDark) 0.35f else 0.45f)) else null,
        )
        return
    }
    Image(
        painter = painterResource(R.drawable.brush_stroke),
        contentDescription = null,
        modifier = modifier.fillMaxWidth().height(7.dp),
        contentScale = ContentScale.FillBounds,
        colorFilter = ColorFilter.tint(p.ink.copy(alpha = if (p.isDark) 0.35f else 0.45f)),
    )
}
