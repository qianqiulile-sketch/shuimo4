package com.dia.app.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.dia.app.R
import com.dia.app.prefs.DiaPrefs

/**
 * Dia's logo — the friendly speech-bubble mark, scaled and centered.
 *
 * Animation is a gentle breathing scale that respects "reduce motion".
 * Use a fixed size param to anchor consistent rendering across the app.
 */
@Composable
fun DiaLogo(
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    animate: Boolean = true,
) {
    val reduceMotion by DiaPrefs.reduceMotion.collectAsState()
    val shouldAnimate = animate && !reduceMotion

    val infiniteTransition = rememberInfiniteTransition(label = "logo")
    val breath by infiniteTransition.animateFloat(
        initialValue = if (shouldAnimate) 0.97f else 1f,
        targetValue = if (shouldAnimate) 1.03f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breath",
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_dia_logo),
            contentDescription = "灵犀 Dia",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = breath
                    scaleY = breath
                }
                .clip(RoundedCornerShape(percent = 24)),
        )
    }
}
