package com.dia.app.home

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal Home Assistant REST API client.
 * Talks to a local HA instance over HTTP.
 */
object HaClient {
    private const val TAG = "HaClient"

    data class HaEntity(
        val entityId: String,
        val state: String,
        val friendlyName: String,
        val domain: String,
    )

    /** Check if HA is reachable. */
    fun ping(baseUrl: String, token: String): Boolean {
        return try {
            val conn = url("$baseUrl/api/").openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "application/json")
            val code = conn.responseCode
            conn.disconnect()
            code == 200
        } catch (e: Exception) {
            Log.w(TAG, "ping failed: ${e.message}")
            false
        }
    }

    /** Get state of a single entity. */
    fun getState(baseUrl: String, token: String, entityId: String): HaEntity? {
        return try {
            val conn = url("$baseUrl/api/states/$entityId").openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "application/json")
            if (conn.responseCode != 200) { conn.disconnect(); return null }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            parseEntity(JSONObject(body))
        } catch (e: Exception) {
            Log.e(TAG, "getState failed: ${e.message}")
            null
        }
    }

    /** List entities, optionally filtered by domain (e.g. "light", "switch"). */
    fun listEntities(baseUrl: String, token: String, domain: String? = null): List<HaEntity> {
        return try {
            val conn = url("$baseUrl/api/states").openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "application/json")
            if (conn.responseCode != 200) { conn.disconnect(); return emptyList() }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val arr = JSONArray(body)
            val result = mutableListOf<HaEntity>()
            for (i in 0 until arr.length()) {
                val entity = parseEntity(arr.getJSONObject(i)) ?: continue
                if (domain == null || entity.domain == domain) result.add(entity)
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "listEntities failed: ${e.message}")
            emptyList()
        }
    }

    /** Call a service (e.g. domain="light", service="turn_on", entityId="light.bedroom"). */
    fun callService(
        baseUrl: String, token: String,
        domain: String, service: String, entityId: String,
        extraData: Map<String, Any>? = null,
    ): Boolean {
        return try {
            val endpoint = "$baseUrl/api/services/$domain/$service"
            val conn = url(endpoint).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "application/json")
            val payload = JSONObject().apply {
                put("entity_id", entityId)
                extraData?.forEach { (k, v) -> put(k, v) }
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray()) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (e: Exception) {
            Log.e(TAG, "callService failed: ${e.message}")
            false
        }
    }

    private fun parseEntity(obj: JSONObject): HaEntity? {
        val entityId = obj.optString("entity_id").ifBlank { return null }
        val state = obj.optString("state", "unknown")
        val attrs = obj.optJSONObject("attributes")
        val friendlyName = attrs?.optString("friendly_name", entityId) ?: entityId
        val domain = entityId.substringBefore('.')
        return HaEntity(entityId, state, friendlyName, domain)
    }

    private fun url(s: String) = URL(s)
}
