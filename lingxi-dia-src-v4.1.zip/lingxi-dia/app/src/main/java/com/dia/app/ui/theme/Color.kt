package com.dia.app.ui.theme

import androidx.compose.ui.graphics.Color

/*
 * 全局固定色（「墨夜」配色）。
 *
 * 老的各个功能页（实时镜头 / 手写板 / 引导 …）直接引用这些常量，
 * 所以这里统一换成中国风的深色：墨色底、朱砂主色、古金、黛青。
 * 新的对话主界面使用 [DiaPalette]（可在 墨夜 / 宣纸 之间切换）。
 */

// ── 底色 & 表面（墨） ──
val DiaBackground = Color(0xFF15110E)
val DiaSurface = Color(0xFF1F1A16)
val DiaSurfaceGlass = Color(0xFF29221C)
val DiaSurfaceElevated = Color(0xFF2E261F)

// ── 主色 ──
/** 朱砂 */
val DiaAccent = Color(0xFFE0533F)
val DiaAccentSoft = Color(0xFFB8432F)
/** 古金 */
val DiaAccentSecondary = Color(0xFFD4A85A)
/** 黛青 */
val DiaAccentTertiary = Color(0xFF5FA392)

// ── 文字（宣纸白） ──
val DiaTextPrimary = Color(0xFFF0E8D8)
val DiaTextSecondary = Color(0xFFB5A88F)
val DiaTextTertiary = Color(0xFF7F7462)

// ── 语义色 ──
val DiaSuccess = Color(0xFF7FB069)
val DiaWarning = Color(0xFFE3A857)
val DiaError = Color(0xFFE5534B)

// ── 效果 ──
val DiaBorder = Color(0x1FD4A85A)
val DiaBorderLight = Color(0x33D4A85A)
val DiaGlow = Color(0x33E0533F)
val DiaShimmer = Color(0x0DF0E8D8)

// ── 各功能色 ──
val DiaChatColor = Color(0xFFE0533F)
val DiaVoiceColor = Color(0xFFB07AA1)
val DiaLensColor = Color(0xFFD9822B)
val DiaGuideColor = Color(0xFF7FB069)
val DiaPilotColor = Color(0xFFD4A85A)
val DiaSlateColor = Color(0xFF5FA392)
val DiaDriveColor = Color(0xFFE5534B)

// ── 实时镜头状态色 ──
val DiaLensListening = Color(0xFF7FB069)
val DiaLensProcessing = Color(0xFFE3A857)
val DiaLensSpeaking = Color(0xFFB07AA1)
