package com.dia.app.files

/**
 * Word / PPT / Excel 的「精细编辑 + 新建」（纯 Kotlin + java.util.zip，可单元测试）。
 *
 * 与 [OfficeXml]（读取 / 查找替换）配合：
 *  - Word：按段落编号改写 / 插入 / 删除；保留原段落与首个文字块的格式；Markdown 追加；Markdown 新建（含标题样式、列表、表格）
 *  - PPT ：按幻灯片顺序读取大纲；改标题 / 正文；复制、删除幻灯片；按大纲新建（水墨配色）
 *  - Excel：按单元格写值 / 公式；追加行；由表格新建
 *  - 通用：按段落批量改写（供 AI 整篇改写使用，结构与格式不变）
 */
object OfficeEdit {

    // ═════════════════════ 通用：段落扫描 ═════════════════════

    class Dialect(
        val p: String, val r: String, val t: String, val pPr: String, val rPr: String,
        val brRe: Regex, val br: String, val tab: String?,
    )

    val WORD = Dialect(
        "w:p", "w:r", "w:t", "w:pPr", "w:rPr",
        Regex("<w:br\\b[^>]*/>|<w:cr\\s*/>"), "<w:br/>", "<w:tab/>",
    )
    val DRAW = Dialect(
        "a:p", "a:r", "a:t", "a:pPr", "a:rPr",
        Regex("<a:br\\b[^>]*/>|<a:br\\b[^>]*>[\\s\\S]*?</a:br>"), "<a:br/>", null,
    )

    data class ParaRange(val start: Int, val end: Int, val selfClosing: Boolean)

    /** 找出所有「叶子段落」（不包含其它段落的段落）的位置，按出现顺序。 */
    fun scanParas(xml: String, d: Dialect): List<ParaRange> {
        val tagRe = Regex("<(/?)${Regex.escape(d.p)}(\\s[^>]*?)?(/?)>")
        val out = ArrayList<ParaRange>()
        // 栈元素：[起点, 是否含子段落(0/1)]
        val stack = ArrayList<IntArray>()
        for (m in tagRe.findAll(xml)) {
            val closing = m.groupValues[1] == "/"
            val selfClose = m.groupValues[3] == "/"
            when {
                closing -> {
                    if (stack.isEmpty()) continue
                    val top = stack.removeAt(stack.size - 1)
                    if (top[1] == 0) out.add(ParaRange(top[0], m.range.last + 1, false))
                    if (stack.isNotEmpty()) stack[stack.size - 1][1] = 1
                }
                selfClose -> {
                    out.add(ParaRange(m.range.first, m.range.last + 1, true))
                    if (stack.isNotEmpty()) stack[stack.size - 1][1] = 1
                }
                else -> stack.add(intArrayOf(m.range.first, 0))
            }
        }
        out.sortBy { it.start }
        return out
    }

    private fun tokenRe(d: Dialect): Regex {
        val t = Regex.escape(d.t)
        val tab = if (d.tab != null) "|" + Regex.escape(d.tab) + "|<w:tab\\s[^>]*/>" else ""
        return Regex("<$t(?:\\s[^>]*)?>([^<]*)</$t>|<$t(?:\\s[^>]*)?/>|${d.brRe.pattern}$tab")
    }

    /** 段落的纯文本（换行用 \n，制表用 \t）。 */
    fun paraText(para: String, d: Dialect): String {
        val sb = StringBuilder()
        for (m in tokenRe(d).findAll(para)) {
            val v = m.value
            when {
                v.startsWith("<${d.t}") -> sb.append(OfficeXml.unescape(m.groupValues[1]))
                d.brRe.matches(v) -> sb.append('\n')
                else -> sb.append('\t')
            }
        }
        return sb.toString()
    }

    private fun firstElement(xml: String, tag: String): String? {
        val e = Regex.escape(tag)
        return Regex("<$e(?:\\s[^>]*)?/>|<$e(?:\\s[^>]*)?>[\\s\\S]*?</$e>").find(xml)?.value
    }

    /** 段落的开标签（自闭合段落返回 `<w:p>`）。 */
    private fun openTag(para: String, d: Dialect, selfClosing: Boolean): String =
        if (selfClosing) "<${d.p}>" else para.substring(0, para.indexOf('>') + 1)

    private fun innerOf(para: String, d: Dialect, selfClosing: Boolean): String {
        if (selfClosing) return ""
        val open = para.indexOf('>') + 1
        val close = para.lastIndexOf("</${d.p}>")
        return if (close >= open) para.substring(open, close) else ""
    }

    /** 段落属性 pPr（没有返回空串）。 */
    fun paraProps(para: String, d: Dialect, selfClosing: Boolean = false): String {
        val inner = innerOf(para, d, selfClosing)
        val pPr = firstElement(inner, d.pPr) ?: return ""
        // pPr 必须是第一个子元素才算段落属性
        return if (inner.trimStart().startsWith("<${d.pPr}")) pPr else ""
    }

    /** 第一个含文字的 run 的 rPr。 */
    private fun firstRunProps(inner: String, d: Dialect): String {
        val rr = Regex.escape(d.r)
        val runRe = Regex("<$rr(?:\\s[^>]*)?>([\\s\\S]*?)</$rr>")
        val runs = runRe.findAll(inner).toList()
        val withText = runs.firstOrNull { it.groupValues[1].contains("<${d.t}") } ?: runs.firstOrNull() ?: return ""
        return firstElement(withText.groupValues[1], d.rPr)?.takeIf { withText.groupValues[1].trimStart().startsWith("<${d.rPr}") }.orEmpty()
    }

    private fun runsXml(text: String, d: Dialect, rPr: String): String {
        val sb = StringBuilder()
        val lines = text.split('\n')
        if (d === WORD) {
            sb.append("<w:r>").append(rPr)
            for ((i, line) in lines.withIndex()) {
                if (i > 0) sb.append("<w:br/>")
                val parts = line.split('\t')
                for ((j, part) in parts.withIndex()) {
                    if (j > 0) sb.append("<w:tab/>")
                    if (part.isNotEmpty()) sb.append("<w:t xml:space=\"preserve\">").append(OfficeXml.escape(part)).append("</w:t>")
                }
            }
            sb.append("</w:r>")
        } else {
            for ((i, line) in lines.withIndex()) {
                if (i > 0) sb.append("<a:br>").append(rPr).append("</a:br>")
                sb.append("<a:r>").append(rPr).append("<a:t>").append(OfficeXml.escape(line)).append("</a:t></a:r>")
            }
        }
        return sb.toString()
    }

    /** 用新文字替换段落内容，保留段落格式和第一个文字块的字体格式。 */
    fun setParaText(para: String, d: Dialect, text: String, selfClosing: Boolean = false): String {
        val open = openTag(para, d, selfClosing)
        val inner = innerOf(para, d, selfClosing)
        val pPr = paraProps(para, d, selfClosing)
        val rest = if (pPr.isNotEmpty()) inner.substring(inner.indexOf(pPr) + pPr.length) else inner
        val rPr = firstRunProps(rest, d)
        val endPara = if (d === DRAW) (firstElement(rest, "a:endParaRPr") ?: "") else ""
        // Word 段落里的书签 / 批注标记之类直接丢弃，只保留文字
        return open + pPr + runsXml(text, d, rPr) + endPara + "</${d.p}>"
    }

    /** 一个 XML 部件里的叶子段落文字。 */
    fun partParagraphs(xml: String, d: Dialect): List<String> =
        scanParas(xml, d).map { paraText(xml.substring(it.start, it.end), d) }

    /**
     * 按序号批量改段落文字（序号对应 [partParagraphs] 的下标）。
     * @return (新 xml, 实际修改数)
     */
    fun mapParagraphs(xml: String, d: Dialect, changes: Map<Int, String>): Pair<String, Int> {
        if (changes.isEmpty()) return xml to 0
        val ranges = scanParas(xml, d)
        val sb = StringBuilder()
        var last = 0
        var n = 0
        for ((i, r) in ranges.withIndex()) {
            val newText = changes[i] ?: continue
            sb.append(xml, last, r.start)
            val para = xml.substring(r.start, r.end)
            sb.append(setParaText(para, d, newText, r.selfClosing))
            last = r.end
            n++
        }
        sb.append(xml, last, xml.length)
        return sb.toString() to n
    }

    // ═════════════════════ DOCX ═════════════════════

    private const val DOC = "word/document.xml"

    /** 正文的全部段落（含表格里的段落），下标从 0 开始。 */
    fun docxParagraphs(bytes: ByteArray): List<String> {
        val xml = OfficeXml.unzip(bytes)[DOC]?.toString(Charsets.UTF_8) ?: return emptyList()
        return partParagraphs(xml, WORD)
    }

    /** 按段落下标批量改写正文（保留格式）。 */
    fun docxMapParagraphs(bytes: ByteArray, changes: Map<Int, String>): Pair<ByteArray, Int> {
        val entries = OfficeXml.unzip(bytes)
        val xml = entries[DOC]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val (nx, n) = mapParagraphs(xml, WORD, changes)
        entries[DOC] = nx.toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries) to n
    }

    /** 编号大纲：「[3] 段落文字」，空段落跳过。给 AI 精确定位用。 */
    fun docxOutline(bytes: ByteArray, maxChars: Int = 8000): String {
        val xml = OfficeXml.unzip(bytes)[DOC]?.toString(Charsets.UTF_8) ?: return ""
        val ranges = scanParas(xml, WORD)
        val sb = StringBuilder()
        for ((i, r) in ranges.withIndex()) {
            val para = xml.substring(r.start, r.end)
            val t = paraText(para, WORD)
            if (t.isBlank()) continue
            val style = Regex("<w:pStyle w:val=\"([^\"]+)\"").find(para)?.groupValues?.get(1)
            val tag = if (style != null && style != "Normal" && style != "a") "〈$style〉" else ""
            val line = "[$i]$tag ${t.replace('\n', '↵')}\n"
            if (sb.length + line.length > maxChars) { sb.append("…（后面还有段落，可用 offset 读取）\n"); break }
            sb.append(line)
        }
        return sb.toString().trimEnd()
    }

    data class ParaOp(val kind: String, val index: Int, val text: String = "")

    /**
     * 段落级编辑：set（改写）/ insert_after / insert_before / delete。
     * insert 的文本按行拆成多个段落，行首 #/##/### 会设为对应标题样式。
     */
    fun docxApply(bytes: ByteArray, ops: List<ParaOp>): Pair<ByteArray, Int> {
        val entries = OfficeXml.unzip(bytes)
        val xml = entries[DOC]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val ranges = scanParas(xml, WORD)
        if (ranges.isEmpty()) throw IllegalArgumentException("文档里没有段落")
        val styleIds = wordStyleIds(entries)
        // 从后往前改，前面段落的位置不受影响
        val sorted = ops.sortedWith(compareByDescending<ParaOp> { it.index }.thenBy { if (it.kind == "delete") 1 else 0 })
        var doc = xml
        var count = 0
        for (op in sorted) {
            val i = if (op.index < 0) ranges.size + op.index else op.index
            if (i !in ranges.indices) throw IllegalArgumentException("段落编号 ${op.index} 超出范围（共 ${ranges.size} 段，编号 0~${ranges.size - 1}）")
            val r = ranges[i]
            val para = doc.substring(r.start, r.end)
            val replacement = when (op.kind) {
                "set", "replace", "rewrite" -> setParaText(para, WORD, op.text, r.selfClosing)
                "delete", "remove" -> ""
                "insert_after", "after", "append_after" -> para + linesToWordParas(op.text, styleIds, paraProps(para, WORD, r.selfClosing))
                "insert_before", "before" -> linesToWordParas(op.text, styleIds, paraProps(para, WORD, r.selfClosing)) + para
                else -> throw IllegalArgumentException("未知段落操作：${op.kind}")
            }
            doc = doc.substring(0, r.start) + replacement + doc.substring(r.end)
            count++
        }
        entries[DOC] = doc.toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries) to count
    }

    /** 读出 styles.xml 中常用样式的 id（中文版 Word 的标题样式 id 往往是 "1" "2"）。 */
    private fun wordStyleIds(entries: Map<String, ByteArray>): Map<String, String> {
        val xml = entries["word/styles.xml"]?.toString(Charsets.UTF_8) ?: return emptyMap()
        val out = HashMap<String, String>()
        val styleRe = Regex("<w:style\\b[^>]*w:styleId=\"([^\"]+)\"[^>]*>([\\s\\S]*?)</w:style>")
        for (m in styleRe.findAll(xml)) {
            val name = Regex("<w:name w:val=\"([^\"]+)\"").find(m.groupValues[2])?.groupValues?.get(1)?.lowercase() ?: continue
            out.putIfAbsent(name, m.groupValues[1])
        }
        return out
    }

    private fun headingPPr(level: Int, styleIds: Map<String, String>): String {
        val id = styleIds["heading $level"] ?: if (styleIds.isEmpty()) "Heading$level" else null
        return if (id != null) "<w:pPr><w:pStyle w:val=\"$id\"/></w:pPr>" else ""
    }

    private fun linesToWordParas(text: String, styleIds: Map<String, String>, basePPr: String): String {
        val sb = StringBuilder()
        // 插入的新段落不继承标题 / 列表样式，避免把正文变成标题
        val inherit = if (basePPr.contains("<w:pStyle") || basePPr.contains("<w:numPr")) "" else basePPr
        for (line in text.split('\n')) {
            val h = Regex("^(#{1,3})\\s+(.*)$").find(line.trim())
            if (h != null) {
                val level = h.groupValues[1].length
                val ppr = headingPPr(level, styleIds)
                val rpr = if (ppr.isEmpty()) "<w:rPr><w:b/><w:sz w:val=\"${36 - level * 4}\"/></w:rPr>" else ""
                sb.append("<w:p>").append(ppr).append(runsXml(h.groupValues[2], WORD, rpr)).append("</w:p>")
            } else {
                sb.append("<w:p>").append(inherit).append(wordInline(line)).append("</w:p>")
            }
        }
        return sb.toString()
    }

    /** 行内 Markdown → Word runs。 */
    private fun wordInline(text: String, base: String = ""): String {
        val sb = StringBuilder()
        for (s in Markdown.spans(text)) {
            val props = StringBuilder()
            if (s.bold) props.append("<w:b/><w:bCs/>")
            if (s.italic) props.append("<w:i/>")
            if (s.code) props.append("<w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"EFE8D8\"/>")
            val rpr = if (props.isEmpty() && base.isEmpty()) "" else "<w:rPr>$base$props</w:rPr>"
            sb.append(runsXml(s.text, WORD, rpr))
        }
        return sb.toString()
    }

    /** body 级 sectPr 前的插入点。 */
    private fun bodyEndIndex(doc: String): Int {
        val bodyEnd = doc.lastIndexOf("</w:body>")
        if (bodyEnd < 0) return -1
        val sect = doc.lastIndexOf("<w:sectPr", bodyEnd)
        if (sect >= 0 && doc.lastIndexOf("</w:p>", bodyEnd) < sect) return sect
        return bodyEnd
    }

    /** 在文末追加 Markdown（标题、列表、表格都会排版）。 */
    fun docxAppendMarkdown(bytes: ByteArray, md: String): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val doc = entries[DOC]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val idx = bodyEndIndex(doc)
        if (idx < 0) throw IllegalArgumentException("文档结构异常")
        val body = mdToWordXml(Markdown.parse(md), wordStyleIds(entries).ifEmpty { DEFAULT_STYLE_IDS })
        entries[DOC] = (doc.substring(0, idx) + body + doc.substring(idx)).toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries)
    }

    /** 用 Markdown 整体重写正文（保留页面设置与样式表）。 */
    fun docxRewriteMarkdown(bytes: ByteArray, md: String): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val doc = entries[DOC]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("不是有效的 Word 文档")
        val bodyOpen = Regex("<w:body(?:\\s[^>]*)?>").find(doc) ?: throw IllegalArgumentException("文档结构异常")
        val start = bodyOpen.range.last + 1
        val end = bodyEndIndex(doc)
        if (end < start) throw IllegalArgumentException("文档结构异常")
        val body = mdToWordXml(Markdown.parse(md), wordStyleIds(entries).ifEmpty { DEFAULT_STYLE_IDS })
        entries[DOC] = (doc.substring(0, start) + body + doc.substring(end)).toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries)
    }

    private val DEFAULT_STYLE_IDS = mapOf(
        "heading 1" to "Heading1", "heading 2" to "Heading2", "heading 3" to "Heading3",
        "title" to "Title", "quote" to "Quote",
    )

    fun mdToWordXml(blocks: List<MdBlock>, styleIds: Map<String, String>): String {
        val sb = StringBuilder()
        for (b in blocks) {
            when (b) {
                is MdBlock.Heading -> {
                    val lv = b.level.coerceIn(1, 3)
                    val ppr = headingPPr(lv, styleIds)
                    val rpr = if (ppr.isEmpty()) "<w:b/><w:sz w:val=\"${36 - lv * 4}\"/>" else ""
                    sb.append("<w:p>").append(ppr).append(wordInline(b.text, rpr)).append("</w:p>")
                }
                is MdBlock.Para -> for (line in b.text.split('\n')) {
                    sb.append("<w:p><w:pPr><w:ind w:firstLineChars=\"200\" w:firstLine=\"480\"/></w:pPr>").append(wordInline(line)).append("</w:p>")
                }
                is MdBlock.Bullet -> {
                    val left = 420 + b.level * 420
                    val mark = if (b.ordered) "${b.number}. " else if (b.level == 0) "• " else "◦ "
                    sb.append("<w:p><w:pPr><w:ind w:left=\"$left\" w:hanging=\"300\"/></w:pPr>")
                        .append(runsXml(mark, WORD, "")).append(wordInline(b.text)).append("</w:p>")
                }
                is MdBlock.Quote -> {
                    val id = styleIds["quote"]
                    val ppr = if (id != null) "<w:pPr><w:pStyle w:val=\"$id\"/><w:ind w:left=\"420\"/></w:pPr>" else "<w:pPr><w:ind w:left=\"420\"/></w:pPr>"
                    sb.append("<w:p>").append(ppr).append(wordInline(b.text, "<w:i/><w:color w:val=\"6B5B45\"/>")).append("</w:p>")
                }
                is MdBlock.Code -> for (line in b.text.split('\n')) {
                    sb.append("<w:p><w:pPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"EFE8D8\"/><w:spacing w:before=\"0\" w:after=\"0\"/></w:pPr>")
                        .append(runsXml(line, WORD, "<w:rPr><w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\"/><w:sz w:val=\"20\"/></w:rPr>")).append("</w:p>")
                }
                is MdBlock.Table -> sb.append(wordTable(b.rows))
                MdBlock.Rule -> sb.append("<w:p><w:pPr><w:pBdr><w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"1\" w:color=\"9A7B3C\"/></w:pBdr></w:pPr></w:p>")
                MdBlock.PageBreak -> sb.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            }
        }
        return sb.toString()
    }

    private fun wordTable(rows: List<List<String>>): String {
        if (rows.isEmpty()) return ""
        val cols = rows.maxOf { it.size }.coerceAtLeast(1)
        val w = 8300 / cols
        val sb = StringBuilder()
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"5000\" w:type=\"pct\"/><w:tblBorders>")
        for (side in listOf("top", "left", "bottom", "right", "insideH", "insideV")) {
            sb.append("<w:$side w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"8C7E6C\"/>")
        }
        sb.append("</w:tblBorders><w:tblLook w:val=\"04A0\" w:firstRow=\"1\"/></w:tblPr><w:tblGrid>")
        repeat(cols) { sb.append("<w:gridCol w:w=\"$w\"/>") }
        sb.append("</w:tblGrid>")
        for ((ri, row) in rows.withIndex()) {
            sb.append("<w:tr>")
            for (ci in 0 until cols) {
                val cell = row.getOrElse(ci) { "" }
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/>")
                if (ri == 0) sb.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"EAE0CA\"/>")
                sb.append("</w:tcPr><w:p><w:pPr><w:spacing w:before=\"40\" w:after=\"40\"/>")
                if (ri == 0) sb.append("<w:jc w:val=\"center\"/>")
                sb.append("</w:pPr>").append(wordInline(cell, if (ri == 0) "<w:b/>" else "")).append("</w:p></w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl><w:p/>")
        return sb.toString()
    }

    /** 由 Markdown 新建 Word：带标题样式、首行缩进、列表、表格，中文字体为宋体 / 黑体。 */
    fun docxCreateMarkdown(md: String, title: String? = null): ByteArray {
        val e = LinkedHashMap<String, ByteArray>()
        fun put(name: String, s: String) { e[name] = s.toByteArray(Charsets.UTF_8) }
        put("[Content_Types].xml", XML_HEAD +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
            "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
            "</Types>")
        put("_rels/.rels", XML_HEAD +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
            "</Relationships>")
        put("docProps/core.xml", XML_HEAD +
            "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" " +
            "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
            "<dc:title>${OfficeXml.escape(title ?: "灵犀文档")}</dc:title><dc:creator>灵犀 Dia</dc:creator></cp:coreProperties>")
        put("word/_rels/document.xml.rels", XML_HEAD +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
            "</Relationships>")
        put("word/styles.xml", WORD_STYLES)
        val blocks = Markdown.parse(md)
        val body = StringBuilder()
        if (!title.isNullOrBlank() && (blocks.firstOrNull() as? MdBlock.Heading)?.text != title) {
            body.append("<w:p><w:pPr><w:pStyle w:val=\"Title\"/></w:pPr>").append(runsXml(title, WORD, "")).append("</w:p>")
        }
        body.append(mdToWordXml(blocks, DEFAULT_STYLE_IDS))
        put(DOC, XML_HEAD +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            "<w:body>$body<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1440\" w:right=\"1588\" w:bottom=\"1440\" w:left=\"1588\" w:header=\"851\" w:footer=\"992\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>")
        return OfficeXml.zip(e)
    }

    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    private val WORD_STYLES = XML_HEAD +
        "<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
        "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:eastAsia=\"宋体\" w:hAnsi=\"Times New Roman\" w:cs=\"Times New Roman\"/>" +
        "<w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:lang w:val=\"en-US\" w:eastAsia=\"zh-CN\"/></w:rPr></w:rPrDefault>" +
        "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"360\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
        "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Title\"><w:name w:val=\"Title\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/>" +
        "<w:pPr><w:jc w:val=\"center\"/><w:spacing w:before=\"240\" w:after=\"360\"/></w:pPr>" +
        "<w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:eastAsia=\"黑体\" w:hAnsi=\"Times New Roman\"/><w:b/><w:sz w:val=\"40\"/><w:szCs w:val=\"40\"/></w:rPr></w:style>" +
        headingStyle(1, 32) + headingStyle(2, 28) + headingStyle(3, 26) +
        "<w:style w:type=\"paragraph\" w:styleId=\"Quote\"><w:name w:val=\"Quote\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/>" +
        "<w:pPr><w:pBdr><w:left w:val=\"single\" w:sz=\"18\" w:space=\"8\" w:color=\"B5372B\"/></w:pBdr></w:pPr>" +
        "<w:rPr><w:rFonts w:eastAsia=\"楷体\"/><w:i/><w:color w:val=\"5E5246\"/></w:rPr></w:style>" +
        "</w:styles>"

    private fun headingStyle(level: Int, size: Int): String =
        "<w:style w:type=\"paragraph\" w:styleId=\"Heading$level\"><w:name w:val=\"heading $level\"/><w:basedOn w:val=\"Normal\"/>" +
            "<w:next w:val=\"Normal\"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before=\"${360 - level * 60}\" w:after=\"120\"/>" +
            "<w:outlineLvl w:val=\"${level - 1}\"/></w:pPr><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:eastAsia=\"黑体\" w:hAnsi=\"Times New Roman\"/>" +
            "<w:b/><w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/>${if (level == 1) "<w:color w:val=\"2B2520\"/>" else ""}</w:rPr></w:style>"

    // ═════════════════════ PPTX ═════════════════════

    /** 按 presentation.xml 里的真实顺序列出幻灯片部件名。 */
    fun slideOrder(entries: Map<String, ByteArray>): List<String> {
        val pres = entries["ppt/presentation.xml"]?.toString(Charsets.UTF_8)
        val rels = entries["ppt/_rels/presentation.xml.rels"]?.toString(Charsets.UTF_8)
        if (pres != null && rels != null) {
            val relMap = HashMap<String, String>()
            for (m in Regex("<Relationship\\b[^>]*>").findAll(rels)) {
                val id = Regex("\\bId=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1) ?: continue
                val target = Regex("\\bTarget=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1) ?: continue
                relMap[id] = target
            }
            val list = Regex("<p:sldId\\b[^>]*r:id=\"([^\"]+)\"").findAll(pres).mapNotNull { m ->
                relMap[m.groupValues[1]]?.let { t -> "ppt/" + t.removePrefix("/ppt/").removePrefix("./") }
            }.filter { it in entries }.toList()
            if (list.isNotEmpty()) return list
        }
        return entries.keys.filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast("slide"))?.value?.toIntOrNull() ?: 0 }
    }

    private data class Shape(val range: IntRange, val xml: String, val ph: String?, val texts: List<String>)

    private fun shapesOf(slide: String): List<Shape> {
        val re = Regex("<p:sp>[\\s\\S]*?</p:sp>|<p:sp\\s[^>]*>[\\s\\S]*?</p:sp>")
        return re.findAll(slide).mapNotNull { m ->
            if (!m.value.contains("<p:txBody")) return@mapNotNull null
            val ph = Regex("<p:ph\\b([^>]*)/?>").find(m.value)?.let { phm ->
                Regex("type=\"([^\"]+)\"").find(phm.groupValues[1])?.groupValues?.get(1) ?: "body"
            }
            val texts = partParagraphs(m.value, DRAW)
            Shape(m.range, m.value, ph, texts)
        }.toList()
    }

    private fun isTitle(ph: String?) = ph == "title" || ph == "ctrTitle"

    /** 大纲：每页的标题、正文、其它文本框。 */
    fun pptxOutline(bytes: ByteArray): String {
        val entries = OfficeXml.unzip(bytes)
        val sb = StringBuilder()
        for ((i, name) in slideOrder(entries).withIndex()) {
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            val shapes = shapesOf(xml)
            sb.append("【第${i + 1}页】\n")
            for (s in shapes) {
                val t = s.texts.filter { it.isNotBlank() }
                if (t.isEmpty()) continue
                val label = when {
                    isTitle(s.ph) -> "标题"
                    s.ph != null -> "正文"
                    else -> "文本框"
                }
                sb.append("  $label：").append(t.joinToString(" / ")).append('\n')
            }
        }
        return sb.toString().trimEnd()
    }

    /** 改某一页（从 1 开始）的标题和 / 或正文（正文每个元素一段）。 */
    fun pptxSetSlide(bytes: ByteArray, slideNo: Int, title: String?, body: List<String>?): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val order = slideOrder(entries)
        val name = order.getOrNull(slideNo - 1) ?: throw IllegalArgumentException("没有第 $slideNo 页（共 ${order.size} 页）")
        var xml = entries.getValue(name).toString(Charsets.UTF_8)
        val shapes = shapesOf(xml)
        if (shapes.isEmpty()) throw IllegalArgumentException("第 $slideNo 页没有可编辑的文本框")
        val titleShape = shapes.firstOrNull { isTitle(it.ph) } ?: shapes.first()
        val bodyShape = shapes.firstOrNull { it !== titleShape && it.ph != null && !isTitle(it.ph) }
            ?: shapes.firstOrNull { it !== titleShape }
        // 从后往前替换，避免下标错位
        val edits = ArrayList<Pair<Shape, String>>()
        if (title != null) edits.add(titleShape to replaceShapeParas(titleShape.xml, listOf(title)))
        if (body != null) {
            if (bodyShape == null) throw IllegalArgumentException("第 $slideNo 页没有正文文本框，只能改标题")
            edits.add(bodyShape to replaceShapeParas(bodyShape.xml, body))
        }
        for ((shape, newXml) in edits.sortedByDescending { it.first.range.first }) {
            xml = xml.substring(0, shape.range.first) + newXml + xml.substring(shape.range.last + 1)
        }
        entries[name] = xml.toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries)
    }

    /** 把文本框的全部段落换成新段落（沿用第一段的格式）。 */
    private fun replaceShapeParas(shape: String, lines: List<String>): String {
        val bodyRe = Regex("(<p:txBody>|<p:txBody\\s[^>]*>)([\\s\\S]*?)(</p:txBody>)")
        val m = bodyRe.find(shape) ?: return shape
        val inner = m.groupValues[2]
        val ranges = scanParas(inner, DRAW)
        val head = if (ranges.isNotEmpty()) inner.substring(0, ranges.first().start) else inner
        val tpl = ranges.firstOrNull()?.let { inner.substring(it.start, it.end) }
        val tplSelf = ranges.firstOrNull()?.selfClosing ?: false
        val sb = StringBuilder()
        for (line in lines.ifEmpty { listOf("") }) {
            val clean = line.trimStart().removePrefix("- ").removePrefix("• ")
            sb.append(if (tpl != null) setParaText(tpl, DRAW, clean, tplSelf) else "<a:p><a:r><a:t>${OfficeXml.escape(clean)}</a:t></a:r></a:p>")
        }
        val tail = if (ranges.isNotEmpty()) inner.substring(ranges.last().end) else ""
        val newInner = head + sb + tail
        return shape.substring(0, m.range.first) + m.groupValues[1] + newInner + m.groupValues[3] + shape.substring(m.range.last + 1)
    }

    private fun relsName(part: String) = part.substringBeforeLast('/') + "/_rels/" + part.substringAfterLast('/') + ".rels"

    /** 删除第 [slideNo] 页（从 1 开始）。 */
    fun pptxDeleteSlide(bytes: ByteArray, slideNo: Int): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val order = slideOrder(entries)
        if (order.size <= 1) throw IllegalArgumentException("只剩一页，不能再删")
        val name = order.getOrNull(slideNo - 1) ?: throw IllegalArgumentException("没有第 $slideNo 页（共 ${order.size} 页）")
        val target = name.removePrefix("ppt/")
        val relsKey = "ppt/_rels/presentation.xml.rels"
        val rels = entries.getValue(relsKey).toString(Charsets.UTF_8)
        val rel = Regex("<Relationship\\b[^>]*Target=\"/?(?:ppt/)?${Regex.escape(target)}\"[^>]*/>").find(rels)
            ?: throw IllegalArgumentException("幻灯片关系缺失")
        val rid = Regex("\\bId=\"([^\"]+)\"").find(rel.value)!!.groupValues[1]
        entries[relsKey] = rels.replace(rel.value, "").toByteArray(Charsets.UTF_8)
        val pres = entries.getValue("ppt/presentation.xml").toString(Charsets.UTF_8)
        entries["ppt/presentation.xml"] = pres.replace(Regex("<p:sldId\\b[^>]*r:id=\"${Regex.escape(rid)}\"[^>]*/>"), "").toByteArray(Charsets.UTF_8)
        entries.remove(name)
        entries.remove(relsName(name))
        val ct = entries.getValue("[Content_Types].xml").toString(Charsets.UTF_8)
        entries["[Content_Types].xml"] = ct.replace(Regex("<Override PartName=\"/${Regex.escape(name)}\"[^>]*/>"), "").toByteArray(Charsets.UTF_8)
        return OfficeXml.zip(entries)
    }

    /**
     * 复制第 [slideNo] 页，插到它后面（或末尾），并可直接改新页的标题 / 正文。
     * @return (新文件, 新页的页码)
     */
    fun pptxDuplicateSlide(bytes: ByteArray, slideNo: Int, title: String? = null, body: List<String>? = null, toEnd: Boolean = false): Pair<ByteArray, Int> {
        val entries = OfficeXml.unzip(bytes)
        val order = slideOrder(entries)
        val src = order.getOrNull(slideNo - 1) ?: throw IllegalArgumentException("没有第 $slideNo 页（共 ${order.size} 页）")
        var n = 1
        while ("ppt/slides/slide$n.xml" in entries) n++
        val newName = "ppt/slides/slide$n.xml"
        entries[newName] = entries.getValue(src)
        // 复制关系，但去掉备注页（避免两页共用一个备注）
        entries[relsName(src)]?.let { r ->
            val s = r.toString(Charsets.UTF_8).replace(Regex("<Relationship\\b[^>]*notesSlide[^>]*/>"), "")
            entries[relsName(newName)] = s.toByteArray(Charsets.UTF_8)
        }
        val ct = entries.getValue("[Content_Types].xml").toString(Charsets.UTF_8)
        entries["[Content_Types].xml"] = ct.replace("</Types>",
            "<Override PartName=\"/$newName\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/></Types>").toByteArray(Charsets.UTF_8)
        val relsKey = "ppt/_rels/presentation.xml.rels"
        val rels = entries.getValue(relsKey).toString(Charsets.UTF_8)
        var ridN = 1
        while (rels.contains("Id=\"rId$ridN\"")) ridN++
        val rid = "rId$ridN"
        entries[relsKey] = rels.replace("</Relationships>",
            "<Relationship Id=\"$rid\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide\" Target=\"slides/slide$n.xml\"/></Relationships>").toByteArray(Charsets.UTF_8)
        var pres = entries.getValue("ppt/presentation.xml").toString(Charsets.UTF_8)
        val ids = Regex("<p:sldId\\b[^>]*\\bid=\"(\\d+)\"").findAll(pres).map { it.groupValues[1].toLong() }.toList()
        val newId = (ids.maxOrNull() ?: 255L) + 1
        val newTag = "<p:sldId id=\"$newId\" r:id=\"$rid\"/>"
        val tags = Regex("<p:sldId\\b[^>]*/>").findAll(pres).toList()
        val newPos: Int
        if (toEnd || slideNo - 1 >= tags.size - 1) {
            pres = pres.replace("</p:sldIdLst>", "$newTag</p:sldIdLst>")
            newPos = tags.size + 1
        } else {
            val after = tags[slideNo - 1]
            pres = pres.substring(0, after.range.last + 1) + newTag + pres.substring(after.range.last + 1)
            newPos = slideNo + 1
        }
        entries["ppt/presentation.xml"] = pres.toByteArray(Charsets.UTF_8)
        var out = OfficeXml.zip(entries)
        if (title != null || body != null) out = pptxSetSlide(out, newPos, title, body)
        return out to newPos
    }

    /** 所有页的叶子段落（按页序）。返回 (部件名, 段落下标, 文字)。 */
    fun pptxParagraphs(bytes: ByteArray): List<Triple<String, Int, String>> {
        val entries = OfficeXml.unzip(bytes)
        val out = ArrayList<Triple<String, Int, String>>()
        for (name in slideOrder(entries)) {
            val xml = entries.getValue(name).toString(Charsets.UTF_8)
            for ((i, t) in partParagraphs(xml, DRAW).withIndex()) out.add(Triple(name, i, t))
        }
        return out
    }

    /** 按 (部件名 → (段落下标 → 新文字)) 批量改写。 */
    fun pptxMapParagraphs(bytes: ByteArray, changes: Map<String, Map<Int, String>>): Pair<ByteArray, Int> {
        val entries = OfficeXml.unzip(bytes)
        var total = 0
        for ((name, m) in changes) {
            val xml = entries[name]?.toString(Charsets.UTF_8) ?: continue
            val (nx, n) = mapParagraphs(xml, DRAW, m)
            entries[name] = nx.toByteArray(Charsets.UTF_8)
            total += n
        }
        return OfficeXml.zip(entries) to total
    }

    data class SlideSpec(val title: String, val bullets: List<String> = emptyList(), val note: String = "")

    /**
     * 大纲 → 幻灯片：`# 标题` 开新的一页，`- 要点` 为正文，`> 文字` 为页脚小字。
     * 第一页若只有标题和一两行文字，做成封面。
     */
    fun parseSlides(md: String): List<SlideSpec> {
        val out = ArrayList<SlideSpec>()
        var title: String? = null
        val bullets = ArrayList<String>()
        var note = ""
        fun flush() {
            val t = title
            if (t != null || bullets.isNotEmpty()) out.add(SlideSpec(t ?: "", bullets.toList(), note))
            title = null; bullets.clear(); note = ""
        }
        for (raw in md.replace("\r\n", "\n").split('\n')) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val h = Regex("^#{1,3}\\s+(.*)$").find(line)
            when {
                h != null -> { flush(); title = Markdown.plain(h.groupValues[1].trim()) }
                line == "---" -> flush()
                line.startsWith(">") -> note = (note + " " + line.trimStart('>').trim()).trim()
                else -> {
                    val b = line.replace(Regex("^([-*+•·]|\\d{1,2}[.、)])\\s*"), "")
                    val indent = raw.length - raw.trimStart().length
                    bullets.add((if (indent >= 2) "　" else "") + Markdown.plain(b))
                }
            }
        }
        flush()
        return out
    }

    fun pptxCreate(slides: List<SlideSpec>, deckTitle: String = "灵犀演示"): ByteArray {
        val list = slides.ifEmpty { listOf(SlideSpec(deckTitle)) }
        val e = LinkedHashMap<String, ByteArray>()
        fun put(name: String, s: String) { e[name] = s.toByteArray(Charsets.UTF_8) }
        val ct = StringBuilder(XML_HEAD)
            .append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
            .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
            .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
            .append("<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>")
            .append("<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>")
            .append("<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>")
            .append("<Override PartName=\"/ppt/slideLayouts/slideLayout2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>")
            .append("<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
            .append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>")
        for (i in list.indices) {
            ct.append("<Override PartName=\"/ppt/slides/slide${i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
        }
        ct.append("</Types>")
        put("[Content_Types].xml", ct.toString())
        put("_rels/.rels", XML_HEAD + "<Relationships xmlns=\"$REL_NS\">" +
            "<Relationship Id=\"rId1\" Type=\"$OFFICE_REL/officeDocument\" Target=\"ppt/presentation.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
            "</Relationships>")
        put("docProps/core.xml", XML_HEAD +
            "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>${OfficeXml.escape(deckTitle)}</dc:title><dc:creator>灵犀 Dia</dc:creator></cp:coreProperties>")
        val sldIds = StringBuilder()
        val presRels = StringBuilder(XML_HEAD).append("<Relationships xmlns=\"$REL_NS\">")
            .append("<Relationship Id=\"rId1\" Type=\"$OFFICE_REL/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>")
            .append("<Relationship Id=\"rId2\" Type=\"$OFFICE_REL/theme\" Target=\"theme/theme1.xml\"/>")
        for (i in list.indices) {
            sldIds.append("<p:sldId id=\"${256 + i}\" r:id=\"rId${i + 3}\"/>")
            presRels.append("<Relationship Id=\"rId${i + 3}\" Type=\"$OFFICE_REL/slide\" Target=\"slides/slide${i + 1}.xml\"/>")
        }
        presRels.append("</Relationships>")
        put("ppt/presentation.xml", XML_HEAD + "<p:presentation $PNS saveSubsetFonts=\"1\">" +
            "<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst>" +
            "<p:sldIdLst>$sldIds</p:sldIdLst><p:sldSz cx=\"$SW\" cy=\"$SH\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>")
        put("ppt/_rels/presentation.xml.rels", presRels.toString())
        put("ppt/slideMasters/slideMaster1.xml", MASTER)
        put("ppt/slideMasters/_rels/slideMaster1.xml.rels", XML_HEAD + "<Relationships xmlns=\"$REL_NS\">" +
            "<Relationship Id=\"rId1\" Type=\"$OFFICE_REL/slideLayout\" Target=\"../slideLayouts/slideLayout1.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"$OFFICE_REL/slideLayout\" Target=\"../slideLayouts/slideLayout2.xml\"/>" +
            "<Relationship Id=\"rId3\" Type=\"$OFFICE_REL/theme\" Target=\"../theme/theme1.xml\"/></Relationships>")
        put("ppt/slideLayouts/slideLayout1.xml", layout("title", "封面", listOf(
            phShape(2, "标题", "ctrTitle", null, 838200, 2286000, 10515600, 1371600),
            phShape(3, "副标题", "subTitle", 1, 838200, 3810000, 10515600, 914400),
        )))
        put("ppt/slideLayouts/slideLayout2.xml", layout("obj", "标题和内容", listOf(
            phShape(2, "标题", "title", null, 838200, 457200, 10515600, 1005840),
            phShape(3, "内容", null, 1, 838200, 1645920, 10515600, 4480560),
        )))
        val layoutRel = XML_HEAD + "<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OFFICE_REL/slideMaster\" Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>"
        put("ppt/slideLayouts/_rels/slideLayout1.xml.rels", layoutRel)
        put("ppt/slideLayouts/_rels/slideLayout2.xml.rels", layoutRel)
        put("ppt/theme/theme1.xml", THEME)
        for ((i, s) in list.withIndex()) {
            val cover = i == 0 && s.bullets.size <= 2 && list.size > 1
            put("ppt/slides/slide${i + 1}.xml", slideXml(s, cover))
            put("ppt/slides/_rels/slide${i + 1}.xml.rels", XML_HEAD + "<Relationships xmlns=\"$REL_NS\">" +
                "<Relationship Id=\"rId1\" Type=\"$OFFICE_REL/slideLayout\" Target=\"../slideLayouts/slideLayout${if (cover) 1 else 2}.xml\"/></Relationships>")
        }
        return OfficeXml.zip(e)
    }

    private const val SW = 12192000L
    private const val SH = 6858000L
    private const val REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val OFFICE_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PNS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\""
    private const val INK = "2B2520"
    private const val CINNABAR = "B5372B"
    private const val GOLD = "9A7B3C"
    private const val PAPER = "F4EEDF"
    private const val GRP = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
        "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>"

    private fun phShape(id: Int, name: String, type: String?, idx: Int?, x: Long, y: Long, w: Long, h: Long): String {
        val ph = buildString {
            append("<p:ph")
            if (type != null) append(" type=\"$type\"")
            if (idx != null) append(" idx=\"$idx\"")
            append("/>")
        }
        return "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"$name\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr>$ph</p:nvPr></p:nvSpPr>" +
            "<p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm></p:spPr>" +
            "<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang=\"zh-CN\"/></a:p></p:txBody></p:sp>"
    }

    private fun layout(type: String, name: String, shapes: List<String>): String =
        XML_HEAD + "<p:sldLayout $PNS type=\"$type\" preserve=\"1\"><p:cSld name=\"$name\"><p:spTree>$GRP${shapes.joinToString("")}</p:spTree></p:cSld>" +
            "<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"

    private fun rect(id: Int, name: String, x: Long, y: Long, w: Long, h: Long, color: String, alpha: Int = 100000): String =
        "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"$name\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>" +
            "<a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>" +
            "<a:solidFill><a:srgbClr val=\"$color\">${if (alpha < 100000) "<a:alpha val=\"$alpha\"/>" else ""}</a:srgbClr></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr>" +
            "<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang=\"zh-CN\"/></a:p></p:txBody></p:sp>"

    private fun textBox(id: Int, name: String, ph: String, x: Long, y: Long, w: Long, h: Long, paras: String, anchor: String = "t"): String =
        "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"$name\"/><p:cNvSpPr${if (ph.isEmpty()) " txBox=\"1\"" else ""}>" +
            "${if (ph.isNotEmpty()) "<a:spLocks noGrp=\"1\"/>" else ""}</p:cNvSpPr><p:nvPr>$ph</p:nvPr></p:nvSpPr>" +
            "<p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/><a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>" +
            "<p:txBody><a:bodyPr wrap=\"square\" anchor=\"$anchor\"><a:normAutofit/></a:bodyPr><a:lstStyle/>$paras</p:txBody></p:sp>"

    private fun run(text: String, size: Int, color: String, bold: Boolean = false, font: String = "微软雅黑"): String =
        "<a:r><a:rPr lang=\"zh-CN\" sz=\"$size\"${if (bold) " b=\"1\"" else ""} dirty=\"0\"><a:solidFill><a:srgbClr val=\"$color\"/></a:solidFill>" +
            "<a:latin typeface=\"$font\"/><a:ea typeface=\"$font\"/></a:rPr><a:t>${OfficeXml.escape(text)}</a:t></a:r>"

    private fun slideXml(s: SlideSpec, cover: Boolean): String {
        val sb = StringBuilder(XML_HEAD).append("<p:sld $PNS><p:cSld><p:spTree>").append(GRP)
        if (cover) {
            sb.append(rect(10, "墨带", 0, 3200400, SW, 60000, INK, 85000))
            sb.append(rect(11, "朱砂印", 10668000, 685800, 685800, 685800, CINNABAR))
            sb.append(textBox(12, "印文", "", 10668000, 685800, 685800, 685800,
                "<a:p><a:pPr algn=\"ctr\"/>${run("灵犀", 2000, "FFF6EA", true, "楷体")}</a:p>", "ctr"))
            sb.append(textBox(2, "标题", "<p:ph type=\"ctrTitle\"/>", 838200, 1600200, 10515600, 1463040,
                "<a:p><a:pPr algn=\"ctr\"/>${run(s.title.ifBlank { "灵犀演示" }, 4800, INK, true, "楷体")}</a:p>", "b"))
            val sub = s.bullets.joinToString("  ·  ").ifBlank { s.note }
            sb.append(textBox(3, "副标题", "<p:ph type=\"subTitle\" idx=\"1\"/>", 838200, 3474720, 10515600, 914400,
                "<a:p><a:pPr marL=\"0\" indent=\"0\" algn=\"ctr\"><a:buNone/></a:pPr>${run(sub, 2000, "5E5246")}</a:p>"))
        } else {
            sb.append(rect(10, "朱砂竖线", 457200, 548640, 76200, 822960, CINNABAR))
            sb.append(textBox(2, "标题", "<p:ph type=\"title\"/>", 685800, 457200, 10820400, 1005840,
                "<a:p>${run(s.title, 3200, INK, true, "楷体")}</a:p>", "ctr"))
            sb.append(rect(11, "金线", 685800, 1508760, 10820400, 12700, GOLD, 70000))
            val paras = StringBuilder()
            val items = s.bullets.ifEmpty { listOf(" ") }
            val size = when {
                items.size > 9 -> 1600
                items.size > 6 -> 1800
                else -> 2200
            }
            for (b in items) {
                val sub = b.startsWith("　")
                val text = b.trimStart('　')
                paras.append("<a:p><a:pPr marL=\"${if (sub) 685800 else 342900}\" indent=\"-285750\">")
                    .append("<a:spcBef><a:spcPts val=\"600\"/></a:spcBef>")
                    .append("<a:buClr><a:srgbClr val=\"$CINNABAR\"/></a:buClr><a:buFont typeface=\"Arial\"/><a:buChar char=\"${if (sub) "–" else "•"}\"/></a:pPr>")
                    .append(run(text, if (sub) size - 200 else size, if (sub) "5E5246" else INK)).append("</a:p>")
            }
            sb.append(textBox(3, "内容", "<p:ph idx=\"1\"/>", 685800, 1645920, 10820400, 4480560, paras.toString()))
            if (s.note.isNotBlank()) {
                sb.append(textBox(12, "注", "", 685800, 6172200, 9144000, 457200,
                    "<a:p>${run(s.note, 1200, "8C7E6C")}</a:p>"))
            }
        }
        sb.append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>")
        return sb.toString()
    }

    private val MASTER = XML_HEAD + "<p:sldMaster $PNS><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"$PAPER\"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>" +
        "<p:spTree>$GRP" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"标题占位符\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr>" +
        "<p:spPr><a:xfrm><a:off x=\"838200\" y=\"365125\"/><a:ext cx=\"10515600\" cy=\"1325563\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr anchor=\"ctr\"/><a:lstStyle/><a:p><a:endParaRPr lang=\"zh-CN\"/></a:p></p:txBody></p:sp>" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"文本占位符\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"body\" idx=\"1\"/></p:nvPr></p:nvSpPr>" +
        "<p:spPr><a:xfrm><a:off x=\"838200\" y=\"1825625\"/><a:ext cx=\"10515600\" cy=\"4351338\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang=\"zh-CN\"/></a:p></p:txBody></p:sp>" +
        "</p:spTree></p:cSld>" +
        "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
        "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/><p:sldLayoutId id=\"2147483650\" r:id=\"rId2\"/></p:sldLayoutIdLst>" +
        "<p:txStyles>" +
        "<p:titleStyle><a:lvl1pPr algn=\"l\"><a:defRPr sz=\"3600\" b=\"1\"><a:solidFill><a:srgbClr val=\"$INK\"/></a:solidFill><a:latin typeface=\"+mj-lt\"/><a:ea typeface=\"+mj-ea\"/></a:defRPr></a:lvl1pPr></p:titleStyle>" +
        "<p:bodyStyle><a:lvl1pPr marL=\"342900\" indent=\"-342900\"><a:buChar char=\"•\"/><a:defRPr sz=\"2200\"><a:solidFill><a:srgbClr val=\"$INK\"/></a:solidFill><a:latin typeface=\"+mn-lt\"/><a:ea typeface=\"+mn-ea\"/></a:defRPr></a:lvl1pPr>" +
        "<a:lvl2pPr marL=\"742950\" indent=\"-285750\"><a:buChar char=\"–\"/><a:defRPr sz=\"2000\"><a:solidFill><a:srgbClr val=\"5E5246\"/></a:solidFill></a:defRPr></a:lvl2pPr></p:bodyStyle>" +
        "<p:otherStyle><a:lvl1pPr><a:defRPr sz=\"1800\"><a:solidFill><a:srgbClr val=\"$INK\"/></a:solidFill></a:defRPr></a:lvl1pPr></p:otherStyle>" +
        "</p:txStyles></p:sldMaster>"

    private val THEME = XML_HEAD + "<a:theme xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" name=\"水墨\"><a:themeElements>" +
        "<a:clrScheme name=\"水墨\"><a:dk1><a:srgbClr val=\"$INK\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1>" +
        "<a:dk2><a:srgbClr val=\"3E3530\"/></a:dk2><a:lt2><a:srgbClr val=\"$PAPER\"/></a:lt2>" +
        "<a:accent1><a:srgbClr val=\"$CINNABAR\"/></a:accent1><a:accent2><a:srgbClr val=\"$GOLD\"/></a:accent2>" +
        "<a:accent3><a:srgbClr val=\"3E6E64\"/></a:accent3><a:accent4><a:srgbClr val=\"5B8A3E\"/></a:accent4>" +
        "<a:accent5><a:srgbClr val=\"6B5B45\"/></a:accent5><a:accent6><a:srgbClr val=\"8C7E6C\"/></a:accent6>" +
        "<a:hlink><a:srgbClr val=\"3E6E64\"/></a:hlink><a:folHlink><a:srgbClr val=\"6B5B45\"/></a:folHlink></a:clrScheme>" +
        "<a:fontScheme name=\"水墨\"><a:majorFont><a:latin typeface=\"Georgia\"/><a:ea typeface=\"楷体\"/><a:cs typeface=\"\"/></a:majorFont>" +
        "<a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"微软雅黑\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
        "<a:fmtScheme name=\"水墨\"><a:fillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"><a:tint val=\"50000\"/></a:schemeClr></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"><a:shade val=\"80000\"/></a:schemeClr></a:solidFill></a:fillStyleLst>" +
        "<a:lnStyleLst><a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>" +
        "<a:ln w=\"12700\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>" +
        "<a:ln w=\"19050\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln></a:lnStyleLst>" +
        "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>" +
        "<a:bgFillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"><a:tint val=\"95000\"/></a:schemeClr></a:solidFill>" +
        "<a:solidFill><a:schemeClr val=\"phClr\"><a:shade val=\"90000\"/></a:schemeClr></a:solidFill></a:bgFillStyleLst></a:fmtScheme>" +
        "</a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>"

    // ═════════════════════ XLSX ═════════════════════

    private fun sheetTargets(entries: Map<String, ByteArray>): List<Pair<String, String>> {
        val wb = entries["xl/workbook.xml"]?.toString(Charsets.UTF_8) ?: return emptyList()
        val rels = entries["xl/_rels/workbook.xml.rels"]?.toString(Charsets.UTF_8).orEmpty()
        val relMap = HashMap<String, String>()
        for (m in Regex("<Relationship\\b[^>]*>").findAll(rels)) {
            val id = Regex("\\bId=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1) ?: continue
            val t = Regex("\\bTarget=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1) ?: continue
            relMap[id] = if (t.startsWith("/")) t.removePrefix("/") else "xl/" + t.removePrefix("./")
        }
        return Regex("<sheet\\b[^>]*/>").findAll(wb).mapNotNull { m ->
            val name = Regex("\\bname=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1)?.let { OfficeXml.unescape(it) } ?: return@mapNotNull null
            val rid = Regex("\\br:id=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1)
            val target = rid?.let { relMap[it] } ?: return@mapNotNull null
            name to target
        }.toList()
    }

    private fun resolveSheet(entries: Map<String, ByteArray>, sheet: String?): String {
        val list = sheetTargets(entries)
        if (list.isEmpty()) {
            return entries.keys.firstOrNull { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) }
                ?: throw IllegalArgumentException("不是有效的 Excel 文件")
        }
        if (sheet.isNullOrBlank()) return list.first().second
        sheet.toIntOrNull()?.let { n -> list.getOrNull(n - 1)?.let { return it.second } }
        return list.firstOrNull { it.first == sheet }?.second
            ?: list.firstOrNull { it.first.contains(sheet, true) }?.second
            ?: throw IllegalArgumentException("没有名为「$sheet」的工作表（有：${list.joinToString("、") { it.first }}）")
    }

    fun colIndex(letters: String): Int {
        var n = 0
        for (c in letters.uppercase()) n = n * 26 + (c - 'A' + 1)
        return n
    }

    fun colLetters(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.append('A' + r)
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    private fun cellXml(ref: String, value: String, style: String?): String {
        val s = if (style != null) " s=\"$style\"" else ""
        val v = value.trim()
        return when {
            v.startsWith("=") && v.length > 1 -> "<c r=\"$ref\"$s><f>${OfficeXml.escape(v.substring(1))}</f></c>"
            v.isNotEmpty() && v.matches(Regex("-?\\d{1,15}(\\.\\d+)?")) -> "<c r=\"$ref\"$s><v>$v</v></c>"
            v.isEmpty() -> "<c r=\"$ref\"$s/>"
            else -> "<c r=\"$ref\"$s t=\"inlineStr\"><is><t xml:space=\"preserve\">${OfficeXml.escape(value)}</t></is></c>"
        }
    }

    /** 写入若干单元格，如 {"B3":"120", "C3":"=B3*2", "A1":"标题"}。 */
    fun xlsxSetCells(bytes: ByteArray, sheet: String?, cells: Map<String, String>): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val part = resolveSheet(entries, sheet)
        var xml = entries[part]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("工作表缺失")
        for ((rawRef, value) in cells) {
            val ref = rawRef.trim().uppercase()
            val m = Regex("^([A-Z]{1,3})(\\d{1,7})$").find(ref) ?: throw IllegalArgumentException("单元格地址无效：$rawRef")
            val col = colIndex(m.groupValues[1])
            val row = m.groupValues[2].toInt()
            xml = setCellInSheet(xml, ref, col, row, value)
        }
        entries[part] = xml.toByteArray(Charsets.UTF_8)
        if (cells.values.any { it.trim().startsWith("=") }) {
            entries.remove("xl/calcChain.xml")
            entries["xl/workbook.xml"]?.let { wb ->
                var s = wb.toString(Charsets.UTF_8)
                s = when {
                    s.contains("fullCalcOnLoad") -> s
                    s.contains("<calcPr") -> s.replace(Regex("<calcPr\\b([^>]*?)/>"), "<calcPr$1 fullCalcOnLoad=\"1\"/>")
                    else -> s.replace("</workbook>", "<calcPr fullCalcOnLoad=\"1\"/></workbook>")
                }
                entries["xl/workbook.xml"] = s.toByteArray(Charsets.UTF_8)
            }
            entries["[Content_Types].xml"]?.let { c ->
                entries["[Content_Types].xml"] = c.toString(Charsets.UTF_8)
                    .replace(Regex("<Override PartName=\"/xl/calcChain.xml\"[^>]*/>"), "").toByteArray(Charsets.UTF_8)
            }
            entries["xl/_rels/workbook.xml.rels"]?.let { r ->
                entries["xl/_rels/workbook.xml.rels"] = r.toString(Charsets.UTF_8)
                    .replace(Regex("<Relationship\\b[^>]*calcChain[^>]*/>"), "").toByteArray(Charsets.UTF_8)
            }
        }
        return OfficeXml.zip(entries)
    }

    private fun setCellInSheet(xml: String, ref: String, col: Int, row: Int, value: String): String {
        val sdOpen = Regex("<sheetData\\s*/>|<sheetData(?:\\s[^>]*)?>").find(xml) ?: throw IllegalArgumentException("工作表结构异常")
        var doc = xml
        if (sdOpen.value.endsWith("/>")) {
            doc = doc.replaceRange(sdOpen.range, "<sheetData></sheetData>")
        }
        val rowRe = Regex("<row\\b[^>]*\\br=\"$row\"[^>]*?(?:/>|>[\\s\\S]*?</row>)")
        val rowM = rowRe.find(doc)
        if (rowM == null) {
            // 找到第一个行号更大的行，插在它前面
            val all = Regex("<row\\b[^>]*\\br=\"(\\d+)\"").findAll(doc).toList()
            val next = all.firstOrNull { it.groupValues[1].toInt() > row }
            val newRow = "<row r=\"$row\">${cellXml(ref, value, null)}</row>"
            return if (next != null) doc.substring(0, next.range.first) + newRow + doc.substring(next.range.first)
            else doc.replace("</sheetData>", "$newRow</sheetData>")
        }
        var rowXml = rowM.value
        if (rowXml.endsWith("/>")) rowXml = rowXml.dropLast(2) + "></row>"
        val cellRe = Regex("<c\\b[^>]*\\br=\"$ref\"[^>]*?(?:/>|>[\\s\\S]*?</c>)")
        val cm = cellRe.find(rowXml)
        rowXml = if (cm != null) {
            val style = Regex("\\bs=\"(\\d+)\"").find(cm.value.substringBefore('>'))?.groupValues?.get(1)
            rowXml.replaceRange(cm.range, cellXml(ref, value, style))
        } else {
            val cells = Regex("<c\\b[^>]*\\br=\"([A-Z]+)\\d+\"").findAll(rowXml).toList()
            val next = cells.firstOrNull { colIndex(it.groupValues[1]) > col }
            val nc = cellXml(ref, value, null)
            if (next != null) rowXml.substring(0, next.range.first) + nc + rowXml.substring(next.range.first)
            else rowXml.substring(0, rowXml.lastIndexOf("</row>")) + nc + "</row>"
        }
        // 去掉 spans 提示，避免与新列冲突
        rowXml = rowXml.replaceFirst(Regex("\\sspans=\"[^\"]*\""), "")
        return doc.replaceRange(rowM.range, rowXml)
    }

    /** 在工作表末尾追加若干行。 */
    fun xlsxAppendRows(bytes: ByteArray, sheet: String?, rows: List<List<String>>): ByteArray {
        val entries = OfficeXml.unzip(bytes)
        val part = resolveSheet(entries, sheet)
        val xml = entries[part]?.toString(Charsets.UTF_8) ?: throw IllegalArgumentException("工作表缺失")
        val last = Regex("<row\\b[^>]*\\br=\"(\\d+)\"").findAll(xml).maxOfOrNull { it.groupValues[1].toInt() } ?: 0
        val cells = LinkedHashMap<String, String>()
        for ((ri, r) in rows.withIndex()) for ((ci, v) in r.withIndex()) {
            if (v.isNotEmpty()) cells["${colLetters(ci + 1)}${last + 1 + ri}"] = v
        }
        return xlsxSetCells(bytes, sheet, cells)
    }

    /** 新建 Excel：每个工作表一张表格，首行加粗并冻结。 */
    fun xlsxCreate(sheets: List<Pair<String, List<List<String>>>>): ByteArray {
        val list = sheets.ifEmpty { listOf("Sheet1" to emptyList()) }
        val e = LinkedHashMap<String, ByteArray>()
        fun put(name: String, s: String) { e[name] = s.toByteArray(Charsets.UTF_8) }
        val ct = StringBuilder(XML_HEAD).append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
            .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
            .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
            .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
            .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
        val sheetTags = StringBuilder()
        val rels = StringBuilder(XML_HEAD).append("<Relationships xmlns=\"$REL_NS\">")
        val usedNames = HashSet<String>()
        for ((i, s) in list.withIndex()) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet${i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            var name = s.first.replace(Regex("[\\\\/?*\\[\\]:]"), "_").take(31).ifBlank { "Sheet${i + 1}" }
            while (!usedNames.add(name)) name = (name.take(28) + "_${i + 1}")
            sheetTags.append("<sheet name=\"${OfficeXml.escape(name)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>")
            rels.append("<Relationship Id=\"rId${i + 1}\" Type=\"$OFFICE_REL/worksheet\" Target=\"worksheets/sheet${i + 1}.xml\"/>")
            put("xl/worksheets/sheet${i + 1}.xml", sheetXml(s.second))
        }
        rels.append("<Relationship Id=\"rId${list.size + 1}\" Type=\"$OFFICE_REL/styles\" Target=\"styles.xml\"/></Relationships>")
        ct.append("</Types>")
        put("[Content_Types].xml", ct.toString())
        put("_rels/.rels", XML_HEAD + "<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OFFICE_REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        put("xl/workbook.xml", XML_HEAD + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
            "xmlns:r=\"$OFFICE_REL\"><sheets>$sheetTags</sheets><calcPr fullCalcOnLoad=\"1\"/></workbook>")
        put("xl/_rels/workbook.xml.rels", rels.toString())
        put("xl/styles.xml", XML_HEAD + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"等线\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FF2B2520\"/><name val=\"等线\"/></font></fonts>" +
            "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>" +
            "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFEAE0CA\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
            "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>" +
            "<border><left style=\"thin\"><color rgb=\"FFB5A88F\"/></left><right style=\"thin\"><color rgb=\"FFB5A88F\"/></right>" +
            "<top style=\"thin\"><color rgb=\"FFB5A88F\"/></top><bottom style=\"thin\"><color rgb=\"FFB5A88F\"/></bottom><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf></cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>")
        return OfficeXml.zip(e)
    }

    private fun sheetXml(rows: List<List<String>>): String {
        val cols = rows.maxOfOrNull { it.size } ?: 0
        val sb = StringBuilder(XML_HEAD).append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$OFFICE_REL\">")
        if (rows.size > 1) {
            sb.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>")
        }
        if (cols > 0) {
            sb.append("<cols>")
            for (c in 1..cols) {
                val maxLen = rows.maxOf { r -> r.getOrNull(c - 1)?.let { v -> v.sumOf { ch -> if (ch.code > 0x2E80) 2 else 1 } } ?: 0 }
                val w = (maxLen + 2).coerceIn(8, 50)
                sb.append("<col min=\"$c\" max=\"$c\" width=\"$w\" customWidth=\"1\"/>")
            }
            sb.append("</cols>")
        }
        sb.append("<sheetData>")
        for ((ri, r) in rows.withIndex()) {
            sb.append("<row r=\"${ri + 1}\">")
            for ((ci, v) in r.withIndex()) {
                sb.append(cellXml("${colLetters(ci + 1)}${ri + 1}", v, if (ri == 0 && rows.size > 1) "1" else "2"))
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    /** Markdown（多个 `## 表名` + 表格）或 CSV → 多个工作表。 */
    fun parseSheets(content: String, defaultName: String = "Sheet1"): List<Pair<String, List<List<String>>>> {
        val blocks = Markdown.parse(content)
        val tables = ArrayList<Pair<String, List<List<String>>>>()
        var pendingName: String? = null
        for (b in blocks) {
            when (b) {
                is MdBlock.Heading -> pendingName = b.text
                is MdBlock.Table -> {
                    tables.add((pendingName ?: if (tables.isEmpty()) defaultName else "Sheet${tables.size + 1}") to b.rows.map { r -> r.map { Markdown.plain(it) } })
                    pendingName = null
                }
                else -> Unit
            }
        }
        if (tables.isNotEmpty()) return tables
        return listOf(defaultName to Markdown.parseTable(content))
    }
}
