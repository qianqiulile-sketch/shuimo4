package com.dia.app.agent

import com.dia.app.files.FileManager
import com.dia.app.files.FileRef
import com.dia.app.files.OfficeEdit
import com.dia.app.files.OfficeXml
import com.dia.app.files.PdfTools
import com.dia.app.files.TextDecode
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * 文档工具：Word / PPT / Excel / PDF / 文本的精细编辑、整篇 AI 改写（保留格式）、
 * PDF 页面操作与格式转换。所有覆盖原文件的修改都会先自动备份。
 */
object DocTools {

    private fun JSONObject.str(vararg keys: String): String {
        for (k in keys) {
            val v = opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    private fun JSONObject.text(vararg keys: String): String {
        for (k in keys) if (has(k) && !isNull(k)) return optString(k)
        return ""
    }

    private fun JSONObject.intOr(key: String, def: Int): Int = when (val v = opt(key)) {
        is Number -> v.toInt()
        is String -> v.trim().toIntOrNull() ?: def
        else -> def
    }

    private fun need(key: String): Pair<FileRef?, ToolOutcome?> {
        val ref = FileManager.find(key)
        return if (ref == null) null to ToolOutcome("找不到文件「$key」。请先让用户点 ＋ →「文件」选择，或用 list_files / 路径指定。", ok = false)
        else ref to null
    }

    private fun lines(v: Any?): List<String>? = when (v) {
        null, JSONObject.NULL -> null
        is JSONArray -> (0 until v.length()).map { v.optString(it) }
        is String -> v.split('\n').filter { it.isNotBlank() }
        else -> listOf(v.toString())
    }

    // ───────── 大纲 ─────────

    suspend fun outline(args: JSONObject, host: ToolHost): ToolOutcome {
        val (ref, err) = need(args.str("file", "id", "path", "name"))
        if (ref == null) return err!!
        host.progress("正在分析 ${ref.name} 的结构…")
        val text = withContext(Dispatchers.IO) {
            val bytes = FileManager.readBytes(ref)
            when (ref.ext) {
                "docx" -> "Word 段落（[编号] 用于 edit_file 的 index）：\n" + OfficeEdit.docxOutline(bytes, 9000)
                "pptx" -> "PPT 大纲（页码用于 edit_file 的 slide）：\n" + OfficeEdit.pptxOutline(bytes)
                "xlsx" -> "Excel 内容（列 A、B、C… 行 1、2、3…）：\n" + OfficeXml.xlsxText(bytes, 200)
                "pdf" -> PdfTools.pageTexts(bytes, 60).withIndex().joinToString("\n\n") { (i, t) ->
                    "【第${i + 1}页】" + t.take(600) + if (t.length > 600) "…" else ""
                }
                else -> TextDecode.decode(bytes).lines().take(400).withIndex().joinToString("\n") { (i, l) -> "${i + 1}| $l" }
            }
        }
        return ToolOutcome("《${ref.name}》\n" + text.take(12000), display = text.take(2000))
    }

    // ───────── 精细编辑 ─────────

    suspend fun edit(args: JSONObject, host: ToolHost): ToolOutcome {
        val (ref, err) = need(args.str("file", "id", "path", "name"))
        if (ref == null) return err!!
        val action = args.str("action", "mode", "op").lowercase().ifBlank {
            when {
                args.has("ops") -> "ops"
                args.has("cells") -> "set_cells"
                args.has("slide") -> "set_slide"
                args.has("index") -> "set_paragraph"
                args.str("find", "old").isNotBlank() -> "replace"
                else -> "append"
            }
        }
        return when (ref.ext) {
            "docx" -> editDocx(ref, action, args, host)
            "pptx" -> editPptx(ref, action, args, host)
            "xlsx" -> editXlsx(ref, action, args, host)
            "pdf" -> ToolOutcome("PDF 不能逐字修改。可用 rewrite_file 改写后生成新 PDF，或 pdf_tool 处理页面、转 Word 后再改。", ok = false)
            else -> basicEdit(ref, action, args, host)
        }
    }

    /** 文本 / 通用：replace / append / rewrite。 */
    private suspend fun basicEdit(ref: FileRef, action: String, args: JSONObject, host: ToolHost): ToolOutcome {
        val act = when (action) {
            "replace", "替换" -> "replace"
            "rewrite", "overwrite", "重写" -> "rewrite"
            else -> "append"
        }
        val find = args.str("find", "old", "from", "search")
        val text = args.text("text", "new", "content", "to")
        val summary = withContext(Dispatchers.IO) { FileManager.previewEdit(ref, act, find, text) }
        if (!host.confirm("允许修改文件「${ref.name}」？", "$summary\n\n修改前会自动备份，可在「备份还原」里恢复。")) {
            return ToolOutcome("用户拒绝了这次修改，文件没有变化。", ok = false)
        }
        return ToolOutcome(withContext(Dispatchers.IO) { FileManager.applyEdit(ref, act, find, text) })
    }

    private suspend fun commit(ref: FileRef, host: ToolHost, title: String, detail: String, note: String, produce: (ByteArray) -> ByteArray): ToolOutcome {
        val original = withContext(Dispatchers.IO) { FileManager.readBytes(ref) }
        val updated = withContext(Dispatchers.Default) { produce(original) }
        if (!host.confirm(title, "$detail\n\n修改前会自动备份，可在「备份还原」里恢复。")) {
            return ToolOutcome("用户拒绝了这次修改，文件没有变化。", ok = false)
        }
        val res = withContext(Dispatchers.IO) { FileManager.replaceContent(ref, updated, note) }
        return ToolOutcome("已修改《${ref.name}》。$res")
    }

    private suspend fun editDocx(ref: FileRef, action: String, args: JSONObject, host: ToolHost): ToolOutcome {
        val text = args.text("text", "content", "new")
        return when (action) {
            "replace", "替换" -> basicEdit(ref, "replace", args, host)
            "append", "追加" -> commit(ref, host, "在「${ref.name}」末尾追加内容？", "追加 ${text.length} 字（支持标题 / 列表 / 表格）：\n${text.take(200)}", "修改前（追加）") {
                OfficeEdit.docxAppendMarkdown(it, text)
            }
            "rewrite", "重写" -> commit(ref, host, "整体重写「${ref.name}」正文？", "新正文 ${text.length} 字，保留页面设置和样式表：\n${text.take(200)}", "修改前（重写）") {
                OfficeEdit.docxRewriteMarkdown(it, text)
            }
            "set_paragraph", "set", "insert_after", "insert_before", "delete_paragraph", "delete", "ops" -> {
                val ops = ArrayList<OfficeEdit.ParaOp>()
                val arr = args.optJSONArray("ops")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        ops.add(OfficeEdit.ParaOp(normParaOp(o.str("action", "op", "kind")), o.intOr("index", -1), o.text("text", "content")))
                    }
                } else {
                    ops.add(OfficeEdit.ParaOp(normParaOp(action), args.intOr("index", args.intOr("paragraph", -1)), text))
                }
                if (ops.isEmpty()) return ToolOutcome("缺少段落操作 ops", ok = false)
                val desc = ops.joinToString("\n") { o ->
                    when (o.kind) {
                        "delete" -> "删除第 [${o.index}] 段"
                        "set" -> "改写第 [${o.index}] 段 →「${o.text.take(50)}」"
                        "insert_before" -> "在第 [${o.index}] 段前插入「${o.text.take(50)}」"
                        else -> "在第 [${o.index}] 段后插入「${o.text.take(50)}」"
                    }
                }
                commit(ref, host, "修改「${ref.name}」的段落？", desc, "修改前（段落编辑）") { OfficeEdit.docxApply(it, ops).first }
            }
            else -> ToolOutcome("Word 支持的 action：replace / append / rewrite / set_paragraph / insert_after / insert_before / delete_paragraph / ops", ok = false)
        }
    }

    private fun normParaOp(a: String): String = when (a.lowercase()) {
        "set_paragraph", "set", "replace", "rewrite", "改写" -> "set"
        "delete_paragraph", "delete", "remove", "删除" -> "delete"
        "insert_before", "before" -> "insert_before"
        else -> "insert_after"
    }

    private suspend fun editPptx(ref: FileRef, action: String, args: JSONObject, host: ToolHost): ToolOutcome {
        val slide = args.intOr("slide", args.intOr("page", args.intOr("index", 0)))
        val title = if (args.has("title")) args.optString("title") else null
        val body = lines(args.opt("body") ?: args.opt("bullets") ?: args.opt("content"))
        return when (action) {
            "replace", "替换" -> basicEdit(ref, "replace", args, host)
            "set_slide", "set", "edit_slide" -> {
                if (slide <= 0) return ToolOutcome("请用 slide 指定页码（从 1 开始），可先用 doc_outline 查看", ok = false)
                commit(ref, host, "修改「${ref.name}」第 $slide 页？",
                    "标题：${title ?: "（不变）"}\n正文：${body?.joinToString(" / ")?.take(200) ?: "（不变）"}", "修改前（改第${slide}页）") {
                    OfficeEdit.pptxSetSlide(it, slide, title, body)
                }
            }
            "add_slide", "insert_slide", "新增" -> {
                val tpl = if (slide > 0) slide else -1
                commit(ref, host, "在「${ref.name}」新增一页？", "标题：${title.orEmpty()}\n正文：${body?.joinToString(" / ")?.take(200).orEmpty()}", "修改前（新增页）") { bytes ->
                    val count = OfficeEdit.slideOrder(OfficeXml.unzip(bytes)).size
                    // 用最后一页（或指定页）做版式模板；指定页时插在它后面
                    val src = if (tpl > 0) tpl else count
                    OfficeEdit.pptxDuplicateSlide(bytes, src, title ?: "", body ?: emptyList(), toEnd = tpl <= 0).first
                }
            }
            "delete_slide", "delete", "删除" -> {
                if (slide <= 0) return ToolOutcome("请用 slide 指定要删除的页码", ok = false)
                commit(ref, host, "删除「${ref.name}」第 $slide 页？", "删除后其余页面顺延。", "修改前（删第${slide}页）") { OfficeEdit.pptxDeleteSlide(it, slide) }
            }
            "duplicate_slide", "copy_slide" -> {
                if (slide <= 0) return ToolOutcome("请用 slide 指定要复制的页码", ok = false)
                commit(ref, host, "复制「${ref.name}」第 $slide 页？", "副本插在原页后面。", "修改前（复制第${slide}页）") { OfficeEdit.pptxDuplicateSlide(it, slide).first }
            }
            else -> ToolOutcome("PPT 支持的 action：replace / set_slide / add_slide / delete_slide / duplicate_slide", ok = false)
        }
    }

    private suspend fun editXlsx(ref: FileRef, action: String, args: JSONObject, host: ToolHost): ToolOutcome {
        val sheet = args.str("sheet").ifBlank { null }
        return when (action) {
            "replace", "替换" -> basicEdit(ref, "replace", args, host)
            "set_cells", "set_cell", "set", "写入" -> {
                val cells = LinkedHashMap<String, String>()
                args.optJSONObject("cells")?.let { o -> for (k in o.keys()) cells[k] = o.optString(k) }
                val cell = args.str("cell", "ref")
                if (cell.isNotBlank()) cells[cell] = args.text("value", "text")
                if (cells.isEmpty()) return ToolOutcome("缺少 cells，例如 {\"B3\":\"120\",\"C3\":\"=B3*2\"}", ok = false)
                commit(ref, host, "修改「${ref.name}」的单元格？",
                    cells.entries.take(12).joinToString("\n") { "${it.key} = ${it.value}" } + if (cells.size > 12) "\n…共 ${cells.size} 个" else "",
                    "修改前（写单元格）") { OfficeEdit.xlsxSetCells(it, sheet, cells) }
            }
            "append_rows", "append", "追加" -> {
                val rows = args.optJSONArray("rows")?.let { arr ->
                    (0 until arr.length()).map { i -> arr.optJSONArray(i)?.let { r -> (0 until r.length()).map { r.optString(it) } } ?: listOf(arr.optString(i)) }
                } ?: com.dia.app.files.Markdown.parseTable(args.text("content", "text"))
                if (rows.isEmpty()) return ToolOutcome("缺少要追加的行 rows（或 content 里写 CSV / 表格）", ok = false)
                commit(ref, host, "在「${ref.name}」追加 ${rows.size} 行？", rows.take(5).joinToString("\n") { it.joinToString(" | ") }, "修改前（追加行）") {
                    OfficeEdit.xlsxAppendRows(it, sheet, rows)
                }
            }
            else -> ToolOutcome("Excel 支持的 action：replace / set_cells / append_rows", ok = false)
        }
    }

    // ───────── 整篇 AI 改写（保留结构与格式） ─────────

    /**
     * 按段落把文档交给 AI 改写：润色、改语气、扩写、精简、翻译……
     * Word / PPT 原地改写（保留排版），PDF 生成新的 PDF，文本文件按段改写。
     */
    suspend fun rewrite(args: JSONObject, host: ToolHost): ToolOutcome {
        val (ref, err) = need(args.str("file", "id", "path", "name"))
        if (ref == null) return err!!
        val instruction = args.str("instruction", "style", "requirement", "how", "to").ifBlank { "润色语言，使表达更准确、流畅、专业" }
        val saveAs = args.optBoolean("save_as", false) || args.optBoolean("copy", false) || ref.ext == "pdf"
        val suffix = args.str("suffix").ifBlank { "改写" }
        host.progress("正在读取 ${ref.name}…")
        val bytes = withContext(Dispatchers.IO) { FileManager.readBytes(ref) }

        when (ref.ext) {
            "docx" -> {
                val paras = OfficeEdit.docxParagraphs(bytes)
                val changes = rewriteUnits(paras, instruction, host)
                if (changes.isEmpty()) return ToolOutcome("没有可改写的段落。", ok = false)
                val newBytes = OfficeEdit.docxMapParagraphs(bytes, changes).first
                return finish(ref, newBytes, saveAs, suffix, "docx", changes, paras, host, instruction)
            }
            "pptx" -> {
                val paras = OfficeEdit.pptxParagraphs(bytes)
                val flat = paras.map { it.third }
                val changes = rewriteUnits(flat, instruction, host)
                if (changes.isEmpty()) return ToolOutcome("没有可改写的文字。", ok = false)
                val grouped = HashMap<String, HashMap<Int, String>>()
                for ((i, t) in changes) {
                    val (part, idx, _) = paras[i]
                    grouped.getOrPut(part) { HashMap() }[idx] = t
                }
                val newBytes = OfficeEdit.pptxMapParagraphs(bytes, grouped).first
                return finish(ref, newBytes, saveAs, suffix, "pptx", changes, flat, host, instruction)
            }
            "pdf" -> {
                val pages = withContext(Dispatchers.IO) { PdfTools.pageTexts(bytes) }
                if (pages.all { it.isBlank() }) return ToolOutcome("这是扫描版 PDF，没有文字层。可以先用 read_file 识别文字，再用 create_file 生成新文档。", ok = false)
                val units = ArrayList<String>()
                val pageBreaks = HashSet<Int>()
                for (p in pages) {
                    pageBreaks.add(units.size)
                    units.addAll(pdfParagraphs(p))
                }
                val changes = rewriteUnits(units, instruction, host)
                val md = StringBuilder()
                for ((i, u) in units.withIndex()) {
                    if (i in pageBreaks && i > 0 && args.optBoolean("keep_pages", false)) md.append("<分页>\n")
                    md.append(changes[i] ?: u).append("\n\n")
                }
                val title = ref.name.substringBeforeLast('.') + "_$suffix"
                val pdf = withContext(Dispatchers.Default) { PdfTools.createFromMarkdown(md.toString(), title) }
                val nr = withContext(Dispatchers.IO) { FileManager.saveNew("$title.pdf", pdf) }
                return ToolOutcome("已改写并生成新 PDF：${nr.id}《${nr.name}》（${FileManager.saveLocationLabel()}），共改写 ${changes.size} 段。原 PDF 未改动。")
            }
            "xlsx" -> return ToolOutcome("Excel 请用 edit_file 的 set_cells 精确修改单元格。", ok = false)
            else -> {
                val text = TextDecode.decode(bytes)
                val units = text.split(Regex("\n\\s*\n"))
                val changes = rewriteUnits(units, instruction, host)
                val joined = units.withIndex().joinToString("\n\n") { (i, u) -> changes[i] ?: u }
                val cs = TextDecode.detectCharsetName(bytes)
                val newBytes = TextDecode.encode(joined, cs)
                return finish(ref, newBytes, saveAs, suffix, ref.ext.ifBlank { "txt" }, changes, units, host, instruction)
            }
        }
    }

    private fun pdfParagraphs(page: String): List<String> {
        // PDF 抽出的文字按行断开：把短行合并成段落
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in page.lines()) {
            val t = line.trim()
            if (t.isEmpty()) {
                if (sb.isNotEmpty()) { out.add(sb.toString()); sb.setLength(0) }
                continue
            }
            sb.append(t)
            if (t.endsWith("。") || t.endsWith("！") || t.endsWith("？") || t.endsWith(".") || t.endsWith("：") || t.length < 18) {
                out.add(sb.toString()); sb.setLength(0)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private suspend fun finish(
        ref: FileRef, newBytes: ByteArray, saveAs: Boolean, suffix: String, ext: String,
        changes: Map<Int, String>, originals: List<String>, host: ToolHost, instruction: String,
    ): ToolOutcome {
        val sample = changes.entries.take(2).joinToString("\n\n") { (i, t) ->
            "原：${originals.getOrElse(i) { "" }.take(60)}\n改：${t.take(60)}"
        }
        if (saveAs) {
            val name = ref.name.substringBeforeLast('.') + "_$suffix.$ext"
            val nr = withContext(Dispatchers.IO) { FileManager.saveNew(name, newBytes) }
            return ToolOutcome(
                "已按「$instruction」改写 ${changes.size} 段，另存为 ${nr.id}《${nr.name}》（${FileManager.saveLocationLabel()}），格式与原文件一致。原文件未改动。",
                display = sample,
            )
        }
        if (!host.confirm("用改写结果覆盖「${ref.name}」？", "共改写 ${changes.size} 段（$instruction），排版不变。\n\n$sample")) {
            val name = ref.name.substringBeforeLast('.') + "_$suffix.$ext"
            val nr = withContext(Dispatchers.IO) { FileManager.saveNew(name, newBytes) }
            return ToolOutcome("用户没有同意覆盖原文件，已另存为 ${nr.id}《${nr.name}》。", display = sample)
        }
        val res = withContext(Dispatchers.IO) { FileManager.replaceContent(ref, newBytes, "修改前（AI 改写）") }
        return ToolOutcome("已按「$instruction」改写《${ref.name}》共 ${changes.size} 段，排版保持不变。$res", display = sample)
    }

    /**
     * 把若干段文字分批交给模型改写，返回 {下标 → 新文字}。
     * 空段、纯数字、页码之类自动跳过；模型漏掉的段保持原样。
     */
    suspend fun rewriteUnits(units: List<String>, instruction: String, host: ToolHost): Map<Int, String> {
        val todo = units.withIndex().filter { (_, t) ->
            val s = t.trim()
            s.length >= 2 && !s.matches(Regex("[\\d\\s/.,:：\\-—–()（）]+"))
        }
        if (todo.isEmpty()) return emptyMap()
        val batchChars = (LlmGateway.promptCharBudget() / 3).coerceIn(600, 6000)
        val batches = ArrayList<List<IndexedValue<String>>>()
        var cur = ArrayList<IndexedValue<String>>()
        var size = 0
        for (u in todo) {
            if (size + u.value.length > batchChars && cur.isNotEmpty()) { batches.add(cur); cur = ArrayList(); size = 0 }
            cur.add(u); size += u.value.length + 8
        }
        if (cur.isNotEmpty()) batches.add(cur)

        val system = "你是资深文字编辑。按要求逐段改写：$instruction。\n" +
            "规则：\n1. 每段输出一行「[编号] 改写后的内容」，编号与原文一一对应，不合并、不拆分、不遗漏。\n" +
            "2. 原文是标题 / 短语的，改写后仍是简短标题；段内换行用 ↵ 表示。\n" +
            "3. 保留人名、数字、日期、专有名词的准确性。\n4. 只输出改写结果，不要任何解释。"
        val result = java.util.concurrent.ConcurrentHashMap<Int, String>()
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        val parallel = if (LlmGateway.canParallel()) (DiaSettings.wujiWorkers.value.coerceIn(1, 4)) else 1
        val gate = Semaphore(parallel)
        coroutineScope {
            batches.map { batch ->
                async {
                    gate.withPermit {
                        val prompt = batch.joinToString("\n") { "[${it.index}] ${it.value.replace("\n", "↵")}" }
                        val out = try {
                            LlmGateway.complete(system = system, prompt = prompt, temperature = 0.4)
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            ""
                        }
                        val parsed = parseNumbered(out)
                        for (u in batch) {
                            val t = parsed[u.index]?.replace("↵", "\n")?.trim()
                            if (!t.isNullOrBlank()) result[u.index] = t
                        }
                        host.progress("改写中 ${done.incrementAndGet()}/${batches.size}…")
                    }
                }
            }.awaitAll()
        }
        return result.toSortedMap()
    }

    /** 解析「[12] 文字」格式（文字可以跨行，直到下一个编号）。 */
    fun parseNumbered(out: String): Map<Int, String> {
        val map = LinkedHashMap<Int, String>()
        val re = Regex("(?m)^\\s*[\\[【](\\d{1,5})[\\]】]\\s*")
        val ms = re.findAll(out).toList()
        for ((i, m) in ms.withIndex()) {
            val end = if (i + 1 < ms.size) ms[i + 1].range.first else out.length
            val idx = m.groupValues[1].toIntOrNull() ?: continue
            map[idx] = out.substring(m.range.last + 1, end).trim()
        }
        return map
    }

    // ───────── PDF 页面操作 / 转换 ─────────

    suspend fun pdfTool(args: JSONObject, host: ToolHost): ToolOutcome {
        val action = args.str("action", "op").lowercase()
        val keys = ArrayList<String>()
        args.optJSONArray("files")?.let { a -> for (i in 0 until a.length()) keys.add(a.optString(i)) }
        args.str("file", "id").takeIf { it.isNotBlank() }?.let { keys.add(0, it) }
        val refs = keys.mapNotNull { FileManager.find(it) }
        if (refs.isEmpty()) return ToolOutcome("请用 file（或 files 数组）指定 PDF", ok = false)
        val pages = args.str("pages", "range")
        val base = refs.first().name.substringBeforeLast('.')
        host.progress("正在处理 PDF…")
        return withContext(Dispatchers.IO) {
            when (action) {
                "merge", "合并" -> {
                    if (refs.size < 2) return@withContext ToolOutcome("合并至少需要两个 PDF", ok = false)
                    val out = PdfTools.merge(refs.map { FileManager.readBytes(it) })
                    val nr = FileManager.saveNew("${base}_合并.pdf", out)
                    ToolOutcome("已把 ${refs.size} 个 PDF 合并为 ${nr.id}《${nr.name}》（${FileManager.saveLocationLabel()}）。")
                }
                "extract", "split", "提取" -> {
                    val (out, n) = PdfTools.extract(FileManager.readBytes(refs[0]), pages)
                    val nr = FileManager.saveNew("${base}_第${pages.replace(',', '_')}页.pdf", out)
                    ToolOutcome("已提取 $n 页，保存为 ${nr.id}《${nr.name}》。")
                }
                "delete_pages", "delete", "删除" -> {
                    val (out, n) = PdfTools.deletePages(FileManager.readBytes(refs[0]), pages)
                    val saveAs = args.optBoolean("save_as", true)
                    if (saveAs) {
                        val nr = FileManager.saveNew("${base}_删页.pdf", out)
                        ToolOutcome("已删除 $n 页，另存为 ${nr.id}《${nr.name}》。原文件未改动。")
                    } else ToolOutcome("已删除 $n 页。" + FileManager.replaceContent(refs[0], out, "修改前（删页）"))
                }
                "rotate", "旋转" -> {
                    val (out, n) = PdfTools.rotate(FileManager.readBytes(refs[0]), pages, args.intOr("degrees", 90))
                    val nr = FileManager.saveNew("${base}_旋转.pdf", out)
                    ToolOutcome("已旋转 $n 页，保存为 ${nr.id}《${nr.name}》。")
                }
                "info", "信息" -> {
                    val b = FileManager.readBytes(refs[0])
                    ToolOutcome("《${refs[0].name}》共 ${PdfTools.pageCount(b)} 页，大小 ${com.dia.app.web.WebDownloader.formatSize(b.size.toLong())}。")
                }
                "to_word", "to_docx", "转word" -> convertInner(refs[0], "docx")
                "to_text", "to_txt", "to_md" -> convertInner(refs[0], if (action == "to_md") "md" else "txt")
                else -> ToolOutcome("pdf_tool 支持：merge / extract / delete_pages / rotate / info / to_word / to_text", ok = false)
            }
        }
    }

    suspend fun convert(args: JSONObject, host: ToolHost): ToolOutcome {
        val (ref, err) = need(args.str("file", "id", "path", "name"))
        if (ref == null) return err!!
        val to = FileManager.normalizeFormat(args.str("to", "format"), "")
        host.progress("正在转换为 $to…")
        return withContext(Dispatchers.IO) { convertInner(ref, to) }
    }

    /** 把文档内容转成 Markdown（尽量保留标题层级）。 */
    fun toMarkdown(ref: FileRef): String {
        val bytes = FileManager.readBytes(ref)
        return when (ref.ext) {
            "docx" -> {
                val xml = OfficeXml.unzip(bytes)["word/document.xml"]?.toString(Charsets.UTF_8).orEmpty()
                val ranges = OfficeEdit.scanParas(xml, OfficeEdit.WORD)
                ranges.joinToString("\n\n") { r ->
                    val para = xml.substring(r.start, r.end)
                    val t = OfficeEdit.paraText(para, OfficeEdit.WORD)
                    val style = Regex("<w:pStyle w:val=\"([^\"]+)\"").find(para)?.groupValues?.get(1).orEmpty()
                    val lv = Regex("(?i)heading\\s?(\\d)|^(\\d)$").find(style)?.let { m -> (m.groupValues[1].ifBlank { m.groupValues[2] }).toIntOrNull() }
                    when {
                        t.isBlank() -> ""
                        style.equals("Title", true) -> "# $t"
                        lv != null -> "#".repeat((lv + if (xml.contains("w:val=\"Title\"")) 1 else 0).coerceIn(1, 4)) + " " + t
                        else -> t
                    }
                }.replace(Regex("\n{3,}"), "\n\n").trim()
            }
            "pptx" -> {
                val entries = OfficeXml.unzip(bytes)
                OfficeEdit.slideOrder(entries).joinToString("\n\n") { name ->
                    val paras = OfficeEdit.partParagraphs(entries.getValue(name).toString(Charsets.UTF_8), OfficeEdit.DRAW).filter { it.isNotBlank() }
                    if (paras.isEmpty()) "" else "# ${paras.first()}\n" + paras.drop(1).joinToString("\n") { "- $it" }
                }
            }
            "xlsx" -> {
                OfficeXml.xlsxText(bytes, 2000).split("\n\n").joinToString("\n\n") { block ->
                    val ls = block.lines().filter { it.isNotBlank() }
                    if (ls.isEmpty()) "" else {
                        val head = ls.first().removePrefix("【工作表 ").removeSuffix("】")
                        val rows = ls.drop(1).map { it.split('\t') }
                        if (rows.isEmpty()) "## $head" else {
                            val w = rows.maxOf { it.size }
                            "## $head\n" + rows.withIndex().joinToString("\n") { (i, r) ->
                                val cells = r + List(w - r.size) { "" }
                                "| " + cells.joinToString(" | ") + " |" + if (i == 0) "\n|" + " --- |".repeat(w) else ""
                            }
                        }
                    }
                }
            }
            "pdf" -> PdfTools.pageTexts(bytes).joinToString("\n\n") { p -> pdfParagraphs(p).joinToString("\n\n") }
            else -> FileManager.read(ref, 0, 2_000_000).text
        }
    }

    private fun convertInner(ref: FileRef, to: String): ToolOutcome {
        val md = toMarkdown(ref)
        if (md.isBlank()) return ToolOutcome("《${ref.name}》里没有提取到文字，无法转换。", ok = false)
        val base = ref.name.substringBeforeLast('.')
        val nr = FileManager.createFile(base, md, to)
        return ToolOutcome("已把《${ref.name}》转换为 ${nr.id}《${nr.name}》（${FileManager.saveLocationLabel()}）。")
    }
}
