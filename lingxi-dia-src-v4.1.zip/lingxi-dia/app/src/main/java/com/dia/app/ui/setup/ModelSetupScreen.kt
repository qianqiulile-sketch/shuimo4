package com.dia.app.ui.setup

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.llm.DiaEngine
import com.dia.app.llm.ModelState
import com.dia.app.prefs.DiaPrefs
import com.dia.app.ui.components.GlassCard
import com.dia.app.ui.home.DiaMascot
import com.dia.app.ui.theme.DiaAccent
import com.dia.app.ui.theme.DiaAccentSecondary
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaError
import com.dia.app.ui.theme.DiaSuccess
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import com.dia.app.ui.theme.DiaWarning
import kotlinx.coroutines.launch
import java.io.File

private const val PREFS_NAME = "dia_prefs"
private const val KEY_MODEL_PATH = "last_model_path"

@Composable
fun ModelSetupScreen(
    onModelReady: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val loadState by com.dia.app.llm.ModelManager.state.collectAsState()
    val modelState by DiaEngine.state.collectAsState()
    var selectedPath by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val autoLoad = DiaPrefs.autoLoadModel.collectAsState().value

    LaunchedEffect(Unit) {
        val savedPath = com.dia.app.llm.ModelRegistry.savedLocalPath(context)
        if (savedPath != null && File(savedPath).exists()) {
            selectedPath = savedPath
            // ModelManager.autoloadIfPreferred is also called in MainActivity,
            // but if the user explicitly opens this screen we defer to it
            // for any retry path. Don't double-init when already loading.
            if (autoLoad && !DiaEngine.isReady &&
                loadState !is com.dia.app.llm.ModelLoadState.Loading) {
                scope.launch { com.dia.app.llm.ModelManager.load(context.applicationContext, savedPath) }
            }
        }
    }

    // Navigate to chat when model is ready
    LaunchedEffect(modelState) {
        if (modelState is ModelState.Ready) {
            selectedPath?.let { path ->
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_MODEL_PATH, path)
                    .apply()
            }
            onModelReady()
        }
    }

    // File picker (copies URI to local storage)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val path = copyUriToLocalFile(context, it)
            if (path != null) {
                selectedPath = path
                scope.launch {
                    com.dia.app.llm.ModelManager.load(context.applicationContext, path)
                }
            }
        }
    }

    // Auto-discover .litertlm files on device
    val discoveredModels = remember {
        discoverModelFiles()
    }

    // Ambient background
    val infiniteTransition = rememberInfiniteTransition(label = "setupBg")
    val glowOffset by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "bgGlow"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .inkPageBackground()
    ) {
        // Ambient glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            DiaAccentSecondary.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = Offset(400f, 600f + glowOffset * 80f),
                        radius = 500f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            // Back button
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "返回",
                        tint = DiaTextSecondary,
                    )
                }
            }

            // Content — scrollable for error screens with debug info
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Spacer(modifier = Modifier.height(40.dp))

                // Mascot
                DiaMascot(modifier = Modifier.size(120.dp))

                Spacer(modifier = Modifier.height(24.dp))

                AnimatedContent(
                    targetState = modelState,
                    transitionSpec = {
                        fadeIn(tween(300)) togetherWith fadeOut(tween(200))
                    },
                    label = "setupState"
                ) { state ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        when (state) {
                            is ModelState.NotLoaded -> NotLoadedContent(
                                onPickFile = { filePickerLauncher.launch("*/*") },
                                discoveredModels = discoveredModels,
                                onSelectModel = { path ->
                                    selectedPath = path
                                    scope.launch {
                                        com.dia.app.llm.ModelManager.load(context.applicationContext, path)
                                    }
                                }
                            )

                            is ModelState.Loading -> LoadingContent(
                                progress = state.progress
                            )

                            is ModelState.Ready -> {
                                Text(
                                    text = "准备就绪！✨",
                                    style = MaterialTheme.typography.displaySmall,
                                    color = DiaSuccess,
                                    fontWeight = FontWeight.Bold,
                                )
                            }

                            is ModelState.InsufficientMemory -> ErrorContent(
                                title = "内存不足",
                                message = state.message,
                                icon = Icons.Rounded.Warning,
                                iconColor = DiaWarning,
                                selectedPath = selectedPath,
                                context = context,
                                onRetry = {
                                    selectedPath?.let { path ->
                                        scope.launch { com.dia.app.llm.ModelManager.load(context.applicationContext, path) }
                                    }
                                },
                                onPickDifferent = { filePickerLauncher.launch("*/*") },
                                onClearData = {
                                    clearModelData(context)
                                    selectedPath = null
                                }
                            )

                            is ModelState.Error -> ErrorContent(
                                title = "出错了",
                                message = state.message,
                                icon = Icons.Rounded.Warning,
                                iconColor = DiaError,
                                selectedPath = selectedPath,
                                context = context,
                                onRetry = {
                                    selectedPath?.let { path ->
                                        scope.launch { com.dia.app.llm.ModelManager.load(context.applicationContext, path) }
                                    }
                                },
                                onPickDifferent = { filePickerLauncher.launch("*/*") },
                                onClearData = {
                                    clearModelData(context)
                                    selectedPath = null
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}

// ─── NotLoaded ───

@Composable
private fun NotLoadedContent(
    onPickFile: () -> Unit,
    discoveredModels: List<File>,
    onSelectModel: (String) -> Unit,
) {
    val context = LocalContext.current
    var showManualInput by remember { mutableStateOf(false) }
    var manualPath by remember { mutableStateOf("") }
    val hasAllFilesAccess = remember {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else true
    }

    Text(
        text = "先给我装个大脑吧 🧠",
        style = MaterialTheme.typography.displaySmall.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.3).sp,
        ),
        color = DiaTextPrimary,
        textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
        text = "选择一个 Gemma 4 .litertlm 模型",
        style = MaterialTheme.typography.bodyLarge,
        color = DiaTextSecondary,
        textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(24.dp))

    // Grant all-files-access if needed (for auto-discovery)
    if (!hasAllFilesAccess) {
        OutlinedButton(
            onClick = {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    val intent = android.content.Intent(
                        android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        android.net.Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                text = "授予文件访问权限（用于自动查找）",
                color = DiaAccent,
                fontSize = 13.sp,
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
    }

    // Show discovered models
    if (discoveredModels.isNotEmpty()) {
        Text(
            text = "在设备上找到：",
            style = MaterialTheme.typography.labelMedium,
            color = DiaTextTertiary,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )

        discoveredModels.forEach { file ->
            val sizeMb = file.length() / 1024 / 1024
            GlassCard(
                cornerRadius = 12.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                TextButton(
                    onClick = { onSelectModel(file.absolutePath) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = file.name,
                            style = MaterialTheme.typography.bodyMedium,
                            color = DiaAccent,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "${sizeMb} MB · ${file.parent}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DiaTextTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("— 或 —", style = MaterialTheme.typography.labelSmall, color = DiaTextTertiary)
        Spacer(modifier = Modifier.height(8.dp))
    }

    // File picker button
    Button(
        onClick = onPickFile,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = DiaAccent,
            contentColor = DiaBackground,
        )
    ) {
        Icon(
            imageVector = Icons.Rounded.FolderOpen,
            contentDescription = null,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(10.dp))
        Text(
            text = "浏览选择模型文件",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.SemiBold,
            ),
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Manual path input toggle
    TextButton(onClick = { showManualInput = !showManualInput }) {
        Icon(
            Icons.Rounded.Terminal,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = DiaTextTertiary,
        )
        Spacer(modifier = Modifier.size(6.dp))
        Text(
            text = if (showManualInput) "隐藏路径输入" else "手动输入路径",
            color = DiaTextTertiary,
            fontSize = 13.sp,
        )
    }

    if (showManualInput) {
        Spacer(modifier = Modifier.height(8.dp))

        // Manual path text field
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            if (manualPath.isEmpty()) {
                Text(
                    text = "/storage/emulated/0/Download/model.litertlm",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                    ),
                    color = DiaTextTertiary.copy(alpha = 0.5f),
                )
            }
            androidx.compose.foundation.text.BasicTextField(
                value = manualPath,
                onValueChange = { manualPath = it },
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = DiaTextPrimary,
                ),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(DiaAccent),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (manualPath.isNotBlank()) {
                    onSelectModel(manualPath.trim())
                }
            },
            enabled = manualPath.isNotBlank(),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = DiaAccent.copy(alpha = 0.8f),
                contentColor = DiaBackground,
            ),
        ) {
            Text("从路径加载")
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    GlassCard(cornerRadius = 12.dp) {
        Text(
            text = "💡 请将 .litertlm 模型传输到设备的「下载」文件夹。" +
                    "使用上方的文件浏览器，或手动粘贴完整路径。",
            style = MaterialTheme.typography.bodySmall,
            color = DiaTextSecondary,
            modifier = Modifier.padding(14.dp),
            lineHeight = 18.sp,
        )
    }
}

// ─── Loading ───

@Composable
private fun LoadingContent(progress: String) {
    CircularProgressIndicator(
        modifier = Modifier.size(56.dp),
        color = DiaAccent,
        strokeWidth = 3.dp,
        strokeCap = StrokeCap.Round,
    )

    Spacer(modifier = Modifier.height(24.dp))

    Text(
        text = "正在加载模型",
        style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.Bold,
        ),
        color = DiaTextPrimary,
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
        text = progress,
        style = MaterialTheme.typography.bodyLarge,
        color = DiaAccent,
        textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
        text = "首次加载可能需要一分钟左右",
        style = MaterialTheme.typography.bodySmall,
        color = DiaTextTertiary,
    )
}

// ─── Error (with debug tools) ───

@Composable
private fun ErrorContent(
    title: String,
    message: String,
    icon: ImageVector,
    iconColor: Color,
    selectedPath: String?,
    context: Context,
    onRetry: () -> Unit,
    onPickDifferent: () -> Unit,
    onClearData: () -> Unit,
) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = iconColor,
        modifier = Modifier.size(48.dp),
    )

    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = title,
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        color = DiaTextPrimary,
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = DiaTextSecondary,
        textAlign = TextAlign.Center,
        lineHeight = 22.sp,
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Action buttons
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = onRetry,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DiaAccent,
                contentColor = DiaBackground,
            ),
        ) {
            Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.size(6.dp))
            Text("重试")
        }

        Button(
            onClick = onPickDifferent,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White.copy(alpha = 0.08f),
                contentColor = DiaTextPrimary,
            ),
        ) {
            Icon(Icons.Rounded.FolderOpen, null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.size(6.dp))
            Text("换个文件")
        }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // ── Debug Tools ──
    GlassCard(cornerRadius = 12.dp) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Rounded.Terminal,
                    contentDescription = null,
                    tint = DiaTextTertiary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.size(6.dp))
                Text(
                    text = "调试信息",
                    style = MaterialTheme.typography.labelMedium,
                    color = DiaTextTertiary,
                )
            }

            // File info
            selectedPath?.let { path ->
                val file = File(path)
                val sizeMb = if (file.exists()) file.length() / 1024 / 1024 else -1
                DebugLine("路径", path)
                DebugLine("大小", if (sizeMb >= 0) "${sizeMb} MB" else "未找到文件")
                DebugLine("存在", "${file.exists()}")
            } ?: run {
                DebugLine("路径", "未选择")
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Copy Error button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        val clipData = buildString {
                            appendLine("Dia Engine Error")
                            appendLine("================")
                            appendLine("Error: $message")
                            appendLine("Path: $selectedPath")
                            selectedPath?.let {
                                val f = File(it)
                                appendLine("File exists: ${f.exists()}")
                                if (f.exists()) appendLine("File size: ${f.length()} bytes")
                            }
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE)
                                as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Dia Error", clipData))
                        Toast.makeText(context, "错误信息已复制", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        Icons.Rounded.ContentCopy, null,
                        modifier = Modifier.size(16.dp),
                        tint = DiaTextSecondary,
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text("复制错误", color = DiaTextSecondary, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        onClearData()
                        Toast.makeText(context, "模型数据已清除", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        Icons.Rounded.Delete, null,
                        modifier = Modifier.size(16.dp),
                        tint = DiaError.copy(alpha = 0.7f),
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text("清除数据", color = DiaError.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun DebugLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
            ),
            color = DiaTextTertiary,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
            ),
            color = DiaTextSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.horizontalScroll(rememberScrollState()),
        )
    }
}

// ─── Utilities ───

/**
 * Scan common locations for .litertlm files already on the device.
 * This lets users skip the file picker when they've adb-pushed a model.
 */
private fun discoverModelFiles(): List<File> {
    val searchDirs = listOf(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        File(Environment.getExternalStorageDirectory(), "Download"),
        File(Environment.getExternalStorageDirectory(), "Models"),
        File(Environment.getExternalStorageDirectory(), "litertlm"),
    )

    return searchDirs
        .filter { it.exists() && it.isDirectory }
        .flatMap { dir ->
            dir.listFiles { file ->
                file.isFile && (file.name.endsWith(".litertlm", ignoreCase = true) ||
                        file.name.endsWith(".litertlm.bin", ignoreCase = true))
            }?.toList() ?: emptyList()
        }
        .distinctBy { it.absolutePath }
        .sortedByDescending { it.lastModified() }
}

/**
 * Clear all model-related data: delete copied model files, clear saved prefs.
 */
private fun clearModelData(context: Context) {
    // Close engine
    DiaEngine.close()

    // Clear saved model path
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .edit()
        .remove(KEY_MODEL_PATH)
        .apply()

    // Delete models dir in external files
    val modelsDir = File(context.getExternalFilesDir(null), "models")
    if (modelsDir.exists()) {
        modelsDir.deleteRecursively()
    }

    // Delete any model files in internal files dir (from old code path)
    context.filesDir.listFiles { file ->
        file.name.endsWith(".litertlm", ignoreCase = true)
    }?.forEach { it.delete() }
}

/**
 * Copy content URI to app-local file so LiteRT-LM can access it by path.
 */
private fun copyUriToLocalFile(context: Context, uri: Uri): String? {
    return try {
        val fileName = getFileName(context, uri) ?: "model.litertlm"
        val modelsDir = File(context.getExternalFilesDir(null), "models")
        modelsDir.mkdirs()
        val destFile = File(modelsDir, fileName)

        if (destFile.exists()) {
            return destFile.absolutePath
        }

        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        destFile.absolutePath
    } catch (e: Exception) {
        android.util.Log.e("ModelSetup", "Failed to copy model file", e)
        null
    }
}

private fun getFileName(context: Context, uri: Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = cursor.getString(idx)
            }
        }
    }
    if (result == null) {
        result = uri.path?.substringAfterLast('/')
    }
    return result
}
