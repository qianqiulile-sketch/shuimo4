package com.dia.app.pilot

sealed interface PilotEvent {
    data class Started(val task: String) : PilotEvent
    data class Step(val index: Int, val message: String) : PilotEvent
    data class ToolCall(val name: String, val params: String) : PilotEvent
    data class ToolResult(val name: String, val result: String) : PilotEvent
    data class Finished(val summary: String) : PilotEvent
    data class Failed(val error: String) : PilotEvent
}
