package com.dia.app.ui.lenslive

import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import com.dia.app.ui.theme.DiaLensListening
import com.dia.app.ui.theme.DiaLensSpeaking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "LensTranslateScreen"
private val TranslateAccent = Color(0xFFFFB300)

/** Languages available in the hidden language menu. */
private data class TargetLang(val label: String, val name: String, val tag: String, val flag: String)

private val Languages = listOf(
    TargetLang("英语", "English", "en", "🇬🇧"),
    TargetLang("印地语", "Hindi", "hi", "🇮🇳"),
    TargetLang("西班牙语", "Spanish", "es", "🇪🇸"),
    TargetLang("法语", "French", "fr", "🇫🇷"),
    TargetLang("德语", "German", "de", "🇩🇪"),
    TargetLang("日语", "Japanese", "ja", "🇯🇵"),
    TargetLang("韩语", "Korean", "ko", "🇰🇷"),
    TargetLang("简体中文", "Simplified Chinese", "zh", "🇨🇳"),
    TargetLang("阿拉伯语", "Arabic", "ar", "🇸🇦"),
    TargetLang("葡萄牙语", "Portuguese", "pt", "🇵🇹"),
    TargetLang("俄语", "Russian", "ru", "🇷🇺"),
    TargetLang("意大利语", "Italian", "it", "🇮🇹"),
)

/**
 * Lens Live Translate — read text in front of the camera and translate
 * it to a target language.
 *
 * UX:
 *  - Camera stays LIVE the whole time. No freeze-frame here — that
 *    belongs in Guide where it grounds the bounding box.
 *  - Manual capture is the primary flow (big translate button at the
 *    bottom). Auto-loop is opt-in via the HUD play/pause toggle.
 *  - Target language is hidden behind a globe icon in the HUD. Tap to
 *    open a dropdown listing all 12 languages.
 *  - TTS is opt-in per result via a Speak button on the result card.
 */
@Composable
fun LensTranslateScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // ── State ──
    var uiState by remember { mutableStateOf<LensLiveUiState>(LensLiveUiState.Initializing) }
    val transcript = remember { mutableStateListOf<TranscriptEntry>() }
    var currentResponse by remember { mutableStateOf("") }
    var ttsEnabled by remember { mutableStateOf(true) }
    var autoLoop by remember { mutableStateOf(false) }
    var inflightJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val queryInFlight = remember { AtomicBoolean(false) }
    var targetLang by remember { mutableStateOf(Languages.first { it.tag == "zh" }) }
    var langMenuOpen by remember { mutableStateOf(false) }

    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
    }
    val captureExecutor = remember { Executors.newSingleThreadExecutor() }

    // ── TTS ──
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    // ── Camera ──
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    val previewView = remember {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.SIMPLIFIED_CHINESE
                tts?.setSpeechRate(1.0f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Scanning
                    }
                    @Deprecated("Deprecated in API")
                    override fun onError(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Scanning
                    }
                })
            }
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    // Update TTS locale whenever the target language changes so it speaks
    // the translation in the correct accent.
    LaunchedEffect(ttsReady, targetLang) {
        if (ttsReady) {
            try {
                val locale = Locale.forLanguageTag(targetLang.tag)
                val ok = tts?.setLanguage(locale)
                if (ok == TextToSpeech.LANG_NOT_SUPPORTED || ok == TextToSpeech.LANG_MISSING_DATA) {
                    tts?.setLanguage(Locale.US)
                }
            } catch (_: Exception) { /* best-effort */ }
        }
    }

    // ── Initialize Camera ──
    LaunchedEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({ cameraProvider = future.get() }, ContextCompat.getMainExecutor(context))
    }
    LaunchedEffect(cameraProvider) {
        val provider = cameraProvider ?: return@LaunchedEffect
        val selector = CameraSelector.DEFAULT_BACK_CAMERA
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        try {
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
        } catch (e: Exception) {
            Log.e(TAG, "Camera bind failed", e)
        }
        if (uiState is LensLiveUiState.Initializing) uiState = LensLiveUiState.Scanning
    }

    /** Trigger a translate on the current camera frame. */
    val triggerTranslate: () -> Unit = trigger@{
        if (queryInFlight.get()) return@trigger
        currentResponse = ""
        inflightJob = doTranslate(
            targetLanguage = targetLang.name,
            queryInFlight = queryInFlight,
            imageCapture = imageCapture,
            captureExecutor = captureExecutor,
            onStateChange = { uiState = it },
            onResponseUpdate = { currentResponse = it },
            transcript = transcript,
            scope = scope,
        )
    }

    // Auto-loop. Opt-in: only fires when autoLoop = true. No TTS in auto
    // mode — speak is always explicit on the result card.
    LaunchedEffect(autoLoop) {
        while (autoLoop) {
            delay(6000L)
            if (autoLoop && uiState is LensLiveUiState.Scanning && !queryInFlight.get()) {
                triggerTranslate()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraProvider?.unbindAll()
            tts?.stop()
            DiaEngine.cancelLensQuery()
            queryInFlight.set(false)
        }
    }

    // ── Animations ──
    val stateColor = when (uiState) {
        is LensLiveUiState.Scanning -> DiaLensListening
        is LensLiveUiState.Thinking -> TranslateAccent
        is LensLiveUiState.Speaking -> DiaLensSpeaking
        else -> Color(0xFF3A3D46)
    }

    val stateLabel = when (uiState) {
        is LensLiveUiState.Initializing -> "启动中…"
        is LensLiveUiState.Scanning -> if (autoLoop) "自动 · ${targetLang.label}" else targetLang.label
        is LensLiveUiState.Thinking -> "翻译中…"
        is LensLiveUiState.Speaking -> "播报中"
        else -> ""
    }

    val glowTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glowTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = when (uiState) {
            is LensLiveUiState.Thinking -> 0.6f
            is LensLiveUiState.Speaking -> 0.4f
            is LensLiveUiState.Scanning -> 0.2f
            else -> 0.15f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    val auroraTransition = rememberInfiniteTransition(label = "aurora")
    val auroraAngle by auroraTransition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(3500, easing = LinearEasing), RepeatMode.Restart),
        label = "auroraAngle"
    )
    val auroraIntensity by animateFloatAsState(
        targetValue = when (uiState) {
            is LensLiveUiState.Thinking -> 0.8f
            is LensLiveUiState.Speaking -> 0.7f
            is LensLiveUiState.Scanning -> 0.25f
            else -> 0f
        },
        animationSpec = tween(600),
        label = "auroraIntensity"
    )
    val auroraActual = auroraIntensity * 0.55f

    // Latest finished translation (for the result card)
    val lastResult: TranscriptEntry? = remember(transcript.size, currentResponse) {
        if (currentResponse.isBlank()) transcript.firstOrNull { it.meta.startsWith("translate") } else null
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // Camera preview — stays live the whole time.
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        // Top + bottom gradient scrims.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.78f), Color.Black.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(360.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.95f))
                    )
                )
        )

        AuroraBorder(auroraAngle = auroraAngle, auroraActual = auroraActual, tintColor = TranslateAccent)

        // ─── Top HUD ───
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 16.dp, end = 16.dp)
                .align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HudIconButton(Icons.Rounded.Close, "关闭") {
                tts?.stop()
                inflightJob?.cancel()
                DiaEngine.cancelLensQuery()
                onBack()
            }

            Spacer(Modifier.width(12.dp))

            // State pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.dp, stateColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(stateColor.copy(alpha = 0.3f + glowAlpha * 0.7f))
                        .drawBehind { drawCircle(color = stateColor, radius = 3.dp.toPx()) }
                )
                Text(
                    stateLabel,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp
                    ),
                    color = stateColor
                )
            }

            Spacer(Modifier.weight(1f))

            // Stop button (only during inflight)
            val isInflight = uiState is LensLiveUiState.Thinking || uiState is LensLiveUiState.Speaking
            if (isInflight) {
                IconButton(
                    onClick = {
                        tts?.stop()
                        inflightJob?.cancel()
                        DiaEngine.cancelLensQuery()
                        queryInFlight.set(false)
                        uiState = LensLiveUiState.Scanning
                        currentResponse = ""
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFD32F2F).copy(alpha = 0.85f))
                        .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                ) {
                    Icon(Icons.Rounded.Stop, "停止", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(8.dp))
            }

            // Hidden language menu — tap to reveal a dropdown of 12
            // languages. The current selection is shown as a small flag
            // overlaid on the globe icon.
            Box {
                IconButton(
                    onClick = { langMenuOpen = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .border(1.dp, TranslateAccent.copy(alpha = 0.35f), CircleShape),
                ) {
                    Icon(
                        Icons.Rounded.Language, "目标语言",
                        tint = TranslateAccent.copy(alpha = 0.95f),
                        modifier = Modifier.size(20.dp),
                    )
                }
                DropdownMenu(
                    expanded = langMenuOpen,
                    onDismissRequest = { langMenuOpen = false },
                    modifier = Modifier
                        .background(Color(0xFF101418))
                        .heightIn(max = 360.dp),
                ) {
                    Text(
                        "翻译为",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp
                        ),
                        color = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                    for (lang in Languages) {
                        val active = lang.tag == targetLang.tag
                        DropdownMenuItem(
                            onClick = {
                                targetLang = lang
                                langMenuOpen = false
                            },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Text(lang.flag, fontSize = 18.sp)
                                    Text(
                                        lang.label,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                                        ),
                                        color = if (active) TranslateAccent else Color.White.copy(alpha = 0.85f),
                                    )
                                }
                            },
                            trailingIcon = {
                                if (active) {
                                    Icon(
                                        Icons.Rounded.Check, "已选择",
                                        tint = TranslateAccent,
                                        modifier = Modifier.size(16.dp),
                                    )
                                }
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.width(8.dp))

            // TTS toggle (gates the per-result Speak button)
            HudIconButton(
                if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                if (ttsEnabled) "静音" else "取消静音",
                tint = if (ttsEnabled) Color.White.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.45f),
            ) {
                ttsEnabled = !ttsEnabled
                if (!ttsEnabled) tts?.stop()
            }

            Spacer(Modifier.width(8.dp))

            // Auto-loop toggle
            HudIconButton(
                if (autoLoop) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (autoLoop) "暂停自动" else "自动翻译",
                tint = if (autoLoop) TranslateAccent else Color.White.copy(alpha = 0.55f),
            ) { autoLoop = !autoLoop }
        }

        // ─── Bottom panel: result card + capture button ───
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Result card area — fixed slot so the capture button doesn't
            // bounce up and down between states.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 110.dp, max = 240.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AnimatedVisibility(
                    visible = uiState is LensLiveUiState.Thinking && currentResponse.isBlank(),
                    enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 3 },
                    exit = fadeOut(tween(150)),
                ) {
                    ThinkingIndicator(stateColor = TranslateAccent, isDeep = false)
                }

                // Live streaming
                AnimatedVisibility(
                    visible = currentResponse.isNotBlank(),
                    enter = fadeIn(tween(200)),
                    exit = fadeOut(tween(150)),
                ) {
                    TranslationCard(
                        rawText = currentResponse,
                        targetLabel = targetLang.label,
                        streaming = true,
                        canSpeak = false,
                        onSpeak = {},
                    )
                }

                // Last finished translation
                AnimatedVisibility(
                    visible = lastResult != null && currentResponse.isBlank(),
                    enter = fadeIn(tween(200)),
                    exit = fadeOut(tween(150)),
                ) {
                    val r = lastResult
                    if (r != null) {
                        TranslationCard(
                            rawText = r.text,
                            targetLabel = targetLang.label,
                            streaming = false,
                            canSpeak = ttsEnabled && ttsReady,
                            onSpeak = {
                                val (_, translated) = splitOriginalAndTranslation(r.text)
                                if (translated.isNotBlank()) {
                                    uiState = LensLiveUiState.Speaking(translated)
                                    tts?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "lens_translate_manual")
                                }
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Capture button — manual primary action.
            CaptureButton(
                isInflight = uiState is LensLiveUiState.Thinking,
                accent = TranslateAccent,
                onClick = {
                    if (uiState is LensLiveUiState.Thinking) {
                        tts?.stop()
                        inflightJob?.cancel()
                        DiaEngine.cancelLensQuery()
                        queryInFlight.set(false)
                        uiState = LensLiveUiState.Scanning
                        currentResponse = ""
                    } else {
                        triggerTranslate()
                    }
                },
            )

            Spacer(Modifier.height(10.dp))

            Text(
                text = when (uiState) {
                    is LensLiveUiState.Scanning ->
                        if (autoLoop) "自动已开 · 点击立即翻译 · ${targetLang.label}"
                        else "点击翻译为${targetLang.label}"
                    is LensLiveUiState.Thinking -> "正在识别文字…"
                    is LensLiveUiState.Speaking -> "播报中 — 点击停止可静音"
                    else -> ""
                },
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.5.sp),
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        if (uiState is LensLiveUiState.Initializing) InitializingOverlay()
    }
}

/* ────────────────────────────────────────────────────────────────────── */
/*  Sub-composables                                                        */
/* ────────────────────────────────────────────────────────────────────── */

@Composable
private fun HudIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    tint: Color = Color.White.copy(alpha = 0.85f),
    onClick: () -> Unit,
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
    ) {
        Icon(icon, contentDesc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

/**
 * Side-by-side original + translation card. No → arrow. The original is
 * dimmer; the translation is the prominent text. Speak button only
 * appears when [canSpeak] is true (TTS toggle on) and we're not still
 * streaming.
 */
@Composable
private fun TranslationCard(
    rawText: String,
    targetLabel: String,
    streaming: Boolean,
    canSpeak: Boolean,
    onSpeak: () -> Unit,
) {
    val (original, translation) = remember(rawText) { splitOriginalAndTranslation(rawText) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.Black.copy(alpha = 0.65f))
            .border(1.dp, TranslateAccent.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Rounded.Translate,
                "翻译",
                tint = TranslateAccent,
                modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                "译文 · $targetLabel",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp
                ),
                color = TranslateAccent.copy(alpha = 0.95f),
            )
            Spacer(Modifier.weight(1f))
            if (canSpeak && !streaming && translation.isNotBlank()) {
                IconButton(
                    onClick = onSpeak,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(TranslateAccent.copy(alpha = 0.18f)),
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.VolumeUp,
                        "朗读译文",
                        tint = TranslateAccent,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }

        if (original.isNotBlank()) {
            Text(
                original,
                style = MaterialTheme.typography.bodySmall.copy(letterSpacing = 0.2.sp),
                color = Color.White.copy(alpha = 0.55f),
                fontWeight = FontWeight.Medium,
            )
        }
        if (translation.isNotBlank() || streaming) {
            Text(
                translation.ifBlank { "…" },
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 17.sp,
                    lineHeight = 23.sp,
                    fontWeight = FontWeight.SemiBold,
                ),
                color = Color.White,
            )
        } else if (original.isBlank() && !streaming) {
            // Edge case — model output one line only and it didn't parse
            // into original/translation. Show the whole thing.
            Text(
                rawText,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                ),
                color = Color.White,
            )
        }
    }
}

/**
 * Big circular capture button at the bottom. Tints to the inflight color
 * while a translate is running.
 */
@Composable
private fun CaptureButton(
    isInflight: Boolean,
    accent: Color,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    if (isInflight)
                        listOf(Color(0xFFFF5252), Color(0xFFD32F2F))
                    else
                        listOf(accent, accent.copy(alpha = 0.7f))
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = if (isInflight) Icons.Rounded.Stop else Icons.Rounded.Translate,
            contentDescription = if (isInflight) "停止" else "翻译",
            tint = Color.White,
            modifier = Modifier.size(34.dp),
        )
    }
}

/**
 * Split a raw model output into (original, translation). The model is
 * prompted to emit two lines — line 1 is the original, line 2 is the
 * translation. Strips legacy `→` arrow format too in case the model still
 * emits it under temperature noise.
 */
internal fun splitOriginalAndTranslation(raw: String): Pair<String, String> {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return "" to ""
    if (trimmed.equals("No text detected", ignoreCase = true)) return "" to trimmed

    // 1) Two-line format (preferred)
    val lines = trimmed.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
    if (lines.size >= 2) {
        return lines[0].trim('"', '\u201C', '\u201D') to
                lines.drop(1).joinToString(" ").trim('"', '\u201C', '\u201D')
    }

    // 2) Legacy → arrow format
    val arrowIdx = trimmed.indexOf('\u2192')
    if (arrowIdx > 0) {
        val left = trimmed.substring(0, arrowIdx).trim().trim('[', ']', '"')
        val right = trimmed.substring(arrowIdx + 1).trim().trim('[', ']', '"')
        return left to right
    }

    // 3) Fallback — only one line; treat as translation.
    return "" to trimmed
}

/* ────────────────────────────────────────────────────────────────────── */
/*  Inference                                                              */
/* ────────────────────────────────────────────────────────────────────── */

private fun doTranslate(
    targetLanguage: String,
    queryInFlight: AtomicBoolean,
    imageCapture: ImageCapture,
    captureExecutor: java.util.concurrent.Executor,
    onStateChange: (LensLiveUiState) -> Unit,
    onResponseUpdate: (String) -> Unit,
    transcript: MutableList<TranscriptEntry>,
    scope: kotlinx.coroutines.CoroutineScope,
): kotlinx.coroutines.Job? {
    if (!queryInFlight.compareAndSet(false, true)) return null

    DiaEngine.cancelLensQuery()
    onStateChange(LensLiveUiState.Thinking(ThinkMode.TRANSLATE))
    onResponseUpdate("")

    val accumulated = StringBuilder()

    return scope.launch(Dispatchers.IO) {
        val frame = try {
            captureFrameScaled(imageCapture, captureExecutor, mirror = false)
        } catch (e: Exception) {
            Log.e(TAG, "Translate capture failed", e)
            null
        }

        BackendRouter.sendLensTranslate(
            image = frame,
            targetLanguage = targetLanguage,
            onToken = { partial, done ->
                if (!done) {
                    accumulated.append(partial)
                    val snapshot = accumulated.toString()
                    scope.launch(Dispatchers.Main) { onResponseUpdate(snapshot) }
                } else {
                    queryInFlight.set(false)
                    val finalResponse = accumulated.toString().trim()
                    scope.launch(Dispatchers.Main) {
                        if (finalResponse.isNotBlank()) {
                            transcript.add(0, TranscriptEntry("assistant", finalResponse, "translate"))
                            onResponseUpdate("")
                        }
                        onStateChange(LensLiveUiState.Scanning)
                    }
                }
            },
            onError = { msg ->
                queryInFlight.set(false)
                Log.e(TAG, "Translate error: $msg")
                scope.launch(Dispatchers.Main) {
                    onResponseUpdate("")
                    onStateChange(LensLiveUiState.Scanning)
                }
            }
        )
    }
}
