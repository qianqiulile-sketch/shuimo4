package com.dia.app.llm

import android.content.Context
import android.os.Environment
import com.dia.app.prefs.DiaPrefs
import java.io.File

/**
 * Single entry-point for everything in the app that needs to know
 *   "what local models are on this device?" and
 *   "is the cloud one available?".
 *
 * Used by both the dedicated Model Setup screen and the in-chat model
 * picker, so the user sees the same list everywhere.
 */
object ModelRegistry {

    private const val PREFS_NAME = "dia_prefs"
    private const val KEY_MODEL_PATH = "last_model_path"

    /** All on-device .litertlm files we can find. Most-recently-modified first. */
    fun discoverLocal(context: Context): List<File> {
        val candidates = mutableListOf<File>()

        // Public download / model dirs
        candidates += Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        candidates += File(Environment.getExternalStorageDirectory(), "Download")
        candidates += File(Environment.getExternalStorageDirectory(), "Models")
        candidates += File(Environment.getExternalStorageDirectory(), "litertlm")

        // App-private models dir (where we copy picked-from-content-uri files)
        context.getExternalFilesDir(null)?.let { candidates += File(it, "models") }

        return candidates
            .filter { it.exists() && it.isDirectory }
            .flatMap { dir ->
                dir.listFiles { f ->
                    f.isFile && (
                        f.name.endsWith(".litertlm", ignoreCase = true) ||
                        f.name.endsWith(".litertlm.bin", ignoreCase = true) ||
                        f.name.endsWith(".task", ignoreCase = true)
                    )
                }?.toList() ?: emptyList()
            }
            .distinctBy { it.absolutePath }
            .sortedByDescending { it.lastModified() }
    }

    fun savedLocalPath(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_MODEL_PATH, null)
    }

    fun saveLocalPath(context: Context, path: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MODEL_PATH, path)
            .apply()
    }

    /** Friendly name for the picker UI. */
    fun friendlyName(file: File): String = file.nameWithoutExtension
        .removeSuffix(".litertlm")
        .replace('_', ' ')
        .replace('-', ' ')
        .trim()

    fun cloudAvailable(): Boolean = DiaPrefs.cloudIsConfigured()

    fun cloudLabel(): String {
        val model = DiaPrefs.cloudModel.value.ifBlank { "cloud model" }
        val host = try {
            java.net.URL(DiaPrefs.cloudBaseUrl.value).host
        } catch (_: Exception) { DiaPrefs.cloudBaseUrl.value.takeIf { it.isNotBlank() } ?: "" }
        return if (host.isNotBlank()) "$model · $host" else model
    }
}
