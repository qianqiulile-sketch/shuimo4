package com.dia.app.files

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** 已附加到灵犀的一个文件。id 形如 f1、f2，模型通过 id 引用。 */
data class FileRef(
    val id: String,
    val uri: String,
    val name: String,
    val mime: String,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis(),
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
    val kind: String
        get() = when {
            ext == "docx" -> "Word"
            ext == "doc" -> "Word(旧版)"
            ext == "pptx" -> "PPT"
            ext == "ppt" -> "PPT(旧版)"
            ext == "xlsx" -> "Excel"
            ext == "xls" -> "Excel(旧版)"
            ext == "pdf" -> "PDF"
            mime.startsWith("image/") -> "图片"
            mime.startsWith("audio/") || ext in FileManager.AUDIO_EXTS -> "音频"
            mime.startsWith("video/") || ext in FileManager.VIDEO_EXTS -> "视频"
            else -> "文本"
        }
    /** 是否支持修改 */
    val editable: Boolean get() = ext in FileManager.TEXT_EXTS || ext in setOf("docx", "pptx", "xlsx")
}

data class BackupEntry(
    val id: String,
    val fileId: String,
    val uri: String,
    val name: String,
    val time: Long,
    val size: Long,
    val note: String,
)

/** 读取结果。扫描版 PDF 没有文字时会给出页面图片，交给视觉模型识别。 */
data class ReadResult(
    val text: String,
    val totalChars: Int,
    val pages: Int = 0,
    val images: List<Bitmap> = emptyList(),
    val note: String = "",
)

/**
 * 本地文件：附加、读取（Word / PPT / Excel / PDF / 文本）、经用户同意后修改、
 * 修改前自动备份、一键还原。
 */
object FileManager {

    private const val TAG = "FileManager"

    val TEXT_EXTS = setOf(
        "txt", "md", "markdown", "csv", "tsv", "json", "xml", "html", "htm", "log", "ini", "conf", "yaml", "yml",
        "kt", "java", "py", "js", "ts", "c", "cpp", "h", "cs", "go", "rs", "sh", "bat", "sql", "properties", "srt", "lrc",
    )

    val AUDIO_EXTS = setOf("mp3", "wav", "m4a", "aac", "amr", "ogg", "opus", "flac", "wma", "3gp", "awb", "mid")
    val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "avi", "3gpp")

    /** 是否是音频（或带音轨的视频），可以用 transcribe_audio 转文字。 */
    fun isAudio(ref: FileRef): Boolean =
        ref.mime.startsWith("audio/") || ref.mime.startsWith("video/") || ref.ext in AUDIO_EXTS || ref.ext in VIDEO_EXTS

    private lateinit var appCtx: Context
    private val lock = Any()

    private val _files = MutableStateFlow<List<FileRef>>(emptyList())
    val files: StateFlow<List<FileRef>> = _files.asStateFlow()

    private val _backups = MutableStateFlow<List<BackupEntry>>(emptyList())
    val backups: StateFlow<List<BackupEntry>> = _backups.asStateFlow()

    private val filesIndex: File get() = File(appCtx.filesDir, "attached_files.json")
    private val backupDir: File get() = File(appCtx.filesDir, "backups").apply { mkdirs() }
    private val backupIndex: File get() = File(backupDir, "index.json")

    fun init(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        _files.value = loadFiles()
        _backups.value = loadBackups()
        try {
            com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(appCtx)
        } catch (t: Throwable) {
            Log.w(TAG, "PDFBox init failed: ${t.message}")
        }
    }

    // ───────── 附加文件 ─────────

    /** 用户通过系统文件选择器选了文件后调用。 */
    fun attach(uri: Uri): FileRef {
        val cr = appCtx.contentResolver
        try {
            cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {
            try { cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "文件"
        var size = -1L
        try {
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) c.getString(ni)?.let { name = it }
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) { }
        val mime = cr.getType(uri) ?: guessMime(name)
        return register(uri.toString(), name, mime, size)
    }

    /** 通过路径附加（需要“所有文件访问”权限）。 */
    fun attachPath(path: String): FileRef {
        val f = File(path)
        if (!f.exists() || !f.isFile) throw IllegalArgumentException("文件不存在：$path")
        return register(Uri.fromFile(f).toString(), f.name, guessMime(f.name), f.length())
    }

    private fun register(uri: String, name: String, mime: String, size: Long): FileRef {
        synchronized(lock) {
            _files.value.firstOrNull { it.uri == uri }?.let { return it }
            val next = (_files.value.mapNotNull { it.id.removePrefix("f").toIntOrNull() }.maxOrNull() ?: 0) + 1
            val ref = FileRef("f$next", uri, name, mime, size)
            // 长思一跑就是几百步，登记上限放宽，避免早先的 f 编号被挤掉后「找不到文件」
            val list = (listOf(ref) + _files.value).take(400)
            _files.value = list
            saveFiles(list)
            return ref
        }
    }

    fun remove(id: String) {
        synchronized(lock) {
            val list = _files.value.filter { it.id != id }
            _files.value = list
            saveFiles(list)
        }
    }

    /** 按 id / 文件名 / 路径查找。 */
    fun find(key: String): FileRef? {
        val k = key.trim().removePrefix("[").removeSuffix("]")
        if (k.isEmpty()) return null
        val list = _files.value
        list.firstOrNull { it.id.equals(k, true) }?.let { return it }
        list.firstOrNull { it.name == k }?.let { return it }
        list.firstOrNull { it.name.contains(k, true) || k.contains(it.name, true) }?.let { return it }
        if (k.startsWith("/")) {
            try { return attachPath(k) } catch (_: Exception) { }
        }
        // 「灵犀AI」里的相对路径（如 作品/报告.docx、长思/xxx/成果/报告.docx）
        if (AiFolder.isReady) {
            try {
                val f = AiFolder.resolve(k)
                if (f.isFile) return attachPath(f.absolutePath)
            } catch (_: Exception) { }
        }
        return null
    }

    fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "md" -> "text/markdown"
            "kt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    // ───────── 读写字节 ─────────

    fun readBytes(ref: FileRef, limit: Int = 60 * 1024 * 1024): ByteArray {
        val uri = Uri.parse(ref.uri)
        if (uri.scheme == "file") {
            val f = File(uri.path ?: throw IllegalArgumentException("路径无效"))
            if (f.length() > limit) throw IllegalArgumentException("文件过大（超过 ${limit / 1024 / 1024}MB）")
            return f.readBytes()
        }
        val input = appCtx.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("无法打开文件，可能已被移动或没有权限，请重新选择")
        return input.use {
            val bytes = it.readBytes()
            if (bytes.size > limit) throw IllegalArgumentException("文件过大")
            bytes
        }
    }

    private fun writeBytes(ref: FileRef, data: ByteArray) {
        val uri = Uri.parse(ref.uri)
        if (uri.scheme == "file") {
            File(uri.path ?: throw IllegalArgumentException("路径无效")).writeBytes(data)
            return
        }
        val cr = appCtx.contentResolver
        var lastError: Exception? = null
        for (mode in listOf("wt", "rwt", "w")) {
            try {
                val out = cr.openOutputStream(uri, mode) ?: continue
                out.use { it.write(data); it.flush() }
                return
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw IllegalStateException("没有写入权限：${lastError?.message ?: "未知错误"}。请用“文件”按钮重新选择该文件后再试。")
    }

    // ───────── 读取 ─────────

    fun read(ref: FileRef, offset: Int = 0, maxChars: Int = 3000): ReadResult {
        val bytes = readBytes(ref)
        val full: String
        var pages = 0
        var images: List<Bitmap> = emptyList()
        var note = ""
        when {
            ref.ext == "docx" || (ref.ext.isEmpty() && OfficeXml.isZip(bytes) && ref.mime.contains("word")) ->
                full = OfficeXml.docxText(bytes)
            ref.ext == "pptx" -> full = OfficeXml.pptxText(bytes)
            ref.ext == "xlsx" -> full = OfficeXml.xlsxText(bytes)
            ref.ext in setOf("doc", "ppt", "xls") -> {
                full = TextDecode.extractLegacyText(bytes)
                note = "旧版 Office 格式只能粗略提取文字，建议另存为 docx/pptx/xlsx 后再处理。"
            }
            ref.ext == "pdf" || ref.mime == "application/pdf" -> {
                val (t, n) = pdfText(bytes)
                full = t
                pages = n
                if (t.isBlank()) {
                    images = renderPdfPages(ref, 2)
                    note = "这是扫描版 PDF（没有文字层），已把前 ${images.size} 页转成图片进行识别。"
                }
            }
            ref.mime.startsWith("image/") -> {
                full = ""
                note = "这是图片文件，请直接把图片发给我看。"
            }
            isAudio(ref) -> {
                full = ""
                note = "这是音频/视频文件（${ref.name}）。用 transcribe_audio 把它转成文字，或用 listen_audio 让本机模型直接听。"
            }
            ref.ext == "html" || ref.ext == "htm" -> full = com.dia.app.web.HtmlText.htmlToText(TextDecode.decode(bytes), 200_000).second
            else -> full = TextDecode.decode(bytes)
        }
        val start = offset.coerceIn(0, full.length)
        val end = (start + maxChars).coerceAtMost(full.length)
        return ReadResult(full.substring(start, end), full.length, pages, images, note)
    }

    private fun pdfText(bytes: ByteArray): Pair<String, Int> = try {
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes).use { doc ->
            val n = doc.numberOfPages
            val stripper = com.tom_roush.pdfbox.text.PDFTextStripper()
            stripper.startPage = 1
            stripper.endPage = minOf(n, 80)
            stripper.getText(doc).trim() to n
        }
    } catch (t: Throwable) {
        Log.w(TAG, "pdf text failed: ${t.message}")
        "" to 0
    }

    private fun renderPdfPages(ref: FileRef, maxPages: Int): List<Bitmap> {
        val out = ArrayList<Bitmap>()
        try {
            val pfd = appCtx.contentResolver.openFileDescriptor(Uri.parse(ref.uri), "r") ?: return out
            pfd.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    for (i in 0 until minOf(maxPages, renderer.pageCount)) {
                        renderer.openPage(i).use { page ->
                            val w = 1024
                            val h = (w.toFloat() * page.height / page.width).toInt().coerceIn(1, 2048)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            out.add(bmp)
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "pdf render failed: ${t.message}")
        }
        return out
    }

    // ───────── 修改（调用前必须已获得用户同意） ─────────

    /** 预览一次修改：返回给用户确认的说明文字。不写文件。 */
    fun previewEdit(ref: FileRef, action: String, find: String, text: String): String {
        if (!ref.editable) {
            throw IllegalArgumentException(
                if (ref.ext == "pdf") "PDF 不能逐字修改：请改用 rewrite_file（改写后生成新的 PDF）或 pdf_tool（合并 / 提取 / 删除 / 旋转页面、转 Word）。"
                else "${ref.kind} 格式暂不支持修改。"
            )
        }
        return when (action) {
            "replace" -> {
                if (find.isEmpty()) throw IllegalArgumentException("缺少要替换的原文（find）")
                val count = countMatches(ref, find)
                if (count == 0) throw IllegalArgumentException("文件中没有找到「${find.take(40)}」")
                "将「${find.take(60)}」替换为「${text.take(60)}」，共 $count 处"
            }
            "append" -> {
                if (ref.ext == "pptx" || ref.ext == "xlsx") throw IllegalArgumentException("${ref.kind} 暂不支持追加，只支持替换文字")
                "在文末追加 ${text.length} 字：「${text.take(80)}${if (text.length > 80) "…" else ""}」"
            }
            "rewrite" -> {
                if (ref.ext == "pptx" || ref.ext == "xlsx") throw IllegalArgumentException("${ref.kind} 暂不支持整体重写，只支持替换文字")
                val warn = if (ref.ext == "docx") "（原有表格、图片和格式会丢失）" else ""
                "用新内容（${text.length} 字）整体覆盖原文$warn"
            }
            else -> throw IllegalArgumentException("未知操作：$action（可用 replace / append / rewrite）")
        }
    }

    private fun countMatches(ref: FileRef, find: String): Int {
        val bytes = readBytes(ref)
        return when (ref.ext) {
            "docx" -> OfficeXml.docxReplace(bytes, find, find).second
            "pptx" -> OfficeXml.pptxReplace(bytes, find, find).second
            "xlsx" -> OfficeXml.xlsxReplace(bytes, find, find).second
            else -> OfficeXml.countOccurrences(TextDecode.decode(bytes), find)
        }
    }

    /** 执行修改：先备份，再写回。返回结果说明。 */
    fun applyEdit(ref: FileRef, action: String, find: String, text: String): String {
        val original = readBytes(ref)
        val backup = backup(ref, original, "修改前（$action）")
        val newBytes: ByteArray
        var count = 0
        when (ref.ext) {
            "docx" -> newBytes = when (action) {
                "replace" -> OfficeXml.docxReplace(original, find, text).also { count = it.second }.first
                "append" -> OfficeXml.docxAppend(original, text)
                else -> OfficeXml.docxRewrite(original, text)
            }
            "pptx" -> newBytes = OfficeXml.pptxReplace(original, find, text).also { count = it.second }.first
            "xlsx" -> newBytes = OfficeXml.xlsxReplace(original, find, text).also { count = it.second }.first
            else -> {
                val cs = TextDecode.detectCharsetName(original)
                val content = TextDecode.decode(original)
                val updated = when (action) {
                    "replace" -> { count = OfficeXml.countOccurrences(content, find); content.replace(find, text) }
                    "append" -> if (content.endsWith("\n") || content.isEmpty()) content + text else content + "\n" + text
                    else -> text
                }
                newBytes = TextDecode.encode(updated, cs)
            }
        }
        if (action == "replace" && count == 0) throw IllegalArgumentException("没有找到要替换的内容，文件未修改")
        writeBytes(ref, newBytes)
        val what = when (action) {
            "replace" -> "已替换 $count 处"
            "append" -> "已追加内容"
            else -> "已重写全文"
        }
        return "$what。修改前的版本已备份（${formatTime(backup.time)}），可在「备份还原」里一键恢复。"
    }

    /** 按扩展名给出 MIME。 */
    fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "pdf" -> "application/pdf"
        "md", "markdown" -> "text/markdown"
        "html", "htm" -> "text/html"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        else -> "text/plain"
    }

    /** 规范化格式名：word→docx、ppt→pptx、excel→xlsx … */
    fun normalizeFormat(format: String, name: String): String {
        val f = format.trim().lowercase().removePrefix(".")
        val byName = name.substringAfterLast('.', "").lowercase()
        return when (f.ifBlank { byName }) {
            "docx", "word", "doc" -> "docx"
            "pptx", "ppt", "powerpoint", "幻灯片", "演示" -> "pptx"
            "xlsx", "excel", "xls", "表格" -> "xlsx"
            "pdf" -> "pdf"
            "md", "markdown" -> "md"
            "html", "htm", "网页" -> "html"
            "csv" -> "csv"
            "json" -> "json"
            "" -> "txt"
            else -> if (f in TEXT_EXTS) f else "txt"
        }
    }

    /** AI 生成的文件保存在哪里（给模型和用户看的描述）。 */
    fun saveLocationLabel(): String =
        if (com.dia.app.prefs.DiaSettings.aiSaveTo.value == "download") "下载/Dia" else "${AiFolder.NAME}/作品"

    /**
     * 保存 AI 生成的新文件并登记。默认存到「灵犀AI/作品」（AI 专属文件夹），
     * 设置里可改为「下载/Dia」。重名时自动加序号。
     */
    fun saveNew(fileName: String, data: ByteArray, mime: String = mimeFor(fileName.substringAfterLast('.', ""))): FileRef {
        val clean = fileName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "灵犀文件.txt" }
        if (com.dia.app.prefs.DiaSettings.aiSaveTo.value != "download" && AiFolder.isReady) {
            val f = AiFolder.save("作品", clean, data)
            return register(Uri.fromFile(f).toString(), f.name, mime, data.size.toLong())
        }
        return saveToDownloads(clean, data, mime)
    }

    /** 保存到「下载/Dia」（公共下载目录，任何文件管理器可见）。 */
    fun saveToDownloads(fileName: String, data: ByteArray, mime: String = mimeFor(fileName.substringAfterLast('.', ""))): FileRef {
        val clean = fileName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "灵犀文件.txt" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, clean)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Dia")
            }
            val uri = appCtx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建文件")
            appCtx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                ?: throw IllegalStateException("无法写入文件")
            // 系统可能自动改名（重名时加 (1)），以实际名字为准
            var actual = clean
            try {
                appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { actual = it }
                }
            } catch (_: Exception) { }
            return register(uri.toString(), actual, mime, data.size.toLong())
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Dia").apply { mkdirs() }
            var f = File(dir, clean)
            var n = 1
            while (f.exists()) {
                f = File(dir, clean.substringBeforeLast('.') + "($n)." + clean.substringAfterLast('.', "txt")); n++
            }
            f.writeBytes(data)
            return register(Uri.fromFile(f).toString(), f.name, mime, data.size.toLong())
        }
    }

    /**
     * 新建文件（默认在「灵犀AI/作品」，见 [saveNew]）。
     * format: docx / pptx / xlsx / pdf / md / txt / html / csv / json
     * 内容统一用 Markdown 书写：Word、PDF 排版标题 / 列表 / 表格；PPT 用「# 标题」分页；Excel 用表格或 CSV。
     */
    fun createFile(name: String, content: String, format: String): FileRef {
        val ext = normalizeFormat(format, name)
        val base = name.trim().ifBlank { "灵犀文档" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .let { n -> if (n.contains('.') && n.substringAfterLast('.').length in 1..5) n.substringBeforeLast('.') else n }
        val fileName = "$base.$ext"
        return saveNew(fileName, renderContent(content, ext, base), mimeFor(ext))
    }

    /**
     * 把 Markdown / 文本内容渲染成指定格式的字节（docx / pptx / xlsx / pdf / html / csv / 文本）。
     * [create_file] 与 AI 文件夹的写入共用。
     */
    fun renderContent(content: String, ext: String, base: String): ByteArray {
        return when (ext) {
            "docx" -> OfficeEdit.docxCreateMarkdown(content, base)
            "pptx" -> OfficeEdit.pptxCreate(OfficeEdit.parseSlides(content), base)
            "xlsx" -> OfficeEdit.xlsxCreate(OfficeEdit.parseSheets(content, base.take(31)))
            "pdf" -> PdfTools.createFromMarkdown(content, base)
            "html" -> (if (content.contains("<html", true)) content else
                "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><title>$base</title></head><body>\n$content\n</body></html>").toByteArray(Charsets.UTF_8)
            "csv" -> (byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + content.toByteArray(Charsets.UTF_8))
            else -> content.toByteArray(Charsets.UTF_8)
        }
    }

    /** 用新内容覆盖文件（先自动备份）。 */
    fun replaceContent(ref: FileRef, data: ByteArray, note: String): String {
        val original = readBytes(ref)
        val b = backup(ref, original, note)
        writeBytes(ref, data)
        return "修改前的版本已备份（${formatTime(b.time)}），可在「备份还原」里一键恢复。"
    }

    // ───────── 目录浏览（需要“所有文件访问”权限） ─────────

    fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager() else true

    fun listDir(path: String?): String {
        if (!hasAllFilesAccess()) {
            throw IllegalStateException("没有“所有文件访问”权限。可以点输入框左侧 ＋ →「文件」直接选择文件，或在设置里开启该权限。")
        }
        @Suppress("DEPRECATION")
        val root = Environment.getExternalStorageDirectory()
        val dir = when {
            path.isNullOrBlank() -> File(root, Environment.DIRECTORY_DOWNLOADS)
            path.startsWith("/") -> File(path)
            else -> File(root, path)
        }
        if (!dir.exists() || !dir.isDirectory) throw IllegalArgumentException("目录不存在：${dir.absolutePath}")
        val items = dir.listFiles()?.sortedWith(compareBy<File>({ !it.isDirectory }, { -it.lastModified() }))?.take(60).orEmpty()
        if (items.isEmpty()) return "${dir.absolutePath}（空目录）"
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
        return buildString {
            append(dir.absolutePath).append('\n')
            for (f in items) {
                if (f.isDirectory) append("📁 ").append(f.name).append("/\n")
                else append("📄 ").append(f.name).append("  ").append(com.dia.app.web.WebDownloader.formatSize(f.length()))
                    .append("  ").append(fmt.format(Date(f.lastModified()))).append('\n')
            }
        }.trimEnd()
    }

    // ───────── 备份 / 还原 ─────────

    private fun backup(ref: FileRef, data: ByteArray, note: String): BackupEntry {
        val id = UUID.randomUUID().toString()
        File(backupDir, "$id.bin").writeBytes(data)
        val entry = BackupEntry(id, ref.id, ref.uri, ref.name, System.currentTimeMillis(), data.size.toLong(), note)
        synchronized(lock) {
            var list = listOf(entry) + _backups.value
            if (list.size > 80) {
                list.drop(80).forEach { File(backupDir, "${it.id}.bin").delete() }
                list = list.take(80)
            }
            _backups.value = list
            saveBackups(list)
        }
        return entry
    }

    fun backupsFor(fileKey: String?): List<BackupEntry> {
        if (fileKey.isNullOrBlank()) return _backups.value
        val ref = find(fileKey)
        return _backups.value.filter { b -> (ref != null && (b.uri == ref.uri || b.fileId == ref.id)) || b.name.contains(fileKey) }
    }

    /** 还原备份（还原前会把当前版本也备份一份，可来回切换）。 */
    fun restore(backupId: String): String {
        val entry = _backups.value.firstOrNull { it.id == backupId } ?: throw IllegalArgumentException("备份不存在")
        val data = File(backupDir, "${entry.id}.bin").takeIf { it.exists() }?.readBytes()
            ?: throw IllegalStateException("备份文件已丢失")
        val ref = _files.value.firstOrNull { it.uri == entry.uri }
            ?: FileRef(entry.fileId, entry.uri, entry.name, guessMime(entry.name), entry.size)
        try {
            val current = readBytes(ref)
            backup(ref, current, "还原前的版本")
        } catch (_: Exception) { }
        writeBytes(ref, data)
        return "已把「${entry.name}」还原到 ${formatTime(entry.time)} 的版本。"
    }

    fun deleteBackup(backupId: String) {
        synchronized(lock) {
            File(backupDir, "$backupId.bin").delete()
            val list = _backups.value.filter { it.id != backupId }
            _backups.value = list
            saveBackups(list)
        }
    }

    fun formatTime(t: Long): String = SimpleDateFormat("M月d日 HH:mm:ss", Locale.CHINA).format(Date(t))

    // ───────── 持久化 ─────────

    private fun loadFiles(): List<FileRef> = try {
        if (!filesIndex.exists()) emptyList() else {
            val arr = JSONArray(filesIndex.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                FileRef(o.optString("id"), o.optString("uri"), o.optString("name"), o.optString("mime"), o.optLong("size", -1), o.optLong("addedAt"))
            }.filter { it.id.isNotEmpty() && it.uri.isNotEmpty() }
        }
    } catch (_: Exception) { emptyList() }

    private fun saveFiles(list: List<FileRef>) {
        val arr = JSONArray()
        for (f in list) arr.put(JSONObject().put("id", f.id).put("uri", f.uri).put("name", f.name).put("mime", f.mime).put("size", f.size).put("addedAt", f.addedAt))
        try { filesIndex.writeText(arr.toString()) } catch (e: Exception) { Log.e(TAG, "saveFiles", e) }
    }

    private fun loadBackups(): List<BackupEntry> = try {
        if (!backupIndex.exists()) emptyList() else {
            val arr = JSONArray(backupIndex.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                BackupEntry(o.optString("id"), o.optString("fileId"), o.optString("uri"), o.optString("name"), o.optLong("time"), o.optLong("size"), o.optString("note"))
            }
        }
    } catch (_: Exception) { emptyList() }

    private fun saveBackups(list: List<BackupEntry>) {
        val arr = JSONArray()
        for (b in list) arr.put(JSONObject().put("id", b.id).put("fileId", b.fileId).put("uri", b.uri).put("name", b.name).put("time", b.time).put("size", b.size).put("note", b.note))
        try { backupIndex.writeText(arr.toString()) } catch (e: Exception) { Log.e(TAG, "saveBackups", e) }
    }
}
