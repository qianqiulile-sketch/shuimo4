package com.dia.app.ui.slate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dia.app.slate.NotebookMeta
import com.dia.app.slate.NotebookMode
import com.dia.app.slate.NotebookPage
import com.dia.app.slate.PageBackground
import com.dia.app.slate.SlateState
import com.dia.app.slate.SlateStore
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.inkPageBackground
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/**
 * Slate landing screen.
 *
 * Layout:
 *   - Top bar with back arrow + "Slate" title.
 *   - Two big mode tiles: "Notebook" (freeform notes) and "Quiz" (10-q quiz).
 *   - Below, a list of saved notebooks (newest first). Tap to open. Long-press
 *     style row has a delete icon. New notebook button at top-right of the list.
 *
 * Persistence flows through [SlateStore] which is initialised in
 * MainActivity (lifecycleScope), so the list shows up immediately.
 */
@Composable
fun SlateHomeScreen(
    onBack: () -> Unit,
    onOpenNotebook: (id: String) -> Unit,
    onOpenQuiz: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val notebooks by SlateStore.notebooks.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkPageBackground()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        // Top bar
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
            }
            Spacer(Modifier.width(6.dp))
            Text(
                "手写板",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = DiaTextPrimary,
            )
        }

        Spacer(Modifier.height(12.dp))

        // Mode tiles
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ModeTile(
                title = "笔记本",
                subtitle = "写下内容 — 灵犀以手写回复",
                icon = Icons.Rounded.AutoStories,
                accent = Color(0xFF7AD8FF),
                modifier = Modifier.weight(1f),
                onClick = {
                    // Create a new notebook + jump in.
                    scope.launch {
                        val id = SlateStore.newId()
                        val state = SlateState(id, "新笔记本", NotebookMode.NOTES)
                        state.pageBackground = PageBackground.RULED
                        state.addPage(
                            NotebookPage(
                                id = state.newPageId(),
                                width = SlateState.PAGE_WIDTH,
                                height = SlateState.PAGE_HEIGHT,
                            )
                        )
                        SlateStore.save(state)
                        onOpenNotebook(id)
                    }
                },
            )
            ModeTile(
                title = "测验",
                subtitle = "提问、手写作答、自动评分",
                icon = Icons.Rounded.Quiz,
                accent = Color(0xFFFFB300),
                modifier = Modifier.weight(1f),
                onClick = onOpenQuiz,
            )
        }

        Spacer(Modifier.height(20.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "我的笔记本",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = DiaTextPrimary,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = {
                scope.launch {
                    val id = SlateStore.newId()
                    val state = SlateState(id, "新笔记本", NotebookMode.NOTES)
                    state.addPage(
                        NotebookPage(
                            id = state.newPageId(),
                            width = SlateState.PAGE_WIDTH,
                            height = SlateState.PAGE_HEIGHT,
                        )
                    )
                    SlateStore.save(state)
                    onOpenNotebook(id)
                }
            }) {
                Icon(Icons.Rounded.Add, "新建笔记本", tint = DiaTextSecondary)
            }
        }

        Spacer(Modifier.height(8.dp))

        if (notebooks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "还没有笔记本 — 点击上方「笔记本」开始。",
                    color = DiaTextTertiary,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(notebooks, key = { it.id }) { meta ->
                    NotebookRow(
                        meta = meta,
                        onClick = { onOpenNotebook(meta.id) },
                        onDelete = { scope.launch { SlateStore.delete(meta.id) } },
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(DiaSurface)
            .border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = DiaTextPrimary,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = DiaTextSecondary,
        )
    }
}

@Composable
private fun NotebookRow(meta: NotebookMeta, onClick: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DiaSurface)
            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SlateState.PaperColor),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (meta.mode == NotebookMode.QUIZ) Icons.Rounded.Quiz else Icons.Rounded.AutoStories,
                null,
                tint = SlateState.InkOnPaper,
                modifier = Modifier.size(18.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                meta.title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                color = DiaTextPrimary,
            )
            Text(
                "${meta.pageCount} 页 · ${formatDate(meta.updatedAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = DiaTextSecondary,
            )
        }
        IconButton(onClick = onDelete) {
            Icon(
                Icons.Rounded.DeleteOutline,
                "删除",
                tint = DiaTextTertiary,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

private fun formatDate(epochMs: Long): String {
    val df = DateFormat.getDateInstance(DateFormat.MEDIUM)
    return df.format(Date(epochMs))
}
