package com.dia.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Persistent foreground service that shows a notification with quick-launch
 * buttons for Chat, Guide, and Pilot. Designed for elderly/disabled users
 * who can't navigate the app drawer.
 */
class DiaQuickLaunchService : Service() {

    companion object {
        private const val CHANNEL_ID = "dia_quick_launch"
        private const val NOTIFICATION_ID = 4800
        const val ACTION_CHAT = "com.dia.app.QUICK_CHAT"
        const val ACTION_GUIDE = "com.dia.app.QUICK_GUIDE"
        const val ACTION_PILOT = "com.dia.app.QUICK_PILOT"

        @Volatile private var running = false
        fun isRunning() = running

        fun start(context: Context) {
            val intent = Intent(context, DiaQuickLaunchService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, DiaQuickLaunchService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "灵犀快捷启动",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "常驻快捷入口，随时与灵犀对话"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        fun actionIntent(action: String): PendingIntent {
            val intent = Intent(this, MainActivity::class.java).apply {
                this.action = action
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            return PendingIntent.getActivity(
                this, action.hashCode(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("灵犀已就绪")
            .setContentText("点击按钮即可对话、获取帮助或自动执行")
            .setSmallIcon(R.drawable.ic_dia_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "对话", actionIntent(ACTION_CHAT))
            .addAction(0, "指南", actionIntent(ACTION_GUIDE))
            .addAction(0, "Pilot", actionIntent(ACTION_PILOT))
            .setContentIntent(actionIntent(ACTION_CHAT))
            .build()
    }
}
