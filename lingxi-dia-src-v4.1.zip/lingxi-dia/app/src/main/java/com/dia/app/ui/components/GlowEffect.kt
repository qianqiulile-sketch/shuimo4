package com.dia.app.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Draws a soft radial glow behind the composable.
 */
fun Modifier.ambientGlow(
    color: Color,
    alpha: Float = 0.25f,
    radius: Float = 120f
): Modifier = this.drawBehind {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                color.copy(alpha = alpha),
                color.copy(alpha = alpha * 0.4f),
                Color.Transparent
            ),
            center = Offset(size.width / 2f, size.height / 2f),
            radius = radius
        ),
        radius = radius,
        center = Offset(size.width / 2f, size.height / 2f)
    )
}

/**
 * Draws a glow offset upward — good for icon backlighting.
 */
fun Modifier.iconGlow(
    color: Color,
    alpha: Float = 0.35f,
    radius: Float = 80f
): Modifier = this.drawBehind {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                color.copy(alpha = alpha),
                color.copy(alpha = alpha * 0.2f),
                Color.Transparent
            ),
            center = Offset(size.width / 2f, size.height / 2f),
            radius = radius
        ),
        radius = radius,
        center = Offset(size.width / 2f, size.height / 2f)
    )
}
