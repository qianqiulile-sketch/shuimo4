package com.dia.app.ui.chat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** 图片读写工具：按需缩放、纠正 EXIF 旋转、保存到应用目录。 */
object ImageUtil {

    fun chatImageDir(context: Context): File = File(context.filesDir, "chat_images").apply { mkdirs() }

    private fun sampleSize(w: Int, h: Int, maxDim: Int): Int {
        var s = 1
        while (w / (s * 2) >= maxDim || h / (s * 2) >= maxDim) s *= 2
        return s
    }

    private fun scaleDown(b: Bitmap, maxDim: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= maxDim) return b
        val r = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * r).toInt().coerceAtLeast(1), (b.height * r).toInt().coerceAtLeast(1), true)
    }

    fun loadFromUri(context: Context, uri: Uri, maxDim: Int = 1280): Bitmap? = try {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim) }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (raw == null) null else {
            val orientation = try {
                cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                    ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val rotated = if (deg != 0f) {
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(deg) }, true)
            } else raw
            scaleDown(rotated, maxDim)
        }
    } catch (_: Exception) {
        null
    }

    fun decodeFile(path: String, maxDim: Int = 1024): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim) }
        BitmapFactory.decodeFile(path, opts)?.let { scaleDown(it, maxDim) }
    } catch (_: Exception) {
        null
    }

    /** 保存为 JPEG，返回文件路径。 */
    fun save(context: Context, bitmap: Bitmap): String {
        val f = File(chatImageDir(context), "img_${UUID.randomUUID()}.jpg")
        FileOutputStream(f).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        return f.absolutePath
    }
}
