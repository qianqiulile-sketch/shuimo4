package com.dia.app.home

import com.dia.app.prefs.DiaPrefs

/**
 * Home Assistant tool implementations. These are called by the Home Mode
 * engine's LLM loop — same pattern as Pilot's tools but simpler (no
 * accessibility service needed, just HTTP calls).
 */
object HaTools {

    fun callService(domain: String, service: String, entityId: String, extra: Map<String, Any>? = null): String {
        val url = DiaPrefs.haBaseUrl.value
        val token = DiaPrefs.haToken.value
        if (url.isBlank() || token.isBlank()) return "Error: Home Assistant not configured"
        val ok = HaClient.callService(url, token, domain, service, entityId, extra)
        return if (ok) "Done. Called $domain.$service on $entityId"
        else "Error: Failed to call $domain.$service on $entityId"
    }

    fun getState(entityId: String): String {
        val url = DiaPrefs.haBaseUrl.value
        val token = DiaPrefs.haToken.value
        if (url.isBlank() || token.isBlank()) return "Error: Home Assistant not configured"
        val entity = HaClient.getState(url, token, entityId)
            ?: return "Error: Could not get state of $entityId"
        return "${entity.friendlyName} is ${entity.state}"
    }

    fun listEntities(domain: String?): String {
        val url = DiaPrefs.haBaseUrl.value
        val token = DiaPrefs.haToken.value
        if (url.isBlank() || token.isBlank()) return "Error: Home Assistant not configured"
        val entities = HaClient.listEntities(url, token, domain)
        if (entities.isEmpty()) return "No entities found${if (domain != null) " for domain '$domain'" else ""}"
        return entities.joinToString("\n") { "\u2022 ${it.friendlyName} (${it.entityId}) \u2014 ${it.state}" }
    }
}
