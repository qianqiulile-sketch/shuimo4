package com.dia.app.files

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import java.io.ByteArrayOutputStream

/**
 * PDF 工具：
 *  - Markdown → PDF（A4、宣纸底色、朱砂标题线，中文用系统字体，自动分页、表格）
 *  - 合并 / 提取页 / 删除页 / 旋转（PDFBox）
 *  - 按页取文字（供 AI 改写后重新生成 PDF）
 */
object PdfTools {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN_X = 60f
    private const val MARGIN_TOP = 64f
    private const val MARGIN_BOTTOM = 64f

    private val INK = Color.rgb(0x2B, 0x25, 0x20)
    private val INK_SOFT = Color.rgb(0x5E, 0x52, 0x46)
    private val CINNABAR = Color.rgb(0xB5, 0x37, 0x2B)
    private val GOLD = Color.rgb(0x9A, 0x7B, 0x3C)
    private val PAPER = Color.rgb(0xFC, 0xF9, 0xF1)
    private val TABLE_HEAD = Color.rgb(0xEA, 0xE0, 0xCA)

    private class Pager(val doc: PdfDocument, val title: String?) {
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = MARGIN_TOP
        var no = 0
        val bottom get() = PAGE_H - MARGIN_BOTTOM
        val width get() = PAGE_W - MARGIN_X * 2

        fun newPage() {
            finish()
            no++
            val info = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, no).create()
            val p = doc.startPage(info)
            page = p
            val c = p.canvas
            canvas = c
            c.drawColor(PAPER)
            val line = Paint().apply { color = GOLD; strokeWidth = 0.6f; alpha = 150 }
            c.drawLine(MARGIN_X, 40f, PAGE_W - MARGIN_X, 40f, line)
            if (!title.isNullOrBlank()) {
                val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = INK_SOFT; textSize = 8f }
                c.drawText(title.take(40), MARGIN_X, 34f, tp)
            }
            val np = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = INK_SOFT; textSize = 9f; textAlign = Paint.Align.CENTER }
            c.drawText("— $no —", PAGE_W / 2f, PAGE_H - 30f, np)
            y = MARGIN_TOP
        }

        fun ensure(h: Float) {
            if (page == null || y + h > bottom) newPage()
        }

        fun finish() {
            page?.let { doc.finishPage(it) }
            page = null
            canvas = null
        }
    }

    private fun paint(size: Float, color: Int = INK, bold: Boolean = false, serif: Boolean = false): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun styled(text: String): CharSequence {
        val sb = SpannableStringBuilder()
        for (s in Markdown.spans(text)) {
            val start = sb.length
            sb.append(s.text)
            val end = sb.length
            if (s.bold) sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (s.italic) sb.setSpan(StyleSpan(Typeface.ITALIC), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (s.code) {
                sb.setSpan(TypefaceSpan("monospace"), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(BackgroundColorSpan(Color.rgb(0xEF, 0xE8, 0xD8)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(ForegroundColorSpan(Color.rgb(0x3E, 0x6E, 0x64)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sb
    }

    private fun layout(text: CharSequence, p: TextPaint, width: Int, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL, spacing: Float = 1.35f): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(10))
            .setAlignment(align)
            .setLineSpacing(0f, spacing)
            .setIncludePad(false)
            .build()

    /** 把一个 StaticLayout 逐行画到页面上，放不下就翻页。 */
    private fun flow(pg: Pager, l: StaticLayout, x: Float, before: Float = 0f, after: Float = 6f) {
        pg.ensure(before + l.getLineBottom(0).toFloat())
        pg.y += before
        var line = 0
        while (line < l.lineCount) {
            if (pg.page == null || pg.y + (l.getLineBottom(line) - l.getLineTop(line)) > pg.bottom) pg.newPage()
            // 本页能放下的行
            val top = l.getLineTop(line)
            var end = line
            while (end < l.lineCount && pg.y + (l.getLineBottom(end) - top) <= pg.bottom) end++
            if (end == line) end = line + 1
            val bottom = l.getLineBottom(end - 1)
            val c = pg.canvas!!
            c.save()
            c.translate(x, pg.y - top)
            c.clipRect(0f, top.toFloat(), pg.width + 40f, bottom.toFloat())
            l.draw(c)
            c.restore()
            pg.y += (bottom - top)
            line = end
        }
        pg.y += after
    }

    fun createFromMarkdown(md: String, title: String? = null): ByteArray {
        val doc = PdfDocument()
        val pg = Pager(doc, title)
        pg.newPage()
        val w = pg.width.toInt()
        val blocks = Markdown.parse(md)
        val firstHeading = (blocks.firstOrNull() as? MdBlock.Heading)?.text
        if (!title.isNullOrBlank() && firstHeading != title) {
            drawTitle(pg, title)
        }
        for ((i, b) in blocks.withIndex()) {
            when (b) {
                is MdBlock.Heading -> {
                    if (i == 0 && b.level == 1) { drawTitle(pg, Markdown.plain(b.text)); continue }
                    val size = when (b.level) { 1 -> 18f; 2 -> 15f; 3 -> 13f; else -> 12f }
                    val l = layout(styled(b.text), paint(size, INK, bold = true, serif = true), w - 10)
                    pg.ensure(size * 3)
                    pg.y += size * 0.6f
                    if (b.level <= 2) {
                        pg.canvas!!.drawRect(MARGIN_X, pg.y + 2, MARGIN_X + 3f, pg.y + l.height - 2, Paint().apply { color = CINNABAR })
                    }
                    flow(pg, l, MARGIN_X + if (b.level <= 2) 9f else 0f, 0f, size * 0.4f)
                }
                is MdBlock.Para -> {
                    for (line in b.text.split('\n')) {
                        val l = layout(styled("　　$line"), paint(11f), w)
                        flow(pg, l, MARGIN_X, 0f, 5f)
                    }
                }
                is MdBlock.Bullet -> {
                    val indent = 14f + b.level * 14f
                    val mark = if (b.ordered) "${b.number}." else if (b.level == 0) "•" else "◦"
                    val ml = layout(mark, paint(11f, CINNABAR, bold = true), 20)
                    val l = layout(styled(b.text), paint(11f), (w - indent - 14).toInt())
                    pg.ensure(l.getLineBottom(0).toFloat())
                    ml.let { mk ->
                        val c = pg.canvas!!
                        c.save(); c.translate(MARGIN_X + indent - 12f, pg.y); mk.draw(c); c.restore()
                    }
                    flow(pg, l, MARGIN_X + indent + 4f, 0f, 3f)
                }
                is MdBlock.Quote -> {
                    val l = layout(styled(b.text), paint(10.5f, INK_SOFT, serif = true), w - 20)
                    pg.ensure(l.height.toFloat().coerceAtMost(60f))
                    val startY = pg.y
                    val startPage = pg.no
                    flow(pg, l, MARGIN_X + 14f, 2f, 8f)
                    if (pg.no == startPage) {
                        pg.canvas!!.drawRect(MARGIN_X + 2f, startY + 2, MARGIN_X + 5f, pg.y - 8f, Paint().apply { color = CINNABAR; alpha = 180 })
                    }
                }
                is MdBlock.Code -> {
                    val l = layout(b.text, paint(9f, Color.rgb(0x3E, 0x6E, 0x64)).apply { typeface = Typeface.MONOSPACE }, w - 16, spacing = 1.2f)
                    flow(pg, l, MARGIN_X + 8f, 4f, 8f)
                }
                is MdBlock.Table -> drawTable(pg, b.rows)
                MdBlock.Rule -> {
                    pg.ensure(14f)
                    pg.y += 6f
                    pg.canvas!!.drawLine(MARGIN_X, pg.y, PAGE_W - MARGIN_X, pg.y, Paint().apply { color = GOLD; strokeWidth = 0.8f })
                    pg.y += 8f
                }
                MdBlock.PageBreak -> pg.newPage()
            }
        }
        pg.finish()
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private fun drawTitle(pg: Pager, title: String) {
        val l = layout(title, paint(22f, INK, bold = true, serif = true), pg.width.toInt(), Layout.Alignment.ALIGN_CENTER)
        pg.ensure(l.height + 40f)
        pg.y += 8f
        flow(pg, l, MARGIN_X, 0f, 6f)
        val c = pg.canvas!!
        val cx = PAGE_W / 2f
        c.drawLine(cx - 60f, pg.y, cx + 60f, pg.y, Paint().apply { color = CINNABAR; strokeWidth = 1.6f })
        pg.y += 18f
    }

    private fun drawTable(pg: Pager, rows: List<List<String>>) {
        if (rows.isEmpty()) return
        val cols = rows.maxOf { it.size }.coerceAtLeast(1)
        val colW = pg.width / cols
        val pad = 4f
        val border = Paint().apply { color = Color.rgb(0x8C, 0x7E, 0x6C); strokeWidth = 0.6f; style = Paint.Style.STROKE }
        val head = Paint().apply { color = TABLE_HEAD }
        pg.y += 4f
        for ((ri, row) in rows.withIndex()) {
            val layouts = (0 until cols).map { ci ->
                layout(styled(row.getOrElse(ci) { "" }), paint(10f, INK, bold = ri == 0), (colW - pad * 2).toInt(), if (ri == 0) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL, 1.2f)
            }
            val h = (layouts.maxOf { it.height } + pad * 2).coerceAtMost(pg.bottom - MARGIN_TOP - 10f)
            pg.ensure(h)
            val c = pg.canvas!!
            for ((ci, l) in layouts.withIndex()) {
                val x = MARGIN_X + ci * colW
                if (ri == 0) c.drawRect(x, pg.y, x + colW, pg.y + h, head)
                c.drawRect(x, pg.y, x + colW, pg.y + h, border)
                c.save()
                c.clipRect(x, pg.y, x + colW, pg.y + h)
                c.translate(x + pad, pg.y + pad)
                l.draw(c)
                c.restore()
            }
            pg.y += h
        }
        pg.y += 10f
    }

    // ───────── PDFBox 页面操作 ─────────

    /** 解析页码范围，如 "1-3,5,8-"（从 1 开始），返回 0 基下标。 */
    fun parsePages(spec: String, total: Int): List<Int> {
        val out = LinkedHashSet<Int>()
        val s = spec.replace('，', ',').replace('、', ',').replace('～', '-').replace('~', '-').replace('–', '-').replace("到", "-").replace("至", "-")
            .replace("第", "").replace("页", "").replace(" ", "")
        if (s.isBlank() || s == "全部" || s == "all") return (0 until total).toList()
        for (part in s.split(',')) {
            if (part.isBlank()) continue
            if (part.contains('-')) {
                val a = part.substringBefore('-').toIntOrNull() ?: 1
                val b = part.substringAfter('-').toIntOrNull() ?: total
                val lo = minOf(a, b).coerceAtLeast(1)
                val hi = maxOf(a, b).coerceAtMost(total)
                for (i in lo..hi) out.add(i - 1)
            } else {
                val n = part.toIntOrNull() ?: continue
                if (n in 1..total) out.add(n - 1) else if (n < 0 && total + n >= 0) out.add(total + n)
            }
        }
        return out.toList()
    }

    private fun save(doc: com.tom_roush.pdfbox.pdmodel.PDDocument): ByteArray {
        val out = ByteArrayOutputStream()
        doc.save(out)
        return out.toByteArray()
    }

    fun merge(files: List<ByteArray>): ByteArray {
        if (files.size < 2) throw IllegalArgumentException("至少需要两个 PDF 才能合并")
        val sources = files.map { com.tom_roush.pdfbox.pdmodel.PDDocument.load(it) }
        val dst = com.tom_roush.pdfbox.pdmodel.PDDocument()
        try {
            for (src in sources) {
                for (i in 0 until src.numberOfPages) dst.importPage(src.getPage(i))
            }
            return save(dst)
        } finally {
            try { dst.close() } catch (_: Exception) { }
            sources.forEach { try { it.close() } catch (_: Exception) { } }
        }
    }

    /** 只保留选中的页（按给定顺序）。 */
    fun extract(bytes: ByteArray, spec: String): Pair<ByteArray, Int> {
        val src = com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes)
        val dst = com.tom_roush.pdfbox.pdmodel.PDDocument()
        try {
            val idx = parsePages(spec, src.numberOfPages)
            if (idx.isEmpty()) throw IllegalArgumentException("页码「$spec」无效（共 ${src.numberOfPages} 页）")
            for (i in idx) dst.importPage(src.getPage(i))
            return save(dst) to idx.size
        } finally {
            try { dst.close() } catch (_: Exception) { }
            try { src.close() } catch (_: Exception) { }
        }
    }

    fun deletePages(bytes: ByteArray, spec: String): Pair<ByteArray, Int> {
        val doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes)
        try {
            val idx = parsePages(spec, doc.numberOfPages).sortedDescending()
            if (idx.isEmpty()) throw IllegalArgumentException("页码「$spec」无效（共 ${doc.numberOfPages} 页）")
            if (idx.size >= doc.numberOfPages) throw IllegalArgumentException("不能删除全部页面")
            for (i in idx) doc.removePage(i)
            return save(doc) to idx.size
        } finally {
            try { doc.close() } catch (_: Exception) { }
        }
    }

    fun rotate(bytes: ByteArray, spec: String, degrees: Int): Pair<ByteArray, Int> {
        val doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes)
        try {
            val idx = parsePages(spec.ifBlank { "全部" }, doc.numberOfPages)
            val d = ((degrees % 360) + 360) % 360 / 90 * 90
            for (i in idx) {
                val p = doc.getPage(i)
                p.rotation = (p.rotation + d) % 360
            }
            return save(doc) to idx.size
        } finally {
            try { doc.close() } catch (_: Exception) { }
        }
    }

    /** 每页的文字。 */
    fun pageTexts(bytes: ByteArray, maxPages: Int = 200): List<String> {
        val doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes)
        try {
            val n = minOf(doc.numberOfPages, maxPages)
            val st = com.tom_roush.pdfbox.text.PDFTextStripper()
            return (1..n).map { p ->
                st.startPage = p
                st.endPage = p
                st.getText(doc).trim()
            }
        } finally {
            try { doc.close() } catch (_: Exception) { }
        }
    }

    fun pageCount(bytes: ByteArray): Int {
        val doc = com.tom_roush.pdfbox.pdmodel.PDDocument.load(bytes)
        try { return doc.numberOfPages } finally { try { doc.close() } catch (_: Exception) { } }
    }
}
