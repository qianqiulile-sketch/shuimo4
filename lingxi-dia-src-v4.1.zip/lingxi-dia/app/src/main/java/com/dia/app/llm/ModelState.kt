package com.dia.app.llm

/**
 * Sealed interface for model lifecycle states.
 * Used by the UI to show appropriate loading / error / ready states.
 */
sealed interface ModelState {
    /** No model file has been selected or loaded. */
    data object NotLoaded : ModelState

    /** Engine is initializing (loading weights, allocating GPU memory, etc). */
    data class Loading(val progress: String) : ModelState

    /** Engine initialized, conversation ready for messages. */
    data class Ready(val modelName: String) : ModelState

    /** Initialization failed due to insufficient device memory. */
    data class InsufficientMemory(val message: String) : ModelState

    /** Generic initialization / runtime error. */
    data class Error(val message: String) : ModelState
}
