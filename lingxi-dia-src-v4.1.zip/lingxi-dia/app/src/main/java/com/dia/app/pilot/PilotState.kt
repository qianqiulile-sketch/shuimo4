package com.dia.app.pilot

/** UI-observable log entry for the activity panel. */
data class PilotLogEntry(
    val id: Long,
    val kind: Kind,
    val text: String,
) {
    enum class Kind { STARTED, STEP, TOOL_CALL, TOOL_RESULT, FINISHED, FAILED, INFO }
}

/** High-level runtime state that survives UI recomposition. */
data class PilotState(
    val running: Boolean = false,
    val task: String = "",
    val stepIndex: Int = 0,
    val lastMessage: String = "",
)
