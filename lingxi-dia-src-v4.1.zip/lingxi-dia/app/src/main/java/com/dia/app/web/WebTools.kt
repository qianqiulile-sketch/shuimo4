package com.dia.app.web

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import com.dia.app.prefs.DiaSettings
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset

/** 简单 HTTP 工具（HttpURLConnection，无第三方依赖）。 */
object Http {

    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"

    data class Response(val code: Int, val bytes: ByteArray, val contentType: String?, val finalUrl: String)

    fun get(url: String, maxBytes: Int = 3_000_000, timeoutMs: Int = 15_000, headers: Map<String, String> = emptyMap()): Response {
        var current = url
        var redirects = 0
        while (true) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.7")
                for ((k, v) in headers) setRequestProperty(k, v)
            }
            try {
                val code = conn.responseCode
                if (code in 300..399 && redirects < 6) {
                    val loc = conn.getHeaderField("Location")
                    if (!loc.isNullOrBlank()) {
                        current = URL(URL(current), loc).toString()
                        redirects++
                        continue
                    }
                }
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val bytes = stream?.use { input ->
                    val out = ByteArrayOutputStream()
                    val buf = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        if (total >= maxBytes) break
                    }
                    out.toByteArray()
                } ?: ByteArray(0)
                return Response(code, bytes, conn.contentType, current)
            } finally {
                conn.disconnect()
            }
        }
        throw IllegalStateException("too many redirects")
    }

    fun postJson(url: String, body: JSONObject, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 120_000): Response {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = timeoutMs
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("User-Agent", UA)
            for ((k, v) in headers) setRequestProperty(k, v)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            return Response(code, bytes, conn.contentType, url)
        } finally {
            conn.disconnect()
        }
    }

    /** 按 Content-Type / HTML meta 判断编码并解码。 */
    fun decode(resp: Response): String {
        val fromHeader = resp.contentType?.let {
            Regex("charset=([A-Za-z0-9_\\-]+)", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)
        }
        val name = fromHeader ?: HtmlText.sniffCharset(resp.bytes.copyOf(minOf(resp.bytes.size, 4096))) ?: "UTF-8"
        val cs = try { Charset.forName(name) } catch (_: Exception) { Charsets.UTF_8 }
        return String(resp.bytes, cs)
    }
}

/** 联网搜索：Bing（国内可用）/ DuckDuckGo / SearXNG，失败自动换下一个。 */
object WebSearch {

    private const val TAG = "WebSearch"

    data class Result(val engine: String, val hits: List<HtmlText.Hit>, val error: String? = null)

    fun search(query: String, limit: Int = 6): Result {
        val q = query.trim()
        if (q.isEmpty()) return Result("", emptyList(), "搜索词为空")
        val preferred = DiaSettings.searchEngine.value
        val order = buildList {
            add(preferred)
            for (e in listOf("bing", "duckduckgo", "searxng")) if (e != preferred) add(e)
        }
        val errors = ArrayList<String>()
        for (engine in order) {
            if (engine == "searxng" && DiaSettings.searxngUrl.value.isBlank()) continue
            try {
                val hits = when (engine) {
                    "bing" -> bing(q)
                    "duckduckgo" -> duck(q)
                    "searxng" -> searx(q)
                    else -> emptyList()
                }
                val clean = hits.distinctBy { it.url.substringBefore('#') }.take(limit)
                if (clean.isNotEmpty()) return Result(engine, clean)
                errors.add("$engine: 无结果")
            } catch (e: Exception) {
                Log.w(TAG, "$engine failed: ${e.message}")
                errors.add("$engine: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        return Result("", emptyList(), errors.joinToString("；").ifBlank { "所有搜索引擎都失败了" })
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun bing(q: String): List<HtmlText.Hit> {
        val resp = Http.get("https://cn.bing.com/search?q=${enc(q)}&setlang=zh-Hans&ensearch=0")
        if (resp.code !in 200..299) throw IllegalStateException("HTTP ${resp.code}")
        val hits = HtmlText.parseBing(Http.decode(resp))
        if (hits.isNotEmpty()) return hits
        // 部分地区 cn.bing.com 返回空，再试国际版
        val resp2 = Http.get("https://www.bing.com/search?q=${enc(q)}")
        return HtmlText.parseBing(Http.decode(resp2))
    }

    private fun duck(q: String): List<HtmlText.Hit> {
        val resp = Http.get("https://html.duckduckgo.com/html/?q=${enc(q)}&kl=cn-zh")
        if (resp.code !in 200..299) throw IllegalStateException("HTTP ${resp.code}")
        return HtmlText.parseDuckDuckGo(Http.decode(resp))
    }

    private fun searx(q: String): List<HtmlText.Hit> {
        val base = DiaSettings.searxngUrl.value.trim().trimEnd('/')
        val resp = Http.get("$base/search?q=${enc(q)}&format=json&language=zh-CN")
        if (resp.code !in 200..299) throw IllegalStateException("HTTP ${resp.code}")
        val root = JSONObject(Http.decode(resp))
        val arr = root.optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val url = o.optString("url")
            val title = o.optString("title")
            if (url.isBlank() || title.isBlank()) null
            else HtmlText.Hit(title, url, o.optString("content").take(300))
        }
    }
}

/** 读取网页正文。 */
object WebReader {

    data class Page(val url: String, val title: String, val text: String)

    fun read(url: String, maxChars: Int = 5000): Page {
        val fixed = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val resp = Http.get(fixed)
        if (resp.code !in 200..299) throw IllegalStateException("网页打开失败（HTTP ${resp.code}）")
        val type = resp.contentType.orEmpty()
        val body = Http.decode(resp)
        return if (type.contains("json") || type.startsWith("text/plain")) {
            Page(resp.finalUrl, "", body.take(maxChars))
        } else {
            val (title, text) = HtmlText.htmlToText(body, maxChars)
            Page(resp.finalUrl, title, text)
        }
    }
}

/** 下载文件到「下载/Dia」目录（系统下载管理器，带通知）。 */
object WebDownloader {

    data class Probe(val url: String, val fileName: String, val mime: String?, val sizeBytes: Long)

    /** 下载前先探测文件名 / 大小，用于确认卡片。 */
    fun probe(url: String, suggestedName: String?): Probe {
        var mime: String? = null
        var size = -1L
        var disposition: String? = null
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 10_000
                readTimeout = 10_000
                setRequestProperty("User-Agent", Http.UA)
            }
            try {
                conn.responseCode
                mime = conn.contentType?.substringBefore(';')?.trim()
                size = conn.contentLengthLong
                disposition = conn.getHeaderField("Content-Disposition")
            } finally {
                conn.disconnect()
            }
        } catch (_: Exception) { }
        val name = suggestedName?.trim()?.takeIf { it.isNotEmpty() }
            ?: URLUtil.guessFileName(url, disposition, mime)
        return Probe(url, sanitize(name, mime), mime, size)
    }

    private fun sanitize(name: String, mime: String?): String {
        var n = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
        if (!n.contains('.') && mime != null) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
            if (!ext.isNullOrBlank()) n = "$n.$ext"
        }
        return n.ifBlank { "download.bin" }
    }

    /** @return DownloadManager 任务 id */
    fun enqueue(context: Context, probe: Probe): Long {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val req = DownloadManager.Request(Uri.parse(probe.url)).apply {
            setTitle(probe.fileName)
            setDescription("灵犀下载")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Dia/${probe.fileName}")
            addRequestHeader("User-Agent", Http.UA)
            if (!probe.mime.isNullOrBlank()) setMimeType(probe.mime)
        }
        return dm.enqueue(req)
    }

    /** 查询下载状态：返回 (状态文字, 是否结束)。 */
    fun status(context: Context, id: Long): Pair<String, Boolean> {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val c: android.database.Cursor = dm.query(DownloadManager.Query().setFilterById(id)) ?: return "未知" to true
        return c.use { cursor ->
            if (!cursor.moveToFirst()) return@use "任务不存在" to true
            val st = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val done = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            when (st) {
                DownloadManager.STATUS_SUCCESSFUL -> "下载完成" to true
                DownloadManager.STATUS_FAILED -> "下载失败" to true
                DownloadManager.STATUS_PAUSED -> "已暂停（等待网络）" to false
                DownloadManager.STATUS_PENDING -> "排队中" to false
                else -> {
                    val pct = if (total > 0) " ${done * 100 / total}%" else ""
                    "下载中$pct" to false
                }
            }
        }
    }

    fun formatSize(bytes: Long): String = when {
        bytes < 0 -> "未知大小"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
        else -> String.format(java.util.Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    }
}
