package com.dia.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class DiaNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        private var instance: DiaNotificationListenerService? = null

        @Volatile
        private var connected: Boolean = false

        fun isConnected(): Boolean = connected && instance != null

        /**
         * Snapshot of active notifications. Returns an empty array if the
         * listener isn't connected or the OS denies access.
         */
        fun getActiveNotificationList(): Array<StatusBarNotification> {
            val svc = instance ?: return emptyArray()
            return try {
                svc.activeNotifications ?: emptyArray()
            } catch (_: Exception) {
                emptyArray()
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        connected = true
        Log.d("DiaNotification", "Notification Listener Connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        connected = false
        Log.d("DiaNotification", "Notification Listener Disconnected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn?.let {
            Log.d("DiaNotification", "Notification from: ${it.packageName}")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
