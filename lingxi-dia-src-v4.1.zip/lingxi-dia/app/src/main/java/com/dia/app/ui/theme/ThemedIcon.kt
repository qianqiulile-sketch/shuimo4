package com.dia.app.ui.theme

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.agent.AgentTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 一个可以换图标的位置。 */
data class IconSlot(
    val key: String,
    val label: String,
    val group: String,
    /** 默认是 Material 图标 */
    val vector: ImageVector? = null,
    /** 默认是文字 / emoji */
    val glyph: String? = null,
)

/**
 * 全部可自定义的图标位。主题包的 theme.json 里 `icons` 用这些 key；
 * 「主题与图标」页里每一个都可以换成图片或文字。
 */
object IconSlots {

    /** 工具的默认图标（emoji）。 */
    fun toolGlyph(name: String?): String = when (name) {
        "web_search" -> "🔍"
        "read_webpage", "open_url" -> "🌐"
        "download" -> "⬇️"
        "read_file", "list_files", "doc_outline" -> "📜"
        "edit_file", "create_file", "rewrite_file", "convert_file" -> "✍️"
        "pdf_tool" -> "📕"
        "restore_file" -> "♻️"
        "translate", "translate_screen" -> "🈯"
        "generate_image", "set_background" -> "🎨"
        "open_app", "phone_task", "phone_action" -> "📱"
        "read_screen", "look_screen" -> "👁"
        "notifications" -> "🔔"
        "clipboard" -> "📋"
        "device_info", "list_apps" -> "⚙️"
        "contacts", "call_phone", "send_message" -> "📞"
        "guide" -> "🧭"
        "remember", "forget", "recall" -> "📝"
        "step_think" -> "☯"
        "calc" -> "🧮"
        "smart_home" -> "🏠"
        "open_page", "set_theme", "theme" -> "🏮"
        "ai_files" -> "🗂"
        "transcribe_audio" -> "🎙"
        "listen_audio" -> "👂"
        "deep_think" -> "🧠"
        "plan" -> "🗺"
        "ask_user" -> "🙋"
        else -> "🗡"
    }

    private val BASE: List<IconSlot> = listOf(
        // 顶栏
        IconSlot("avatar.ai", "灵犀头像", "顶栏"),
        IconSlot("header.history", "历史对话", "顶栏", vector = Icons.Rounded.History),
        IconSlot("header.wuji", "无极开关", "顶栏", glyph = "☯"),
        IconSlot("header.deep", "长思入口", "顶栏", glyph = "思"),
        IconSlot("header.new", "新对话", "顶栏", vector = Icons.Rounded.Add),
        IconSlot("header.more", "更多菜单", "顶栏", vector = Icons.Rounded.MoreVert),
        // 输入栏
        IconSlot("input.toolbox", "百宝囊", "输入栏", glyph = "囊"),
        IconSlot("input.tools", "工具台", "输入栏", glyph = "器"),
        IconSlot("input.web", "联网开关", "输入栏", glyph = "网"),
        IconSlot("input.send", "发送", "输入栏", vector = Icons.AutoMirrored.Rounded.Send),
        IconSlot("input.mic", "语音输入", "输入栏", vector = Icons.Rounded.Mic),
        IconSlot("input.stop", "停止", "输入栏", vector = Icons.Rounded.Stop),
        IconSlot("input.cancel", "取消", "输入栏", vector = Icons.Rounded.Close),
        IconSlot("input.done", "说完了", "输入栏", vector = Icons.Rounded.Check),
        // 消息
        IconSlot("msg.copy", "复制", "消息", vector = Icons.Rounded.ContentCopy),
        IconSlot("msg.speak", "朗读", "消息", vector = Icons.AutoMirrored.Rounded.VolumeUp),
        IconSlot("msg.mute", "停止朗读", "消息", vector = Icons.AutoMirrored.Rounded.VolumeOff),
        IconSlot("msg.retry", "重新生成", "消息", vector = Icons.Rounded.Refresh),
        IconSlot("msg.delete", "删除", "消息", vector = Icons.Rounded.Delete),
        IconSlot("msg.save", "保存图片", "消息", vector = Icons.Rounded.Save),
        IconSlot("msg.thinking", "思考过程", "消息", vector = Icons.Rounded.AutoAwesome),
        // 卡片
        IconSlot("card.done", "工具完成", "卡片", vector = Icons.Rounded.CheckCircle),
        IconSlot("card.error", "工具失败", "卡片", vector = Icons.Rounded.Warning),
        IconSlot("card.expand", "展开", "卡片", vector = Icons.Rounded.KeyboardArrowDown),
        IconSlot("card.plan", "思考树", "卡片", glyph = "☯"),
        IconSlot("card.confirm", "确认令牌", "卡片", glyph = "令"),
        IconSlot("card.user", "亲自调用标记", "卡片", glyph = "亲"),
        // 长思
        IconSlot("deep.start", "开始 / 继续", "长思", vector = Icons.Rounded.PlayArrow),
        IconSlot("deep.pause", "暂停", "长思", vector = Icons.Rounded.Pause),
        IconSlot("deep.folder", "长思文件夹", "长思", vector = Icons.Rounded.Folder),
        IconSlot("deep.new", "新建长思", "长思", vector = Icons.Rounded.Add),
        IconSlot("deep.send", "插话发送", "长思", vector = Icons.AutoMirrored.Rounded.Send),
        IconSlot("deep.attach", "添加文件", "长思", vector = Icons.Rounded.AttachFile),
        // 文件夹
        IconSlot("folder.dir", "文件夹", "文件夹", glyph = "📁"),
        IconSlot("folder.file", "文件", "文件夹", glyph = "📄"),
    )

    val ALL: List<IconSlot> by lazy {
        val tools = AgentTools.ALL.map { IconSlot("tool.${it.name}", it.title, "工具", glyph = toolGlyph(it.name)) }
        val box = com.dia.app.ui.chat.TOOLBOX_GROUPS.flatMap { (_, items) -> items }
            .map { IconSlot("box.${it.key}", it.label, "百宝囊", glyph = it.emoji) }
        BASE + tools + box
    }

    val GROUPS: List<String> get() = ALL.map { it.group }.distinct()

    fun find(key: String): IconSlot? = ALL.firstOrNull { it.key == key }
}

/** 主题图片缓存（解码一次，多处复用）。 */
object ThemeImageCache {
    private val cache = object : LruCache<String, ImageBitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    fun peek(path: String, maxDim: Int): ImageBitmap? = cache.get("$path@$maxDim")

    fun load(path: String, maxDim: Int): ImageBitmap? {
        peek(path, maxDim)?.let { return it }
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var sample = 1
            while (o.outWidth / sample > maxDim * 2 || o.outHeight / sample > maxDim * 2) sample *= 2
            val b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
            if (b != null) cache.put("$path@$maxDim", b)
            b
        } catch (_: Throwable) {
            null
        }
    }

    fun clear() = cache.evictAll()
}

@Composable
fun rememberThemeBitmap(path: String?, maxDim: Int = 256): ImageBitmap? {
    if (path == null) return null
    ThemeImageCache.peek(path, maxDim)?.let { return it }
    val b by produceState<ImageBitmap?>(initialValue = null, path, maxDim) {
        value = withContext(Dispatchers.IO) { ThemeImageCache.load(path, maxDim) }
    }
    return b
}

@Composable
private fun GlyphText(text: String, color: Color, size: Dp, brush: Boolean, modifier: Modifier) {
    val n = text.codePointCount(0, text.length).coerceAtLeast(1)
    val isEmoji = text.any { Character.isSurrogate(it) } || text.any { it.code in 0x2600..0x27BF }
    val scale = when {
        isEmoji -> 0.74f
        n == 1 -> 0.86f
        n == 2 -> 0.52f
        else -> 0.38f
    }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Text(
            text,
            color = color,
            fontSize = (size.value * scale).sp,
            lineHeight = (size.value * scale * 1.05f).sp,
            fontFamily = if (brush && !isEmoji) DiaBrush else null,
            textAlign = TextAlign.Center,
            maxLines = 1,
        )
    }
}

/**
 * 可被主题替换的图标（默认是 Material 图标）。
 * 主题里这个位置是图片就画图片，是文字就用毛笔字写出来。
 */
@Composable
fun ThemedIcon(
    slot: String,
    fallback: ImageVector,
    contentDescription: String?,
    tint: Color,
    size: Dp = 24.dp,
    modifier: Modifier = Modifier,
) {
    when (val spec = LocalThemePack.current.icons[slot]) {
        is IconSpec.Img -> {
            val b = rememberThemeBitmap(spec.path, 192)
            if (b != null) {
                Image(b, contentDescription, modifier.size(size), contentScale = ContentScale.Fit,
                    colorFilter = if (spec.tint) ColorFilter.tint(tint) else null)
            } else Icon(fallback, contentDescription, modifier.size(size), tint = tint)
        }
        is IconSpec.Txt -> GlyphText(spec.text, spec.color ?: tint, size, spec.brush, modifier)
        null -> Icon(fallback, contentDescription, modifier.size(size), tint = tint)
    }
}

/** 可被主题替换的文字 / emoji 图标（默认是 [fallback] 这几个字）。 */
@Composable
fun ThemedGlyph(
    slot: String,
    fallback: String,
    color: Color,
    size: Dp = 24.dp,
    brush: Boolean = true,
    modifier: Modifier = Modifier,
) {
    when (val spec = LocalThemePack.current.icons[slot]) {
        is IconSpec.Img -> {
            val b = rememberThemeBitmap(spec.path, 192)
            if (b != null) {
                Image(b, null, modifier.size(size), contentScale = ContentScale.Fit,
                    colorFilter = if (spec.tint) ColorFilter.tint(color) else null)
            } else GlyphText(fallback, color, size, brush, modifier)
        }
        is IconSpec.Txt -> GlyphText(spec.text, spec.color ?: color, size, spec.brush, modifier)
        null -> GlyphText(fallback, color, size, brush, modifier)
    }
}

/** 主题设置页里预览一个图标位。 */
@Composable
fun SlotPreview(slot: IconSlot, color: Color, size: Dp = 28.dp) {
    when {
        slot.key == "avatar.ai" -> InkAvatar(size)
        slot.vector != null -> ThemedIcon(slot.key, slot.vector, slot.label, color, size)
        else -> ThemedGlyph(slot.key, slot.glyph ?: "?", color, size, brush = slot.glyph?.any { it.code in 0x3400..0x9fff } == true)
    }
}

/** 工具卡片 / 百宝囊上的工具图标。 */
@Composable
fun ToolGlyph(name: String?, color: Color, size: Dp = 18.dp) {
    ThemedGlyph("tool.${name.orEmpty()}", IconSlots.toolGlyph(name), color, size, brush = false)
}
