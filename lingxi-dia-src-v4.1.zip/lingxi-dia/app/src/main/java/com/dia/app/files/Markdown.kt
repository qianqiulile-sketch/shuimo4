package com.dia.app.files

/**
 * 极简 Markdown 解析（纯 Kotlin，可单元测试）：
 * 新建 Word / PDF / PPT 时，AI 用 Markdown 写内容，这里转成块结构再分别排版。
 */
sealed class MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock()
    data class Para(val text: String) : MdBlock()
    data class Bullet(val text: String, val level: Int, val ordered: Boolean, val number: Int) : MdBlock()
    data class Table(val rows: List<List<String>>) : MdBlock()
    data class Quote(val text: String) : MdBlock()
    data class Code(val text: String) : MdBlock()
    object Rule : MdBlock()
    object PageBreak : MdBlock()
}

/** 行内片段：粗体 / 斜体 / 代码。 */
data class MdSpan(val text: String, val bold: Boolean = false, val italic: Boolean = false, val code: Boolean = false)

object Markdown {

    private val headingRe = Regex("^(#{1,6})\\s+(.*)$")
    private val bulletRe = Regex("^(\\s*)([-*+•·])\\s+(.*)$")
    private val orderedRe = Regex("^(\\s*)(\\d{1,3})(?:[.)）]\\s+|、\\s*)(.*)$")
    private val tableSepRe = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")

    fun parse(md: String): List<MdBlock> {
        val out = ArrayList<MdBlock>()
        val lines = md.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        var i = 0
        val para = StringBuilder()
        fun flushPara() {
            if (para.isNotBlank()) out.add(MdBlock.Para(para.toString().trim()))
            para.setLength(0)
        }
        while (i < lines.size) {
            val raw = lines[i]
            val line = raw.trimEnd()
            val t = line.trim()
            when {
                t.startsWith("```") -> {
                    flushPara()
                    val sb = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trim().startsWith("```")) {
                        sb.append(lines[i]).append('\n'); i++
                    }
                    out.add(MdBlock.Code(sb.toString().trimEnd()))
                }
                t.isEmpty() -> flushPara()
                t == "<分页>" || t == "\\pagebreak" || t == "[分页]" -> { flushPara(); out.add(MdBlock.PageBreak) }
                t == "---" || t == "***" || t == "___" -> { flushPara(); out.add(MdBlock.Rule) }
                headingRe.matches(t) -> {
                    flushPara()
                    val m = headingRe.find(t)!!
                    out.add(MdBlock.Heading(m.groupValues[1].length, m.groupValues[2].trim().trimEnd('#').trim()))
                }
                t.startsWith("|") && i + 1 < lines.size && tableSepRe.matches(lines[i + 1]) -> {
                    flushPara()
                    val rows = ArrayList<List<String>>()
                    rows.add(splitRow(t))
                    i += 2
                    while (i < lines.size && lines[i].trim().startsWith("|")) {
                        rows.add(splitRow(lines[i].trim())); i++
                    }
                    out.add(MdBlock.Table(normalizeRows(rows)))
                    continue
                }
                t.startsWith(">") -> {
                    flushPara()
                    out.add(MdBlock.Quote(t.trimStart('>').trim()))
                }
                bulletRe.matches(line) -> {
                    flushPara()
                    val m = bulletRe.find(line)!!
                    out.add(MdBlock.Bullet(m.groupValues[3].trim(), indentLevel(m.groupValues[1]), false, 0))
                }
                orderedRe.matches(line) -> {
                    flushPara()
                    val m = orderedRe.find(line)!!
                    out.add(MdBlock.Bullet(m.groupValues[3].trim(), indentLevel(m.groupValues[1]), true, m.groupValues[2].toIntOrNull() ?: 1))
                }
                else -> {
                    if (para.isNotEmpty()) para.append('\n')
                    para.append(t)
                }
            }
            i++
        }
        flushPara()
        return out
    }

    private fun indentLevel(ws: String): Int {
        val n = ws.replace("\t", "    ").length
        return (n / 2).coerceIn(0, 4)
    }

    private fun splitRow(line: String): List<String> {
        var s = line.trim()
        if (s.startsWith("|")) s = s.substring(1)
        if (s.endsWith("|")) s = s.substring(0, s.length - 1)
        return s.split('|').map { it.trim() }
    }

    private fun normalizeRows(rows: List<List<String>>): List<List<String>> {
        val w = rows.maxOf { it.size }
        return rows.map { r -> if (r.size >= w) r else r + List(w - r.size) { "" } }
    }

    /** 解析行内 **粗体**、*斜体*、`代码`。 */
    fun spans(text: String): List<MdSpan> {
        val out = ArrayList<MdSpan>()
        val re = Regex("\\*\\*(.+?)\\*\\*|__(.+?)__|`([^`]+)`|\\*([^*\\s][^*]*?)\\*")
        var last = 0
        for (m in re.findAll(text)) {
            if (m.range.first > last) out.add(MdSpan(text.substring(last, m.range.first)))
            when {
                m.groupValues[1].isNotEmpty() -> out.add(MdSpan(m.groupValues[1], bold = true))
                m.groupValues[2].isNotEmpty() -> out.add(MdSpan(m.groupValues[2], bold = true))
                m.groupValues[3].isNotEmpty() -> out.add(MdSpan(m.groupValues[3], code = true))
                else -> out.add(MdSpan(m.groupValues[4], italic = true))
            }
            last = m.range.last + 1
        }
        if (last < text.length) out.add(MdSpan(text.substring(last)))
        return out.filter { it.text.isNotEmpty() }
    }

    /** 去掉行内标记，得到纯文本。 */
    fun plain(text: String): String = spans(text).joinToString("") { it.text }

    /** 把 CSV / TSV / Markdown 表格文本解析成行列。 */
    fun parseTable(text: String): List<List<String>> {
        val lines = text.replace("\r\n", "\n").split('\n').filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        if (lines.first().trim().startsWith("|")) {
            return normalizeRows(lines.filter { !tableSepRe.matches(it) }.map { splitRow(it.trim()) })
        }
        val delim = when {
            lines.first().contains('\t') -> '\t'
            lines.first().count { it == ',' } >= lines.first().count { it == '，' } && lines.first().contains(',') -> ','
            lines.first().contains('，') -> '，'
            else -> ','
        }
        return normalizeRows(lines.map { csvSplit(it, delim) })
    }

    private fun csvSplit(line: String, delim: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                q && c == '"' && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> q = !q
                c == delim && !q -> { out.add(sb.toString().trim()); sb.setLength(0) }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString().trim())
        return out
    }
}
