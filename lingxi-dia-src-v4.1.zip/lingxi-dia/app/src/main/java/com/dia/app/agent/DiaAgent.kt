package com.dia.app.agent

import android.graphics.Bitmap
import com.dia.app.files.FileRef
import com.dia.app.llm.AudioClip
import com.dia.app.llm.LlmGateway
import com.dia.app.memory.MemoryStore
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatMessage
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 自循环里的角色设定。 */
data class Persona(val name: String, val other: String, val topic: String, val round: Int, val total: Int)

/** 一次回复的输入。 */
data class AgentRequest(
    /** 之前的对话（不含本次用户消息） */
    val history: List<ChatMessage>,
    /** 本次用户消息（自循环时为空） */
    val userText: String,
    val hiddenContext: String? = null,
    val images: List<Bitmap> = emptyList(),
    val audio: List<AudioClip> = emptyList(),
    /** 本次消息附带的文件 */
    val files: List<FileRef> = emptyList(),
    val thinking: Boolean = false,
    val persona: Persona? = null,
    /** 强制先执行的工具（斜杠命令） */
    val forcedTool: Pair<String, JSONObject>? = null,
    /** 无极模式：全部权限 + 深度 / 分布式思考 + 自检续航 */
    val wuji: Boolean = false,
    /** 是否分步思考：null = 按设置自动判断 */
    val stepThink: Boolean? = null,
    /** 用户强制调用的工具（@工具名 / 工具台「执行后交给 AI」），按顺序先执行，之后 AI 仍可自主继续调用 */
    val forcedTools: List<Pair<String, JSONObject>> = emptyList(),
    /** 追加到系统提示词末尾的任务说明（自主长思用） */
    val extraSystem: String? = null,
    /** 指定本轮开放的工具（null = 按设置 / 模式自动决定） */
    val toolsOverride: Set<String>? = null,
    /** 本轮最多工具调用次数（null = 按设置） */
    val maxStepsOverride: Int? = null,
    /** 自主长思的一步：全部权限、不做分步思考与无极自检（长思有自己的计划与复盘） */
    val deep: Boolean = false,
)

/** Agent 运行中向界面汇报的事件。 */
interface AgentListener : ToolHost {
    /** 当前回复的可见文本（整段替换） */
    fun onText(text: String)
    fun onThought(delta: String)
    /** 开始一个工具调用：返回卡片 id */
    fun onToolStart(name: String, title: String): String
    /**
     * 开始一个工具调用（带完整信息）：第几步、AI 说明的意图、参数、是不是用户强制调用的。
     * 默认退回 [onToolStart]，界面可以覆盖它来显示更明确的步骤提示。
     */
    fun onToolCall(name: String, title: String, args: JSONObject, reason: String, stepNo: Int, byUser: Boolean): String =
        onToolStart(name, title)
    fun onToolEnd(cardId: String, outcome: ToolOutcome)
    /** 分步思考的进度（思考树）。 */
    fun onPlan(title: String, tree: String, done: Boolean) {}
    /**
     * 分步思考拆出小问题后，交给用户审阅、修改、增删。
     * 返回 null 表示不修改，直接按原计划求解。
     */
    suspend fun reviewPlan(title: String, items: List<StepThinker.StepItem>): List<StepThinker.StepItem>? = null
}

/**
 * 灵犀 Agent：让本地 / 云端模型以「提示词 + 工具调用」的方式工作。
 *
 * 以完成用户的目标为第一原则：
 *  - 一次输出可以带多个 `<tool>{…}</tool>`，互不依赖的只读工具会并行执行
 *  - 工具调用次数默认不设上限，直到任务完成（只拦截完全重复的调用，防止原地打转）
 *  - 复杂问题先「分步思考」：拆成小问题逐层研究，再写最终回答
 *  - 无极模式：调动全部权限、深度思考、分布式思考，完成后自检，没做完就自动接着做
 */
object DiaAgent {

    private const val NAME = "灵犀"

    fun systemPrompt(req: AgentRequest, tools: List<ToolSpec>, memories: List<String>): String {
        val now = SimpleDateFormat("yyyy年M月d日 EEEE HH:mm", Locale.CHINA).format(Date())
        val lang = DiaSettings.replyLanguage.value
        val sb = StringBuilder()
        val p = req.persona
        if (p != null) {
            sb.append("你正在参与一场「自我对话」。你扮演「${p.name}」，对方是「${p.other}」（也是 AI）。\n")
            sb.append("讨论主题：${p.topic}\n")
            sb.append("要求：针对对方上一段发言回应并推进讨论，可以追问、补充、反驳或总结；每次 80～200 字；不要重复已说过的内容；不要自称 AI 助手。\n")
            sb.append("如果对话记录里出现【用户插话】，必须优先回应用户的新信息或新要求。\n")
            sb.append("现在是第 ${p.round}/${p.total} 轮。")
            if (p.round >= p.total) sb.append("这是最后一轮，请做个收尾总结。")
            sb.append("\n当前时间：$now。使用$lang。\n")
        } else {
            sb.append("你是「$NAME」（Dia），运行在用户手机上的全能中文 AI 助手——侠骨柔情，可靠利落，言出必行。\n")
            sb.append("当前时间：$now。默认使用$lang 回答，除非用户要求其他语言。善用 Markdown（标题、列表、加粗、表格、代码块）。\n")
            sb.append("\n【行事准则】\n")
            sb.append("1. 以解决用户的需求为第一目标：能做的直接做、做到位；不推脱、不敷衍，不反复确认“要不要”，不要只给建议而不动手。\n")
            sb.append("2. 缺信息就自己去拿：联网搜索、读网页、读文件、看屏幕、查通知、剪贴板、通讯录……工具可以连续、多次、组合使用，直到任务真正完成。\n")
            sb.append("3. 互不依赖的工具可以在同一次回复里连写多个 <tool>，系统会全部执行后一并告诉你结果。\n")
            sb.append("4. 工具失败就换方法：换关键词、换工具、换来源、换参数，不轻易放弃，也不要重复完全相同的调用。\n")
            sb.append("5. 用户要改文件、建文件、操作手机时，直接调用工具完成，不要假装已经完成；做完用一两句话说明结果和文件位置。\n")
            sb.append("6. 涉及最新信息先 web_search，引用搜索结果标注 [序号]；凡是计算都用 calc。\n")
            sb.append("7. 用户的语音会先转成文字再发给你，按文字理解，用文字回复。用户发来的音频文件用 transcribe_audio 转文字（或 listen_audio 直接听）后再处理。\n")
            sb.append("8. 你有自己的专属文件夹「灵犀AI」：生成的文档、笔记、草稿都存那里（ai_files 工具可随时读写），用户问起文件时告诉他位置。\n")
            if (req.wuji && !req.deep) {
                sb.append("\n【无极模式 · 已开启】\n")
                sb.append("用户已主动开启无极模式，授权你调动本机全部能力（联网、文件、屏幕读取与操作、通知、剪贴板、通讯录、应用、智能家居等），所有操作已自动批准，不必再征求许可。\n")
                sb.append("- 先在心里规划完整方案，再一步步执行；复杂问题深度思考、拆解推进。\n")
                sb.append("- 工具调用不限次数，一直做到用户的目标完全达成；遇到阻碍自己想办法绕过或换路。\n")
                sb.append("- 收尾时给出结果总结：做了什么、得到了什么、还有什么必须由用户亲自完成。\n")
            }
        }
        if (memories.isNotEmpty()) {
            sb.append("\n【关于用户的记忆】（自然地利用，不要生硬复述）\n")
            for (m in memories) sb.append("- ").append(m).append('\n')
        }
        if (tools.isNotEmpty()) {
            sb.append("\n【工具】调用方法：输出\n<tool>{\"name\":\"工具名\",\"args\":{参数}}</tool>\n")
            if (DiaSettings.toolReasons.value) {
                sb.append("调用前先用一句话写出这一步要做什么（例如「先联网查一下最新价格」），再写 <tool> 块（可以连写多个）；这句话会作为步骤说明显示给用户。系统执行后把【工具结果】告诉你，你再继续。不需要工具就直接回答。\n")
            } else {
                sb.append("调用时只输出 <tool> 块（可以连写多个），系统执行后把【工具结果】告诉你，你再继续。不需要工具就直接回答。\n")
            }
            sb.append("用户也可能用「@工具名」或工具台亲自指定调用某个工具，结果会出现在工具记录里，你接着处理即可。\n")
            for (t in tools) {
                sb.append("- ").append(t.name).append(' ').append(t.args).append("：").append(t.desc).append('\n')
            }
            sb.append("文件用 id（如 f1）指代；精确修改 Word/PPT/Excel 前先 doc_outline 看结构。")
            if (tools.any { it.name == "step_think" }) sb.append("特别复杂、需要多方面研究的问题可以先 step_think。")
            sb.append('\n')
        }
        if (!req.extraSystem.isNullOrBlank()) sb.append('\n').append(req.extraSystem.trim()).append('\n')
        return sb.toString()
    }

    private fun roleName(m: ChatMessage, persona: Persona?): String = when {
        m.isUser -> if (persona != null) "【用户插话】" else "用户"
        m.persona != null -> m.persona
        else -> NAME
    }

    /** 把历史压缩成文本，从最新往前取，直到用完预算。 */
    fun historyText(history: List<ChatMessage>, budget: Int, persona: Persona?): String {
        val lines = ArrayList<String>()
        var used = 0
        for (m in history.asReversed()) {
            val line = when (m.kind) {
                ChatMessage.KIND_NOTE -> null
                ChatMessage.KIND_PLAN -> "（$NAME 做了分步思考：${m.title.orEmpty()}）"
                ChatMessage.KIND_TOOL -> if (m.byUser) {
                    "（用户手动调用了 ${m.title ?: m.toolName}${if (m.status == "error") "，失败" else ""}，结果：${m.detail.orEmpty().replace('\n', ' ').take(600)}）"
                } else "（$NAME 调用了 ${m.title ?: m.toolName}${if (m.status == "error") "，失败" else ""}）"
                ChatMessage.KIND_CONFIRM -> "（请求确认：${m.title}，结果：${if (m.status == "approved" || m.status == "auto") "同意" else "拒绝"}）"
                ChatMessage.KIND_IMAGE -> "（$NAME 生成了一张图片${m.detail?.let { "，$it" }.orEmpty()}）"
                else -> {
                    if (m.isError || (m.text.isBlank() && m.imagePaths.isEmpty() && m.fileNames.isEmpty())) null
                    else {
                        val extra = buildString {
                            if (m.imagePaths.isNotEmpty() && m.isUser) append("［发送了${m.imagePaths.size}张图片］")
                            if (m.fileNames.isNotEmpty()) append("［附件：${m.fileIds.zip(m.fileNames).joinToString("、") { "${it.first}《${it.second}》" }}］")
                        }
                        val body = m.text.let { if (it.length > 1200) it.take(1200) + "…" else it }
                        "${roleName(m, persona)}：$extra$body"
                    }
                }
            } ?: continue
            if (used + line.length > budget) {
                if (lines.isEmpty() && budget > 200) lines.add(line.take(budget - 20) + "…")
                break
            }
            lines.add(line)
            used += line.length + 1
        }
        return lines.asReversed().joinToString("\n")
    }

    /**
     * 运行一次回复。返回最终可见文本（已展示的工具卡片不在其中）。
     */
    suspend fun run(req: AgentRequest, listener: AgentListener): String {
        val deep = req.deep && req.persona == null
        val wuji = req.wuji && req.persona == null && !deep
        val fullPower = wuji || deep
        val recentTools = req.history.takeLast(8).filter { it.kind == ChatMessage.KIND_TOOL }.mapNotNull { it.toolName }
        val forcedQueue = ArrayDeque<Pair<String, JSONObject>>()
        req.forcedTool?.let { forcedQueue.add(it) }
        forcedQueue.addAll(req.forcedTools)
        val hasAudio = req.files.any { com.dia.app.files.FileManager.isAudio(it) }
        val toolNames: Set<String> = req.toolsOverride ?: if (DiaSettings.agentTools.value || forcedQueue.isNotEmpty() || fullPower) {
            AgentTools.enabledNames(req.persona != null, req.userText, recentTools, req.files.isNotEmpty() || hasAudio)
        } else emptySet()
        // 用户强制调用的工具即使不在本轮工具组里也允许执行
        val allowed: Set<String> = toolNames + forcedQueue.map { it.first }
        val tools = AgentTools.ALL.filter { it.name in toolNames }
        val maxSteps = when {
            tools.isEmpty() && forcedQueue.isEmpty() -> 0
            req.maxStepsOverride != null -> req.maxStepsOverride.let { if (it <= 0) Int.MAX_VALUE else it }
            req.persona != null -> 3
            wuji -> Int.MAX_VALUE
            DiaSettings.maxToolSteps.value <= 0 -> Int.MAX_VALUE
            else -> DiaSettings.maxToolSteps.value
        }

        val memItems = if ((DiaSettings.memoryEnabled.value || fullPower) && req.persona == null) {
            MemoryStore.relevant(req.userText + " " + req.history.takeLast(2).joinToString(" ") { it.text.take(100) })
        } else emptyList()
        if (memItems.isNotEmpty()) MemoryStore.markUsed(memItems.map { it.id })
        val system = systemPrompt(req.copy(wuji = wuji), tools, memItems.map { it.content })

        val budget = (LlmGateway.promptCharBudget() - system.length).coerceAtLeast(800)
        val scratch = StringBuilder()
        var images = req.images

        // 本次附带的文件：直接把开头内容放进提示词，模型不必再调用 read_file
        val filesBlock = StringBuilder()
        if (req.files.isNotEmpty()) {
            val perFile = (budget * 0.4 / req.files.size).toInt().coerceIn(400, 8000)
            for (f in req.files) {
                filesBlock.append("文件 ${f.id}《${f.name}》（${f.kind}）")
                try {
                    val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        com.dia.app.files.FileManager.read(f, 0, perFile)
                    }
                    if (r.text.isNotBlank()) {
                        filesBlock.append("内容").append(if (r.totalChars > r.text.length) "（前 ${r.text.length}/${r.totalChars} 字，可用 read_file 继续读）" else "").append("：\n")
                        filesBlock.append(r.text).append("\n\n")
                    } else {
                        filesBlock.append("：").append(r.note.ifBlank { "无法直接提取文字，可调用 read_file 读取。" }).append("\n\n")
                    }
                } catch (e: Exception) {
                    filesBlock.append("：读取失败（${e.message}）\n\n")
                }
            }
        }

        // ── 分步思考：先拆解研究，再写回答 ──
        var hidden = req.hiddenContext
        val useSteps = !deep && req.persona == null && forcedQueue.isEmpty() && req.userText.isNotBlank() &&
            (req.stepThink ?: StepThinker.shouldUse(req.userText, wuji))
        if (useSteps) {
            val bg = buildString {
                hidden?.takeIf { it.isNotBlank() }?.let { append(it.take(1500)).append('\n') }
                if (filesBlock.isNotBlank()) append(filesBlock.take(2500))
                val recent = historyText(req.history.takeLast(4), 1200, null)
                if (recent.isNotBlank()) append("\n【最近对话】\n").append(recent)
            }
            val planTitle = if (wuji) "无极 · 分布式思考" else "分步思考"
            listener.onPlan(planTitle, "正在规划…", false)
            val r = StepThinker.think(
                req.userText, bg, { title, tree, done -> listener.onPlan(title, tree, done) }, wuji,
                review = { items -> listener.reviewPlan(planTitle, items) },
            )
            hidden = ((hidden ?: "") + "\n\n" + r.notes).trim()
        }
        val effReq = if (hidden != req.hiddenContext) req.copy(hiddenContext = hidden) else req

        var step = 0
        var lastShownToUser = false
        var continuations = 0
        var lastVerdict = ""
        var badCalls = 0
        val seen = HashMap<String, Int>()
        while (true) {
            // 用户强制调用的工具（斜杠命令 / @工具 / 工具台）先执行
            if (forcedQueue.isNotEmpty()) {
                val (fname, fargs) = forcedQueue.removeFirst()
                val outcome = runTool(fname, fargs, listener, "用户指定调用", step + 1, byUser = true)
                appendScratch(scratch, fname, fargs, outcome, byUser = true)
                lastShownToUser = outcome.shownToUser
                if (outcome.images.isNotEmpty()) images = (images + outcome.images).takeLast(3)
                step++
                continue
            }

            val canUseTools = tools.isNotEmpty() && step < maxSteps
            val prompt = buildPrompt(effReq, budget, filesBlock.toString(), scratch.toString(), canUseTools, lastShownToUser)

            var full = ""
            listener.onText("")
            val output = LlmGateway.complete(
                system = system,
                prompt = prompt,
                images = images,
                audio = if (step == 0) req.audio else emptyList(),
                temperature = if (req.persona != null) 0.8 else if (fullPower) 0.5 else 0.6,
                thinking = req.thinking || wuji,
            ) { delta, thought ->
                if (thought != null) listener.onThought(thought)
                if (delta.isNotEmpty()) {
                    full += delta
                    val visible = ToolCallParser.visibleText(full)
                    if (!(tools.isNotEmpty() && ToolCallParser.mightBeCall(full))) listener.onText(stripInlineThink(visible))
                }
            }
            full = output.ifEmpty { full }

            val raws = if (canUseTools) ToolCallParser.findAll(full) else emptyList()
            val parsed = raws.mapNotNull { parseCall(it.json) }
            val calls = parsed.filter { it.first in allowed }

            if (calls.isEmpty()) {
                // 模型写了不存在的工具：告诉它可用的工具，让它再来一次
                if (parsed.isNotEmpty() && canUseTools && badCalls < 2) {
                    badCalls++
                    scratch.append("【系统】没有工具「${parsed.joinToString("、") { it.first }}」。可用：${toolNames.joinToString(",")}。请改用可用的工具，或直接回答。\n\n")
                    continue
                }
                val finalText = stripInlineThink(ToolCallParser.visibleText(full)).trim()
                // 无极模式：自检任务是否真正完成，没完成就自动接着做
                if (wuji && DiaSettings.wujiSelfCheck.value && step > 0 && canUseTools && continuations < 8) {
                    listener.onText(finalText)
                    val verdict = selfCheck(req.userText, scratch.toString(), finalText)
                    if (verdict != null && verdict != lastVerdict) {
                        lastVerdict = verdict
                        continuations++
                        scratch.append("【自检】任务还没完成：$verdict。请继续调用工具把它做完，完成后再给出最终总结。\n\n")
                        continue
                    }
                }
                listener.onText(finalText)
                return finalText
            }

            // 是工具调用：清空流式文本，执行工具。工具块前面的那句话就是 AI 说明的意图
            listener.onText("")
            val reason = stripInlineThink(ToolCallParser.visibleText(full)).trim()
                .lines().filter { it.isNotBlank() }.takeLast(2).joinToString(" ").take(160)
            val fresh = ArrayList<Pair<String, JSONObject>>()
            for (c in calls) {
                val sig = c.first + c.second.toString()
                val n = (seen[sig] ?: 0) + 1
                seen[sig] = n
                if (n >= 3) {
                    scratch.append("【系统】你已经用完全相同的参数调用过 ${c.first} ${n - 1} 次，结果见上。请换个方法 / 换参数，或直接根据已有结果回答。\n\n")
                } else fresh.add(c)
            }
            if (fresh.isEmpty()) {
                step++
                continue
            }
            val parallel = fresh.size > 1 && fresh.all { AgentTools.spec(it.first)?.readOnly == true && it.first != "look_screen" && it.first != "read_screen" }
            val base = step
            val outcomes: List<ToolOutcome> = if (parallel) {
                coroutineScope {
                    fresh.mapIndexed { i, (n, a) -> async { runTool(n, a, listener, if (i == 0) reason else "", base + i + 1, false) } }.awaitAll()
                }
            } else {
                fresh.mapIndexed { i, (n, a) -> runTool(n, a, listener, if (i == 0) reason else "", base + i + 1, false) }
            }
            lastShownToUser = false
            for ((i, c) in fresh.withIndex()) {
                val o = outcomes[i]
                appendScratch(scratch, c.first, c.second, o)
                if (o.shownToUser) lastShownToUser = true
                if (o.images.isNotEmpty()) images = (images + o.images).takeLast(3)
            }
            if (fresh.size > 1 && outcomes.any { !it.shownToUser }) lastShownToUser = false
            step += fresh.size
        }
    }

    /** 无极模式的验收：返回 null 表示已完成，否则返回还差什么。 */
    private suspend fun selfCheck(request: String, scratch: String, answer: String): String? {
        val out = try {
            LlmGateway.complete(
                system = "你是严格的任务验收员，只判断用户的要求是否已经真正做到，不做其它事。",
                prompt = "【用户的要求】$request\n\n【已执行的工具记录（节选）】\n${scratch.takeLast(3500)}\n\n【助手的答复】\n${answer.take(1500)}\n\n" +
                    "用户的要求是否已经完全做到？只输出一行：「完成」，或「未完成：还差什么（一句话）」。若剩下的事只能由用户亲自做（如输入密码、付款确认），算「完成」。",
                temperature = 0.1,
                timeoutMs = 90_000,
            ).trim()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            return null
        }
        val line = out.lines().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        if (!line.startsWith("未完成")) return null
        return line.removePrefix("未完成").trimStart('：', ':', ' ').ifBlank { "还有步骤没做完" }.take(120)
    }

    private suspend fun runTool(
        name: String,
        args: JSONObject,
        listener: AgentListener,
        reason: String = "",
        stepNo: Int = 0,
        byUser: Boolean = false,
    ): ToolOutcome {
        val card = listener.onToolCall(name, AgentTools.cardTitle(name, args), args, reason, stepNo, byUser)
        val outcome = AgentTools.execute(name, args, listener)
        listener.onToolEnd(card, outcome)
        return outcome
    }

    private fun appendScratch(sb: StringBuilder, name: String, args: JSONObject, outcome: ToolOutcome, byUser: Boolean = false) {
        val limit = if (LlmGateway.usingCloud()) 8000 else 3500
        val res = outcome.forModel.let { if (it.length > limit) it.take(limit) + "…（已截断）" else it }
        if (byUser) sb.append("（以下是用户亲自指定调用的工具）\n")
        sb.append("<tool>{\"name\":\"").append(name).append("\",\"args\":").append(args.toString()).append("}</tool>\n")
        sb.append("【工具结果 ").append(name).append(if (outcome.ok) "" else "（失败）").append("】\n").append(res).append("\n\n")
    }

    private fun buildPrompt(
        req: AgentRequest,
        budget: Int,
        filesBlock: String,
        scratch: String,
        canUseTools: Boolean,
        shownToUser: Boolean,
    ): String {
        val current = if (req.persona == null) {
            buildString {
                append("用户：")
                if (req.images.isNotEmpty()) append("［发送了${req.images.size}张图片，见上方］")
                if (req.audio.isNotEmpty()) append("［发送了一段语音，请先听懂再回答］")
                append(req.userText)
                if (!req.hiddenContext.isNullOrBlank()) append("\n\n【附带上下文】\n").append(req.hiddenContext.take(budget * 2 / 5))
            }
        } else ""
        // 预算分配：当前消息 > 工具记录 > 文件 > 历史
        val scratchPart = if (scratch.length > budget / 2) {
            val note = if (req.deep) "…（更早的工具结果已省略，但搜索 / 网页结果都已自动存档在本长思「资料/」里，需要时用 ai_files read 重读，不要重搜）\n"
            else "…（更早的工具记录已省略）\n"
            note + scratch.takeLast(budget / 2).let { t -> t.indexOf("<tool>").let { i -> if (i > 0) t.substring(i) else t } }
        } else scratch
        val filesPart = if (filesBlock.length > budget * 2 / 5) filesBlock.take(budget * 2 / 5) else filesBlock
        val remain = (budget - current.length - scratchPart.length - filesPart.length - 200).coerceAtLeast(300)
        val history = historyText(req.history, remain, req.persona)

        return buildString {
            if (history.isNotBlank()) append("【对话记录】\n").append(history).append("\n\n")
            if (filesPart.isNotBlank()) append("【本次附带的文件】\n").append(filesPart).append("\n")
            if (req.persona == null) {
                append("【当前消息】\n").append(current).append("\n\n")
            } else {
                val p: Persona = req.persona
                append("请以「${p.name}」的身份发言")
                if (history.isBlank()) append("，先提出你对主题「${p.topic}」的第一个观点或问题")
                append("。\n\n")
            }
            if (scratchPart.isNotBlank()) {
                append("【本轮工具记录】\n").append(scratchPart)
                when {
                    shownToUser -> append("工具结果已经展示给用户了。还有没做完的事就继续调用工具；都做完了就用一两句话简短收尾，不要重复内容。\n")
                    canUseTools -> append("请根据工具结果继续：任务没完成就接着调用工具（互不依赖的可以一次写多个），已经完成就给出最终回答。\n")
                    else -> append("不要再调用工具，请直接根据以上结果给出最终回答。\n")
                }
            }
            val speaker = req.persona?.name ?: NAME
            append("$speaker：")
        }
    }

    private fun parseCall(json: String): Pair<String, JSONObject>? = try {
        val o = JSONObject(json)
        val name = o.optString("name").ifBlank { o.optString("tool") }.ifBlank { o.optString("function") }.trim()
        if (name.isBlank()) null else {
            val args = o.optJSONObject("args") ?: o.optJSONObject("arguments") ?: o.optJSONObject("params")
                ?: o.optJSONObject("parameters") ?: o.optString("arguments").takeIf { it.startsWith("{") }?.let { JSONObject(it) }
                ?: JSONObject().also { a ->
                    // 参数直接平铺在顶层的情况
                    val keys = o.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        if (k != "name" && k != "tool" && k != "function") a.put(k, o.get(k))
                    }
                }
            name to args
        }
    } catch (_: Exception) {
        null
    }

    /** 去掉部分量化模型会漏出的 `<think>…</think>`。 */
    private fun stripInlineThink(s: String): String {
        var t = s.replace(Regex("<think>[\\s\\S]*?</think>"), "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open)
        return t.trimStart()
    }
}
