package com.dia.app.screen

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 悬浮气泡的菜单动作（可编辑：开关、改名、改提示词、排序、新增自定义动作）。
 */
data class BubbleAction(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val label: String,
    val subtitle: String = "",
    /** 自定义动作的提示词；内置动作留空则用默认提示词 */
    val prompt: String = "",
    val enabled: Boolean = true,
) {
    val isCustom: Boolean get() = type == TYPE_CUSTOM

    companion object {
        const val TYPE_TRANSLATE = "translate"
        const val TYPE_SUMMARIZE = "summarize"
        const val TYPE_ANSWER = "answer"
        const val TYPE_SOLVE = "solve"
        const val TYPE_ASK_REGION = "ask_region"
        const val TYPE_QUICK_ASK = "quick_ask"
        const val TYPE_SCREEN_TO_CHAT = "screen_to_chat"
        const val TYPE_VOICE = "voice"
        const val TYPE_OPEN_CHAT = "open_chat"
        const val TYPE_CUSTOM = "custom"
        const val TYPE_HIDE = "hide"

        /** 可在编辑器里「添加」的内置类型 */
        val BUILTIN_TYPES = listOf(
            TYPE_QUICK_ASK to "问灵犀（输入问题，结合当前屏幕）",
            TYPE_TRANSLATE to "框选翻译",
            TYPE_SUMMARIZE to "框选总结",
            TYPE_ANSWER to "框选答题",
            TYPE_SOLVE to "框选解题",
            TYPE_ASK_REGION to "框选后语音提问",
            TYPE_SCREEN_TO_CHAT to "读取屏幕发到对话",
            TYPE_VOICE to "语音指令（操控手机）",
            TYPE_OPEN_CHAT to "打开灵犀",
            TYPE_HIDE to "隐藏气泡",
        )
    }
}

data class BubbleStyle(
    /** cinnabar 朱砂 / gold 古金 / indigo 黛青 / ink 墨 */
    val color: String = "cinnabar",
    val sizeDp: Int = 52,
    val alpha: Float = 0.95f,
    /** 菜单自动收起秒数 */
    val menuSeconds: Int = 12,
    /** 结果卡片自动消失秒数（0 = 不自动消失） */
    val resultSeconds: Int = 20,
) {
    fun colorInt(): Int = when (color) {
        "gold" -> 0xFFD4A85A.toInt()
        "indigo" -> 0xFF3E6E64.toInt()
        "ink" -> 0xFF2B2520.toInt()
        else -> 0xFFC8412F.toInt()
    }
}

object BubbleConfig {

    private const val PREFS = "dia_bubble"
    private const val KEY_ACTIONS = "actions"
    private const val KEY_STYLE = "style"

    private var sp: SharedPreferences? = null

    private val _actions = MutableStateFlow(defaults())
    val actions: StateFlow<List<BubbleAction>> = _actions.asStateFlow()

    private val _style = MutableStateFlow(BubbleStyle())
    val style: StateFlow<BubbleStyle> = _style.asStateFlow()

    fun defaults(): List<BubbleAction> = listOf(
        BubbleAction(type = BubbleAction.TYPE_QUICK_ASK, label = "问灵犀", subtitle = "输入问题，结合当前屏幕回答"),
        BubbleAction(type = BubbleAction.TYPE_TRANSLATE, label = "翻译", subtitle = "框选区域，译成中文"),
        BubbleAction(type = BubbleAction.TYPE_SUMMARIZE, label = "总结", subtitle = "框选区域，提炼要点"),
        BubbleAction(type = BubbleAction.TYPE_ANSWER, label = "答题", subtitle = "回答屏幕上的题目"),
        BubbleAction(type = BubbleAction.TYPE_SOLVE, label = "解题", subtitle = "数学 / 代码，给出步骤"),
        BubbleAction(type = BubbleAction.TYPE_SCREEN_TO_CHAT, label = "发到对话", subtitle = "把当前屏幕文字带进对话继续聊"),
        BubbleAction(type = BubbleAction.TYPE_VOICE, label = "语音指令", subtitle = "说出任务，灵犀帮你操作手机"),
        BubbleAction(type = BubbleAction.TYPE_CUSTOM, label = "润色文字", subtitle = "自定义示例：框选后润色", prompt = "把图片中的文字润色得更通顺得体，直接给出润色后的中文文本。"),
        BubbleAction(type = BubbleAction.TYPE_OPEN_CHAT, label = "打开灵犀", subtitle = ""),
        BubbleAction(type = BubbleAction.TYPE_HIDE, label = "隐藏气泡", subtitle = ""),
    )

    fun init(context: Context) {
        if (sp != null) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        sp = prefs
        prefs.getString(KEY_ACTIONS, null)?.let { raw ->
            parseActions(raw)?.takeIf { it.isNotEmpty() }?.let { _actions.value = it }
        }
        prefs.getString(KEY_STYLE, null)?.let { raw ->
            try {
                val o = JSONObject(raw)
                _style.value = BubbleStyle(
                    color = o.optString("color", "cinnabar"),
                    sizeDp = o.optInt("sizeDp", 52).coerceIn(36, 80),
                    alpha = o.optDouble("alpha", 0.95).toFloat().coerceIn(0.3f, 1f),
                    menuSeconds = o.optInt("menuSeconds", 12).coerceIn(3, 120),
                    resultSeconds = o.optInt("resultSeconds", 20).coerceIn(0, 600),
                )
            } catch (_: Exception) { }
        }
    }

    private fun parseActions(raw: String): List<BubbleAction>? = try {
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = o.optString("type")
            if (type.isBlank()) null else BubbleAction(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = type,
                label = o.optString("label").ifBlank { "动作" },
                subtitle = o.optString("subtitle"),
                prompt = o.optString("prompt"),
                enabled = o.optBoolean("enabled", true),
            )
        }
    } catch (_: Exception) { null }

    private fun saveActions(list: List<BubbleAction>) {
        _actions.value = list
        val arr = JSONArray()
        for (a in list) {
            arr.put(JSONObject().put("id", a.id).put("type", a.type).put("label", a.label)
                .put("subtitle", a.subtitle).put("prompt", a.prompt).put("enabled", a.enabled))
        }
        sp?.edit()?.putString(KEY_ACTIONS, arr.toString())?.apply()
    }

    fun setStyle(s: BubbleStyle) {
        _style.value = s
        sp?.edit()?.putString(
            KEY_STYLE,
            JSONObject().put("color", s.color).put("sizeDp", s.sizeDp).put("alpha", s.alpha.toDouble())
                .put("menuSeconds", s.menuSeconds).put("resultSeconds", s.resultSeconds).toString()
        )?.apply()
    }

    fun upsert(action: BubbleAction) {
        val list = _actions.value
        saveActions(if (list.any { it.id == action.id }) list.map { if (it.id == action.id) action else it } else list + action)
    }

    fun toggle(id: String) {
        saveActions(_actions.value.map { if (it.id == id) it.copy(enabled = !it.enabled) else it })
    }

    fun delete(id: String) {
        saveActions(_actions.value.filter { it.id != id })
    }

    fun move(id: String, delta: Int) {
        val list = _actions.value.toMutableList()
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return
        val j = (i + delta).coerceIn(0, list.size - 1)
        if (i == j) return
        val item = list.removeAt(i)
        list.add(j, item)
        saveActions(list)
    }

    fun reset() {
        saveActions(defaults())
        setStyle(BubbleStyle())
    }
}
